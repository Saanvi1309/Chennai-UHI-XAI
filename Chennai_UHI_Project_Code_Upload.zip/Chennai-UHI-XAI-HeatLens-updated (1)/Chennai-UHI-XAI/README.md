# Chennai HeatLens - UHI Intelligence (Deep Learning, Explainable AI, Urban Heat Analytics)

This version extends the existing Java project **without changing the dataset** (`data/` is byte-identical to the original),
without Apache Sedona / IoTDB, and without removing any working module. The original DJL classes, the DJL weights
(`models/uhi-dnn-*.params`) and the earlier dashboard tabs are kept.

## What was added

| Area | What it does | Code | Result files (`results/`) |
|---|---|---|---|
| Deep learning | Pure-Java copy of the **same 28-128-64-32-4 ReLU network**, trained with Adam, dropout, early stopping, learning-rate schedules, optional class weights; 7 configurations compared, **chosen on validation macro-F1 only** | `TunedDnn`, `DnnTrainer`, `TuneDnn` | `dnn_tuning_results.csv`, `dnn_training_history.csv` |
| Calibration | Temperature scaling fitted on validation rows; ECE / reliability before and after | `ModelSuite`, `ModelEval` | `calibration_temperatures.csv`, `calibration_reliability.csv` |
| Evaluation | Accuracy, macro/weighted precision-recall-F1, confusion matrices, ROC-AUC (one-vs-rest), log-loss, Brier, ECE, MAE/RMSE/R2 of the UHI anomaly, training and inference time, errors by location | `ModelEval` | `eval_summary.csv`, `eval_per_class.csv`, `eval_by_location.csv`, `dnn_generalisation.csv`, `dnn_actual_vs_predicted.csv` |
| Explainable AI | Monte-Carlo Shapley values on the **actual DNN weights**: global importance, summary plot, dependence, Low-vs-Extreme comparison, local waterfall, top-5 factors, PDF explanation report, deletion-test faithfulness check | `Xai`, `XaiTab`, `AnalysisReports` | `xai_*.csv` |
| Forecasting | Timestamp-alignment check (no interpolation), horizon table (accuracy, MAE, RMSE, R2), per-location and per-hour errors, confidence calibration, actual-vs-predicted temperature | `TimeAlignment`, `ForecastAnalysis`, `ForecastEvalTab` | `time_alignment_*.csv`, `forecast_horizon_table.csv`, `forecast_by_location.csv`, `forecast_error_by_hour.csv`, `forecast_confidence.csv` |
| Urban heat | Seasonal / monthly / day-night patterns, persistent-hotspot test, rankings, correlation matrices (pooled and within-location), heat-risk ranking | `UrbanAnalytics`, `HeatMapTab` | `season_location_stats.csv`, `monthly_uhi_distribution.csv`, `day_night_analysis.csv`, `hotspot_persistence.csv`, `correlation_*.csv`, `heat_risk_ranking.csv` |
| Urban planning | Transparent priority scores (trees, green space, cool roofs, roadside vegetation, water bodies) and a baseline-vs-scenario mitigation comparison with reliability flags | `PlanningEngine`, `PlanningTab` | `urban_planning_priorities.csv`, `mitigation_impact_comparison.csv` |
| Dashboard | 8-page navigation (Overview, Heat Map, DNN Prediction, Model Evaluation, Explainable AI, Heat Risk, Urban Planning, Reports), PNG export buttons, PDF/CSV reports | `UHIDashboard`, `*Tab` | `exports/` |

## Run it

| What | How |
|---|---|
| Dashboard | run `org.example.dashboard.Launcher` (working directory = project root) or `mvn javafx:run` |
| Re-run the DNN search | `org.example.analytics.TuneDnn` (about 3 min, one CPU core) |
| Recompute every results file | `org.example.analytics.AnalysisRunner` (about 1-2 min). The dashboard does this automatically if `results/model_performance_analysis.txt` is missing |
| Sample PDF reports | `org.example.analytics.AnalysisReports` -> `exports/sample_model_performance_report.pdf`, `sample_xai_report_P4.pdf` |

## Findings you should know before presenting

* **The tuned DNN is not meaningfully better than your DJL DNN.** Validation macro-F1 0.664 vs 0.649, test accuracy 58.7% vs 57.9%,
  gradient boosting 59.0%: the three are effectively tied on the test period. The best configuration found (`A_djl_like`) uses the same settings as your
  `UHITrainer` plus early stopping; none of the other six settings (plateau/cosine schedules, other dropout, weight decay, class weights) beat it on validation.
  Classes are nearly balanced, so class weights change little. The honest conclusion is that the 28 features, not the training recipe, limit accuracy.
* **Generalisation gap:** DNN accuracy is 66.8% on validation (Jan-Jun 2025) and 58.7% on test (Jul-Dec 2025). The cause was not isolated (the two periods cover different months).
* **Hardest class:** High (F1 0.48); 82% of errors are to a neighbouring class.
* **XAI:** weather features carry about 48% of total attribution, location/static features about 31%. Static features are constant per grid point, so they act as location identifiers
  - read their credit as "which place", not as a causal effect. The deletion test confirms the ranking is faithful (removing the top-3 features drops P(class) by 0.32 vs 0.07 for random features).
* **Forecasting:** all six locations have complete hourly records (no missing or duplicate hours), so 1-24 h horizons are valid without interpolation. Test accuracy falls from 78.8% (+1 h) to 70.1% (+24 h).
* **Mitigation simulation is weak by construction.** With six grid points the static features behave as location IDs, so simulated changes are mostly below the model error (~0.3 C) and
  some presets even *warm* P2/P4. The tables flag these rows as artefacts. Present the simulator as exploratory; cool-roof effects cannot be simulated (no albedo feature).
* **Hotspots:** P6 (Ponneri-Ennore) and P5 (Tiruvallur) are the persistent hotspots (top-two warmest points in at least half of the 24 months and in both years). Everything spatial refers to six 0.25-degree cells (about 28 km); nothing is interpolated.
* `models/forecast_gb.bin` was re-trained once (the old file lacked the neural-network challenger); gradient boosting was kept after validation comparison and `results/forecast_evaluation.csv` is unchanged.

## Verification status

* All code in `org.example.analytics` (training, XAI, evaluation, forecasting analysis, urban analytics, planning, PDF reports) was compiled and **run** with JDK 21; every file in `results/` and `exports/sample_*` was produced by that run.
* The JavaFX pages (`HeatMapTab`, `DnnTab`, `ForecastEvalTab`, `EvalTab`, `XaiTab`, `PlanningTab`, `ReportsTab`, edits to `UHIDashboard`, `Ui`, `ModelsTab`, `SimulatorTab`) **could not be compiled or launched** in the build environment (no JavaFX/Maven there).
  They only use APIs already used elsewhere in the project, but expect to fix a few compile errors on first build; each page only reads `results/*.csv` or calls the tested analytics classes.
* The DJL trainer/XAI classes were not modified (they need the PyTorch engine). The tuned network is a pure-Java implementation of the same architecture.

---

# Previous README (unchanged content)

# Chennai UHI XAI - dashboard, forecasting and what-if extensions

Your original pipeline (target generation -> classification -> split -> scaling -> DJL training -> evaluation -> Shapley XAI)
is **unchanged**. This version adds an interactive JavaFX dashboard and six new capabilities on top of it.

## Run it

| What | How |
|---|---|
| Dashboard (IntelliJ) | run `org.example.dashboard.Launcher` (working directory = project root, the folder containing `data/` and `models/`) |
| Dashboard (Maven) | `mvn javafx:run` |
| Build/refresh all models + result files once | run `org.example.analytics.BuildArtifacts` (about 1-2 min) |

The zip already contains the trained models (`models/*.bin`) and results (`results/*.csv`), so the dashboard opens in a few seconds.
Delete `models/gb_uhi.bin`, `lr_uhi.bin` or `forecast_gb.bin` to force re-training; the dashboard will retrain automatically.
Only `pom.xml` was edited (main class -> `org.example.dashboard.Launcher`).

## The six features

| # | Feature | Where in the dashboard | Code |
|---|---|---|---|
| 1 | **Forecasting** - UHI class 1-24 h ahead for each grid point, with back-testing | *24 h forecast* tab | `ForecastModel`, `ForecastTab`, `StripCanvas` |
| 2 | **Heat-risk layer** - heat index (air temp + humidity) + UHI anomaly -> 5 warning levels | *Heat risk* tab, filters, forecast strip | `HeatRisk`, `HeatRiskTab` |
| 3 | **Mitigation simulator** - what-if on green cover, building density, road density, water distance | *Mitigation simulator* tab | `Simulator`, `SimulatorTab` |
| 4 | **Report export** - PDF report, CSV summary, CSV of the filtered hourly rows (into `exports/`) | *Export report* menu (top right) | `ReportExporter`, `PdfDoc` |
| 5 | **Multi-model comparison** - your DNN vs gradient boosting vs logistic regression, on the current filters | *Model comparison* tab | `ModelSuite`, `GradientBoostedModel`, `LogisticModel`, `DnnModel` |
| 6 | **Alerts & recommendations** - plain-language insights, forecast alerts, actions per grid point | *Alerts & insights* tab | `InsightEngine`, `InsightsTab` |

Global filters (left sidebar): date range, time of day, grid points, UHI class, heat-risk level, months, quick presets.
Everything - charts, KPIs, insights, exports, model scores - follows the filters. Dark mode toggle in the header.

## How each part works

* **DNN without DJL at dashboard time** - `DnnModel` reads the weights straight from `models/uhi-dnn-0002.params` (the highest-numbered file) and
  runs the 28-128-64-32-4 ReLU network in plain Java. Its test accuracy (57.9%) matches what the DJL evaluator reports, so no retraining was needed.
  Your original DJL classes still work as before.
* **Forecaster** - one gradient-boosting model with the horizon as an input. Features: lagged UHI anomalies (now, -1, -3, -6, -12, -24 h, 24 h mean),
  the anomaly at the same hour 1/2/3 days before the target hour, current weather, grid-relative weather, and the calendar of the target hour.
  Temperature and humidity for the heat-risk level are forecast with a month x hour climatology plus decaying persistence.
* **Heat-risk level** - NWS (Rothfusz) heat index in degC + the UHI anomaly of the hour (or the class-mean anomaly for forecasts), cut at
  26.7 / 32.2 / 39.4 / 51.1 degC into Normal, Caution, Extreme Caution, Danger, Extreme Danger.
* **Simulator** - edits the model inputs (NDVI with NIR/red kept consistent, distance to green space, building density, road density, distance to water),
  re-scales them with the training scaler and re-predicts. Output: class mix before/after, expected UHI anomaly change (probability-weighted), heat-stress change,
  and a 0-100% sensitivity sweep for all three models.
* **Insights** - rule-based text from the filtered view: hot-spot hour/month per point, hottest time-of-day window, spatial contrast, heat-stress exposure,
  seasonal swing, recommendations driven by each point's built density, vegetation, road density and distance to water, and forecast alerts per point.

## Results (test period Jul-Dec 2025)

| Classifier | Accuracy | Macro-F1 | within +/-1 class |
|---|---|---|---|
| DNN (your trained model) | 57.9% | 58.3% | 92.7% |
| Gradient boosting | 59.0% | 58.8% | 91.6% |
| Logistic regression | 43.2% | 42.8% | 73.6% |

| Forecast horizon | Forecast | Same hour yesterday | Climatology (point x month x hour) |
|---|---|---|---|
| +1 h | 78.8% | 67.5% | 61.4% |
| +6 h | 71.8% | 67.5% | 61.4% |
| +12 h | 70.8% | 67.5% | 61.4% |
| +24 h | 70.1% | 67.5% | 61.4% |

Full tables: `results/model_comparison.csv`, `confusion_matrices.csv`, `forecast_evaluation.csv`, `gb_feature_importance.csv`, `forecast_feature_importance.csv`.

## Things you should know (limitations and findings)

1. **Timestamps are UTC.** Air temperature peaks at 09:00 and land-surface temperature at 07:00 in the file, i.e. about 14:30 and 12:30 IST.
   The dashboard and reports convert everything to IST (UTC+5:30); the CSV exports contain both. If your data was meant to be local time, change `Cfg.TZ_MIN` to 0.
2. **Only six grid points.** The static features (land use, building/road density, distances) are constant per point, so models treat them as location IDs.
   Consequently the simulator can only show a (small, inconsistent) response to green cover and about zero to the other levers. Treat it as an exploration tool,
   not a prediction of real cooling. More sample points (ward/pixel level) would fix this.
3. **The 28-feature classifier does not beat a lookup table.** A "point x month x hour" climatology scores 61.4% on the test period versus 58-59% for the models,
   because the feature set has no hour/month input. Adding time features is the quickest accuracy gain for the classifier (the forecaster already has them).
4. **UHI classes are relative.** They are quartile bands of the anomaly against the median of the six points, not absolute urban-minus-rural intensity.
5. `ndwi` and `ndbi` are essentially constant in the data and `distance_to_coast` looks too large for points near the Bay of Bengal - worth checking at the source.
6. Heat-risk bands follow the US NWS scale (not the Indian IMD scale), and all outputs are statistical, not official warnings.
7. Place names next to P1-P6 are approximate nearest-area hints (edit `Cfg.areaHint`).

### Neural-network forecasting experiment (updated)

The forecaster now trains a compact pure-Java feed-forward neural-network challenger using the same lagged UHI, weather, location, and forecast-horizon features as Gradient Boosting. It standardizes inputs using training data only, uses ReLU hidden layers and a softmax output, and applies early stopping against validation log-loss. The application selects the network only when its validation macro-F1 beats Gradient Boosting; otherwise it keeps Gradient Boosting as the production forecaster. This prevents an unverified architecture change from being treated as an improvement.

After the first run with the updated code, `results/forecast_model_comparison.csv` reports Gradient Boosting and neural-network accuracy and macro-F1 on the same held-out test rows for each horizon. Compare these results with the preserved `results/forecast_evaluation_baseline_gb.csv` baseline; improvements are not guaranteed. The updated first run retrains `forecast_gb.bin` because older serialized forecast models do not contain the neural-network challenger.

## Dashboard update: satellite map and full table headers

- The schematic "grid-point map" (Overview, Heat Map and Heat Risk pages) is now a geographic satellite map (Esri World Imagery). Each of the six grid points is drawn at its true latitude/longitude and still coloured by mean UHI anomaly (or heat-risk level on the Heat Risk page). Scroll to zoom, drag to pan, and use the +, -, Reset and Labels buttons. Hover a point for details.
- Imagery needs an internet connection the first time; tiles are cached in `~/.heatlens/tiles`, so viewed areas also work offline afterwards. Without a connection the markers are still shown at their true coordinates.
- All dashboard tables now size their columns to the full header text (and cell text) and stretch to fill the width; if the window is too narrow a horizontal scroll bar appears instead of clipping the headers.
