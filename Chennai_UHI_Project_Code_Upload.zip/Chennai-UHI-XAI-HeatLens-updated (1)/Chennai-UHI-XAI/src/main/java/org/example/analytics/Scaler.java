package org.example.analytics;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;

/** Z-score scaler fitted on the training split (same maths as FeatureScaler.java). */
public final class Scaler {
    public final double[] mean = new double[Cfg.NF];
    public final double[] std = new double[Cfg.NF];

    public static Scaler fit(DataStore ds) {
        Scaler s = new Scaler();
        long c = 0;
        for (int i = 0; i < ds.n; i++) {
            if (ds.split[i] != 0) continue;
            c++;
            for (int f = 0; f < Cfg.NF; f++) s.mean[f] += ds.x[i][f];
        }
        for (int f = 0; f < Cfg.NF; f++) s.mean[f] /= c;
        for (int i = 0; i < ds.n; i++) {
            if (ds.split[i] != 0) continue;
            for (int f = 0; f < Cfg.NF; f++) { double d = ds.x[i][f] - s.mean[f]; s.std[f] += d * d; }
        }
        for (int f = 0; f < Cfg.NF; f++) {
            s.std[f] = Math.sqrt(s.std[f] / c);
            if (s.std[f] < 1e-12) s.std[f] = 1.0;
        }
        return s;
    }

    public double[] scale(double[] raw) {
        double[] o = new double[Cfg.NF];
        for (int f = 0; f < Cfg.NF; f++) o[f] = (raw[f] - mean[f]) / std[f];
        return o;
    }

    public void save(Path file) throws IOException {
        StringBuilder sb = new StringBuilder("feature,mean,std\n");
        for (int f = 0; f < Cfg.NF; f++)
            sb.append(Cfg.FEATURES[f]).append(',').append(mean[f]).append(',').append(std[f]).append('\n');
        Files.createDirectories(file.getParent());
        Files.writeString(file, sb.toString());
    }

    public static Scaler load(Path file) throws IOException {
        List<String> lines = Files.readAllLines(file);
        Scaler s = new Scaler();
        for (int f = 0; f < Cfg.NF; f++) {
            String[] p = lines.get(f + 1).split(",");
            s.mean[f] = Double.parseDouble(p[1]);
            s.std[f] = Double.parseDouble(p[2]);
        }
        return s;
    }

    @Override public String toString() { return String.format(Locale.ROOT, "Scaler(%d features)", Cfg.NF); }
}
