package org.example.analytics;

import java.io.Serializable;
import java.util.Random;

/**
 * Pure-Java feed-forward classifier with the same layout as the DJL network (28-128-64-32-4, ReLU),
 * trained by {@link DnnTrainer} with Adam, dropout, learning-rate scheduling, early stopping and optional class weights.
 * Dropout is identity at inference time. Inputs are the standardised 28 features (same {@link Scaler} as the DJL model).
 */
public final class TunedDnn implements UhiClassifier, Logits, Serializable {
    private static final long serialVersionUID = 1L;

    public final int[] sizes;                 // e.g. {28,128,64,32,4}
    public final float[][][] w;               // [layer][out][in]
    public final float[][] b;                 // [layer][out]
    public String label = "DNN (tuned)";
    public DnnTrainer.Hyper hyper;
    public double trainSeconds;
    public int bestEpoch;
    /** Per-epoch history of the run that produced these weights. */
    public double[] histLr, histTrainLoss, histTrainAcc, histValLoss, histValAcc;

    TunedDnn(int[] sizes, Random rnd) {
        this.sizes = sizes.clone();
        int L = sizes.length - 1;
        w = new float[L][][]; b = new float[L][];
        for (int l = 0; l < L; l++) {
            w[l] = new float[sizes[l + 1]][sizes[l]];
            b[l] = new float[sizes[l + 1]];
            double sd = Math.sqrt(2.0 / sizes[l]);                  // He initialisation
            for (float[] row : w[l]) for (int i = 0; i < row.length; i++) row[i] = (float) (rnd.nextGaussian() * sd);
        }
    }

    @Override public String name() { return label; }

    @Override public double[] logits(double[] x) {
        float[] cur = new float[x.length];
        for (int i = 0; i < x.length; i++) cur[i] = (float) x[i];
        int L = w.length;
        for (int l = 0; l < L; l++) {
            float[] next = new float[w[l].length];
            for (int o = 0; o < next.length; o++) {
                float s = b[l][o];
                float[] row = w[l][o];
                for (int i = 0; i < row.length; i++) s += row[i] * cur[i];
                next[o] = (l < L - 1 && s < 0) ? 0f : s;
            }
            cur = next;
        }
        double[] z = new double[cur.length];
        for (int i = 0; i < z.length; i++) z[i] = cur[i];
        return z;
    }

    @Override public double[] predictProba(double[] x) {
        double[] z = logits(x);
        UhiClassifier.softmaxInPlace(z);
        return z;
    }

    TunedDnn copyWeights() {
        TunedDnn c = new TunedDnn(sizes, new Random(0));
        for (int l = 0; l < w.length; l++) {
            for (int o = 0; o < w[l].length; o++) System.arraycopy(w[l][o], 0, c.w[l][o], 0, w[l][o].length);
            System.arraycopy(b[l], 0, c.b[l], 0, b[l].length);
        }
        return c;
    }

    void loadWeights(TunedDnn s) {
        for (int l = 0; l < w.length; l++) {
            for (int o = 0; o < w[l].length; o++) System.arraycopy(s.w[l][o], 0, w[l][o], 0, w[l][o].length);
            System.arraycopy(s.b[l], 0, b[l], 0, b[l].length);
        }
    }
}
