package org.example.analytics;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;

/** In-memory copy of Chennai_UHI_Final.csv in column-friendly arrays. */
public final class DataStore {
    public static final LocalDateTime START = LocalDateTime.of(2024, 1, 1, 0, 0);

    public final int n;
    public final int nHours;
    public final int nLoc;
    public final double[][] x;          // raw 28 model features
    public final double[] lst, anomaly;
    public final int[] hourIdx, loc, cls, hour, month, year, split;
    public final int[][] rowAt;         // [hourIdx][loc] -> row
    public final double[] locLat, locLon;
    public final String[] locName, locShort;
    public final double[] classMeanAnomaly = new double[Cfg.NC];
    public final double[] heatIndex, adjHi;
    public final int[] risk;

    public DataStore(Path file) throws IOException {
        List<double[]> rawRows = new ArrayList<>(110_000);
        List<int[]> meta = new ArrayList<>(110_000);   // hourIdx, cls
        List<double[]> extra = new ArrayList<>(110_000); // lat, lon, lst, anomaly

        try (BufferedReader br = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String header = br.readLine();
            if (header != null && header.startsWith("\uFEFF")) header = header.substring(1);
            List<String> h = parse(header);
            int[] fi = new int[Cfg.NF];
            for (int f = 0; f < Cfg.NF; f++) fi[f] = idx(h, Cfg.FEATURES[f]);
            int iTs = idx(h, "timestamp"), iLst = idx(h, "land_surface_temperature"),
                    iAn = idx(h, "uhi_anomaly"), iCl = idx(h, "UHI_Class");
            String line;
            while ((line = br.readLine()) != null) {
                if (line.isEmpty()) continue;
                List<String> c = parse(line);
                double[] r = new double[Cfg.NF];
                for (int f = 0; f < Cfg.NF; f++) r[f] = num(c.get(fi[f]));
                String ts = c.get(iTs);
                LocalDateTime dt = LocalDateTime.of(Integer.parseInt(ts.substring(6, 10)),
                        Integer.parseInt(ts.substring(3, 5)), Integer.parseInt(ts.substring(0, 2)),
                        Integer.parseInt(ts.substring(11, 13)), 0);
                int hi = (int) java.time.temporal.ChronoUnit.HOURS.between(START, dt);
                int k = switch (c.get(iCl).trim()) {
                    case "Low" -> 0; case "Moderate" -> 1; case "High" -> 2; default -> 3;
                };
                rawRows.add(r);
                meta.add(new int[]{hi, k});
                extra.add(new double[]{r[0], r[1], num(c.get(iLst)), num(c.get(iAn))});
            }
        }
        n = rawRows.size();
        x = rawRows.toArray(new double[0][]);
        hourIdx = new int[n]; cls = new int[n]; loc = new int[n];
        hour = new int[n]; month = new int[n]; year = new int[n]; split = new int[n];
        lst = new double[n]; anomaly = new double[n];

        TreeSet<Long> keys = new TreeSet<>();
        for (double[] e : extra) keys.add(Math.round(e[0] * 1000) * 100000L + Math.round(e[1] * 1000));
        Long[] ks = keys.toArray(new Long[0]);
        nLoc = ks.length;
        locLat = new double[nLoc]; locLon = new double[nLoc];
        locName = new String[nLoc]; locShort = new String[nLoc];
        int maxHour = 0;
        for (int i = 0; i < n; i++) {
            hourIdx[i] = meta.get(i)[0];
            cls[i] = meta.get(i)[1];
            maxHour = Math.max(maxHour, hourIdx[i]);
            long key = Math.round(extra.get(i)[0] * 1000) * 100000L + Math.round(extra.get(i)[1] * 1000);
            loc[i] = Arrays.binarySearch(ks, key);
            locLat[loc[i]] = extra.get(i)[0];
            locLon[loc[i]] = extra.get(i)[1];
            lst[i] = extra.get(i)[2];
            anomaly[i] = extra.get(i)[3];
            LocalDateTime dt = START.plusHours(hourIdx[i]);
            hour[i] = dt.getHour(); month[i] = dt.getMonthValue() - 1; year[i] = dt.getYear();
            split[i] = year[i] == 2024 ? 0 : (month[i] <= 5 ? 1 : 2);
        }
        for (int l = 0; l < nLoc; l++) {
            locShort[l] = "P" + (l + 1);
            String hint = Cfg.areaHint(locLat[l], locLon[l]);
            locName[l] = String.format(Locale.ROOT, "P%d  %.2f\u00B0N, %.2f\u00B0E%s", l + 1, locLat[l], locLon[l],
                    hint.isEmpty() ? "" : "  (" + hint + ")");
        }
        nHours = maxHour + 1;
        rowAt = new int[nHours][nLoc];
        for (int[] r : rowAt) Arrays.fill(r, -1);
        for (int i = 0; i < n; i++) rowAt[hourIdx[i]][loc[i]] = i;

        double[] sum = new double[Cfg.NC]; long[] cnt = new long[Cfg.NC];
        for (int i = 0; i < n; i++) if (split[i] == 0) { sum[cls[i]] += anomaly[i]; cnt[cls[i]]++; }
        for (int c = 0; c < Cfg.NC; c++) classMeanAnomaly[c] = cnt[c] == 0 ? 0 : sum[c] / cnt[c];

        heatIndex = new double[n]; adjHi = new double[n]; risk = new int[n];
        for (int i = 0; i < n; i++) {
            heatIndex[i] = HeatRisk.heatIndexC(x[i][Cfg.F_AIR_T], x[i][Cfg.F_RH]);
            adjHi[i] = heatIndex[i] + anomaly[i];
            risk[i] = HeatRisk.level(adjHi[i]);
        }
    }

    public LocalDateTime time(int hourIndex) { return START.plusHours(hourIndex); }

    public double anomalyAt(int t, int l) {
        int r = rowAt[Math.max(0, Math.min(nHours - 1, t))][l];
        return r < 0 ? 0 : anomaly[r];
    }

    public int rowAtClamped(int t, int l) {
        return rowAt[Math.max(0, Math.min(nHours - 1, t))][l];
    }

    private static int idx(List<String> h, String name) {
        int i = h.indexOf(name);
        if (i < 0) throw new IllegalStateException("Column not found in CSV: " + name);
        return i;
    }

    private static double num(String s) { return Double.parseDouble(s.trim().replace(",", "")); }

    /** Minimal CSV line parser (handles quoted fields such as "65,90,000"). */
    static List<String> parse(String line) {
        List<String> out = new ArrayList<>(48);
        StringBuilder sb = new StringBuilder();
        boolean q = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (q) {
                if (ch == '"') {
                    if (i + 1 < line.length() && line.charAt(i + 1) == '"') { sb.append('"'); i++; } else q = false;
                } else sb.append(ch);
            } else if (ch == '"') q = true;
            else if (ch == ',') { out.add(sb.toString()); sb.setLength(0); }
            else sb.append(ch);
        }
        out.add(sb.toString());
        return out;
    }
}
