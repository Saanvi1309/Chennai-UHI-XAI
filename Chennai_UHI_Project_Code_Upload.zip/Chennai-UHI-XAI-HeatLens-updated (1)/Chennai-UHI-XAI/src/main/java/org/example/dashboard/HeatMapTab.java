package org.example.dashboard;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import org.example.analytics.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Heat map page: measured grid points, rankings, seasonal / monthly / day-night patterns, hotspots and environmental relationships. */
final class HeatMapTab extends ScrollPane {
    private final AppState st;
    private final MapCanvas map;
    private final TableView<String[]> rank = Ui.table(new String[]{"Rank", "Point", "Area", "Mean LST \u00B0C", "Mean air \u00B0C", "Anomaly \u00B0C", "Extreme", "High+Extreme", "Danger+"},
            new double[]{45, 45, 170, 85, 85, 80, 70, 100, 70});
    private final TableView<String[]> dayNight = Ui.table(new String[]{"Point", "Period", "Hours", "Mean anomaly \u00B0C", "Extreme share"}, new double[]{60, 190, 80, 130, 110});
    private final BarChart<String, Number> season = new BarChart<>(new CategoryAxis(), new NumberAxis());
    private final StackedBarChart<String, Number> monthly = new StackedBarChart<>(new CategoryAxis(), new NumberAxis(0, 100, 25));
    private final ComboBox<String> corrMode = new ComboBox<>();
    private final Canvas corr = new Canvas(760, 470);

    HeatMapTab(AppState st) {
        this.st = st;
        map = new MapCanvas(st, 560, 400, false);
        Label how = Ui.note("The dataset has six measured grid points (about 0.25\u00B0 apart). Everything here is computed from those observations - nothing is interpolated between points, "
                + "so the map shows measured cells only. UHI anomaly = land surface temperature minus the median of the six points at the same hour. Tables and charts follow the filters on the left.");
        how.getStyleClass().add("banner");
        season.setAnimated(false); season.setPrefHeight(300); season.setCategoryGap(18);
        ((NumberAxis) season.getYAxis()).setLabel("Mean UHI anomaly (\u00B0C)");
        monthly.setAnimated(false); monthly.setPrefHeight(300); monthly.setCategoryGap(2);
        ((NumberAxis) monthly.getYAxis()).setLabel("% of hours");
        corrMode.getItems().addAll("Within-location (removes location differences)", "Pooled (all rows)");
        corrMode.getSelectionModel().select(0);
        corrMode.valueProperty().addListener((o, a, b) -> drawCorr());

        VBox cMap = Ui.pngCard("Measured heat map (Low / Moderate / High / Extreme)", "Satellite imagery (Esri World Imagery; internet needed the first time, then cached). Colour = mean anomaly (red warmer, blue cooler); size = share of Extreme hours. Hover for details; scroll to zoom, drag to pan.", map, "heat_map");
        VBox cRank = Ui.card("Location-wise ranking and heat-risk rank", "Rank 1 = highest exposure (mean of the ranks of mean anomaly, Extreme share, Danger+ share and adjusted heat index).", rank);
        VBox cSeason = Ui.card("Seasonal heat-risk trends", "Mean UHI anomaly by season (IMD seasons) and grid point.", new VBox(6, season, Ui.legend(Ui.LOC_COLORS, st.ds.locShort)));
        VBox cMonth = Ui.card("Monthly UHI category distribution", "Share of hours in each UHI class per calendar month (rows in view).", new VBox(6, monthly, Ui.legend(Palette.CLASS, Cfg.CLASS_NAMES)));
        VBox cDay = Ui.card("Day vs night", "Day = 06:30-17:30 IST, night = the rest.", dayNight);
        TableView<String[]> hot = Ui.csvTable("hotspot_persistence.csv", new int[]{0, 1, 2, 3, 4, 6, 7, 8}, new String[]{"Point", "Area", "Mean anomaly \u00B0C", "Extreme share", "Months in top-2 (of 24)", "Rank 2024", "Rank 2025", "Verdict"},
                new double[]{45, 170, 110, 90, 150, 80, 80, 170}, null);
        hot.getItems().forEach(r -> r[3] = Ui.p1(r[3]));
        VBox cHot = Ui.card("Persistent hotspot analysis (2024-2025)", "Persistent = among the two warmest of the six points in at least half of the 24 months and in the top two in both years.", hot);
        VBox cCorr = Ui.pngCard("Environmental relationships (correlation matrix)", "LST, UHI anomaly, weather, vegetation and built-up indicators. Static features are constant per grid point, so only six independent locations support them - read those cells as indicative.", new VBox(6, corrMode, corr), "correlation_matrix");
        TableView<String[]> loc = Ui.csvTable("location_level_correlation.csv", new int[]{0, 1, 2}, new String[]{"Static feature", "Spearman with mean anomaly", "Locations (n)"}, new double[]{200, 200, 110}, null);
        VBox cLoc = Ui.card("Built-up / land-cover vs heat across the six points", "Rank correlation of each static feature with the grid point's mean anomaly. n = 6, so no significance is claimed.", loc);
        TableView<String[]> err = Ui.csvTable("eval_by_location.csv", new int[]{2, 3, 4, 5, 7, 8}, new String[]{"Point", "Rows", "DNN accuracy", "Macro-F1", "Anomaly MAE \u00B0C", "Anomaly bias \u00B0C"},
                new double[]{60, 80, 110, 100, 120, 120}, r -> r[0].equals(st.ms.primary.name()) && r[1].equals("test"));
        err.getItems().forEach(r -> { r[2] = Ui.p1(r[2]); r[3] = Ui.p1(r[3]); });
        VBox cErr = Ui.card("Spatial distribution of prediction errors (" + st.ms.primary.name() + ", test period)", "Where the DNN is weaker. Positive bias = model over-estimates the anomaly.", err);

        setContent(Ui.page(how, Ui.row(cMap, cRank), Ui.row(cSeason, cMonth), Ui.row(cDay, cHot), cCorr, Ui.row(cLoc, cErr)));
        setFitToWidth(true);
        getStyleClass().add("page-scroll");
        st.onView(this::update);
        st.dark.addListener((o, a, b) -> drawCorr());
    }

    private void update() {
        DataStore ds = st.ds;
        map.draw();
        UrbanAnalytics.LocAgg[] agg = UrbanAnalytics.aggregate(ds, st.rows);
        UrbanAnalytics.RiskRank[] rr = UrbanAnalytics.riskRanking(ds, st.rows);
        List<String[]> rows = new ArrayList<>();
        Integer[] order = new Integer[ds.nLoc];
        for (int i = 0; i < order.length; i++) order[i] = i;
        java.util.Arrays.sort(order, (a, b) -> Integer.compare(rr[a].rank(), rr[b].rank()));
        for (int l : order) if (agg[l].n > 0)
            rows.add(new String[]{String.valueOf(rr[l].rank()), ds.locShort[l], Cfg.areaHint(ds.locLat[l], ds.locLon[l]), Ui.num(agg[l].lst, 2), Ui.num(agg[l].air, 2),
                    String.format(Locale.ROOT, "%+.2f", agg[l].anomaly), Ui.pct(agg[l].extremeShare), Ui.pct(agg[l].highPlusShare), Ui.pct(agg[l].dangerShare)});
        Ui.fill(rank, rows);

        // seasonal bars
        double[][] ss = new double[ds.nLoc][4]; int[][] sn = new int[ds.nLoc][4];
        double[][] mc = new double[12][4]; int[] mn = new int[12];
        for (int r : st.rows) {
            int s = UrbanAnalytics.season(ds.month[r]);
            ss[ds.loc[r]][s] += ds.anomaly[r]; sn[ds.loc[r]][s]++;
            mc[ds.month[r]][ds.cls[r]]++; mn[ds.month[r]]++;
        }
        List<XYChart.Series<String, Number>> sl = new ArrayList<>();
        for (int l = 0; l < ds.nLoc; l++) {
            XYChart.Series<String, Number> s = new XYChart.Series<>();
            s.setName(ds.locShort[l]);
            for (int k = 0; k < 4; k++) s.getData().add(new XYChart.Data<>(UrbanAnalytics.SEASONS[k].split(" \\(")[0], sn[l][k] == 0 ? 0 : ss[l][k] / sn[l][k]));
            sl.add(s);
        }
        season.getData().setAll(sl);
        List<int[]> dummy = new ArrayList<>();
        Ui.colorSeriesBars(season, Ui.LOC_COLORS);
        List<XYChart.Series<String, Number>> ml = new ArrayList<>();
        for (int c = 0; c < Cfg.NC; c++) {
            XYChart.Series<String, Number> s = new XYChart.Series<>();
            s.setName(Cfg.CLASS_NAMES[c]);
            for (int m = 0; m < 12; m++) s.getData().add(new XYChart.Data<>(Ui.MONTHS[m], mn[m] == 0 ? 0 : mc[m][c] / mn[m] * 100));
            ml.add(s);
        }
        monthly.getData().setAll(ml);
        Ui.colorSeriesBars(monthly, Palette.CLASS);

        // day / night
        List<String[]> dn = new ArrayList<>();
        for (int l = 0; l < ds.nLoc; l++) for (int p = 0; p < 2; p++) {
            int n = 0, ext = 0; double a = 0;
            for (int r : st.rows) if (ds.loc[r] == l && UrbanAnalytics.isDay(ds.hour[r]) == (p == 0)) { n++; a += ds.anomaly[r]; if (ds.cls[r] == 3) ext++; }
            if (n > 0) dn.add(new String[]{ds.locShort[l], p == 0 ? "Day (06:30-17:30 IST)" : "Night (17:30-06:30 IST)", String.format(Locale.ROOT, "%,d", n), String.format(Locale.ROOT, "%+.2f", a / n), Ui.pct((double) ext / n)});
        }
        Ui.fill(dayNight, dn);
        drawCorr();
    }

    private void drawCorr() {
        GraphicsContext g = corr.getGraphicsContext2D();
        g.clearRect(0, 0, corr.getWidth(), corr.getHeight());
        if (st.rows == null || st.rows.length < 100) return;
        boolean within = corrMode.getSelectionModel().getSelectedIndex() == 0;
        double[][] c = UrbanAnalytics.correlation(st.ds, st.rows, within);
        int V = c.length;
        double cell = 26, x0 = 200, y0 = 12;
        boolean dark = st.dark.get();
        g.setFont(Font.font(10));
        for (int a = 0; a < V; a++) {
            g.setFill(dark ? Color.web("#E5E7EB") : Color.web("#111827"));
            g.setTextAlign(TextAlignment.RIGHT);
            g.fillText(Cfg.prettyFeature(UrbanAnalytics.CORR_VARS[a]), x0 - 6, y0 + a * cell + 17);
            for (int b = 0; b < V; b++) {
                double v = c[a][b];
                g.setFill(Double.isNaN(v) ? Color.web("#9CA3AF") : Ui.color(Palette.diverging(v, 1.0)));
                g.fillRect(x0 + b * cell, y0 + a * cell, cell - 1, cell - 1);
                if (!Double.isNaN(v) && V <= 15) {
                    g.setFill(Color.web("#111827")); g.setTextAlign(TextAlignment.CENTER);
                    g.fillText(String.format(Locale.ROOT, "%.1f", v).replace("0.", ".").replace("-.", "-."), x0 + b * cell + cell / 2, y0 + a * cell + 16);
                }
            }
        }
        g.setFill(dark ? Color.web("#94A3B8") : Color.web("#6B7280")); g.setTextAlign(TextAlignment.LEFT);
        g.fillText("Columns follow the same order as the rows. Grey = constant within the selection (no correlation defined).", 10, y0 + V * cell + 22);
    }
}
