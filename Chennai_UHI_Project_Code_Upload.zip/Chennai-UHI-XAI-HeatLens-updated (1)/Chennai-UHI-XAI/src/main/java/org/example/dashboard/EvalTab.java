package org.example.dashboard;

import javafx.scene.control.*;
import javafx.scene.layout.*;
import org.example.analytics.*;

import java.util.List;

/** Model Performance Analysis page: extended metrics, per-class results, timing and the five written answers. */
final class EvalTab extends ScrollPane {
    EvalTab(AppState st) {
        Label how = Ui.note("Model selection uses the validation split only; the test split (Jul-Dec 2025) is reserved for these final scores. Numeric error is for the probability-weighted UHI anomaly (\u00B0C): "
                + "expected anomaly = sum of class probability x training class-mean anomaly, compared with the observed anomaly. Training time of the DJL network was not recorded by the original code.");
        how.getStyleClass().add("banner");
        String[] hd = {"Model", "Split", "Rows", "Accuracy", "Macro-P", "Macro-R", "Macro-F1", "Weighted-F1", "\u00B11 class", "ROC-AUC (OvR)", "Log-loss", "Log-loss scaled", "ECE", "ECE scaled", "Brier"};
        TableView<String[]> t1 = Ui.csvTable("eval_summary.csv", new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14}, hd,
                new double[]{130, 80, 65, 75, 70, 70, 75, 90, 70, 100, 70, 100, 60, 80, 60}, null);
        t1.getItems().forEach(r -> { for (int i : new int[]{3, 4, 5, 6, 7, 8}) r[i] = Ui.p1(r[i]); for (int i : new int[]{9, 10, 11, 12, 13, 14}) r[i] = Ui.d3(r[i]); });
        TableView<String[]> t2 = Ui.csvTable("eval_summary.csv", new int[]{0, 1, 15, 16, 17, 18, 19, 20}, new String[]{"Model", "Split", "Anomaly MAE \u00B0C", "RMSE \u00B0C", "R\u00B2", "Bias \u00B0C", "Training s", "Inference \u00B5s/row"},
                new double[]{130, 80, 110, 90, 80, 80, 100, 120}, null);
        t2.getItems().forEach(r -> { for (int i : new int[]{2, 3, 4, 5}) r[i] = Ui.d3(r[i]); });
        TableView<String[]> t3 = Ui.csvTable("eval_per_class.csv", new int[]{0, 1, 2, 3, 4, 5, 6, 7}, new String[]{"Model", "Split", "Class", "Support", "Precision", "Recall", "F1", "ROC-AUC"},
                new double[]{130, 80, 90, 80, 90, 80, 80, 90}, r -> r[1].equals("test"));
        t3.getItems().forEach(r -> { for (int i : new int[]{4, 5, 6}) r[i] = Ui.p1(r[i]); r[7] = Ui.d3(r[7]); });
        t1.setPrefHeight(300); t3.setPrefHeight(420);
        Label analysis = new Label(Results.text(AnalysisRunner.MARKER));
        analysis.setWrapText(true);
        VBox cA = Ui.card("Which model is best? Where does it fail? Does it generalise?", "Generated from the computed metrics when the analysis was run.", analysis);
        VBox c1 = Ui.card("Classification metrics (all models, validation and test)", null, t1);
        VBox c2 = Ui.card("Numeric UHI-anomaly error, training and inference time", "Gradient boosting / logistic regression times were re-measured in memory with the same settings.", t2);
        VBox c3 = Ui.card("Per-class precision, recall, F1 and ROC-AUC (test)", null, t3);
        setContent(Ui.page(how, cA, c1, c2, c3));
        setFitToWidth(true);
        getStyleClass().add("page-scroll");
    }
}
