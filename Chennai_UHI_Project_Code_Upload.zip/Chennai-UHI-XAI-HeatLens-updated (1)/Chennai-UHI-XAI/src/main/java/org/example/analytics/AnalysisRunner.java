package org.example.analytics;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * Computes every result file used by the dashboard's evaluation, XAI, forecasting, urban-heat and planning pages and writes
 * them to results/. Nothing is typed in by hand: all numbers come from the loaded models and the unchanged dataset.
 * Run as a program (org.example.analytics.AnalysisRunner) or let the dashboard call ensure() on first start.
 */
public final class AnalysisRunner {
    private AnalysisRunner() {}

    public static final String MARKER = "model_performance_analysis.txt";

    public static boolean upToDate() { return Files.exists(Cfg.results().resolve(MARKER)) && Files.exists(Cfg.results().resolve("xai_global_importance.csv")); }

    /** Computes everything if the marker file is missing (first run). ms.computePredictions must already have been called. */
    public static void ensure(DataStore ds, ModelSuite ms, Consumer<String> log) throws IOException {
        if (!upToDate()) runAll(ds, ms, log);
    }

    public static void runAll(DataStore ds, ModelSuite ms, Consumer<String> log) throws IOException {
        Path dir = Cfg.results();
        Files.createDirectories(dir);
        say(log, "Checking timestamp alignment...");
        TimeAlignment.write(ds, dir);

        say(log, "Measuring training times (logistic regression and gradient boosting are re-trained in memory for timing only)...");
        double[] trainSec = trainingSeconds(ds, ms);

        say(log, "Evaluating every classifier (per-class metrics, ROC-AUC, calibration, errors by location)...");
        ModelEval.writeAll(ds, ms, dir, trainSec);
        ms.writeResults(ds, dir);

        say(log, "Evaluating the 1-24 h forecaster on the test period...");
        ForecastAnalysis.H[] fh = ForecastAnalysis.run(ds, ms.forecast, 2);
        ForecastAnalysis.write(ds, ms.forecast, dir, fh);

        say(log, "Computing Shapley attributions on the DNN weights (" + ms.primary.name() + ")...");
        Xai.Global g = Xai.global(ms.primary, ds, ms.scaler, 300, Xai.PERMS, 2026);
        Xai.writeGlobal(g, ds, ms.scaler, ms.primary, dir);

        say(log, "Urban-heat analytics and planning priorities...");
        UrbanAnalytics.write(ds, dir);
        PlanningEngine.write(ds, ms, dir);

        Files.writeString(dir.resolve(MARKER), performanceAnalysis(ds, ms, fh));
        say(log, "Analysis files written to " + dir);
    }

    private static double[] trainingSeconds(DataStore ds, ModelSuite ms) throws IOException {
        Path f = Cfg.results().resolve("training_time.csv");
        double[] out = new double[ms.models.length];
        java.util.Arrays.fill(out, Double.NaN);
        java.util.Map<String, Double> known = new java.util.HashMap<>();
        if (Files.exists(f)) for (String ln : Files.readAllLines(f).subList(1, Files.readAllLines(f).size())) {
            String[] p = ln.split(",");
            try { known.put(p[0], Double.parseDouble(p[1])); } catch (Exception ignored) { }
        }
        for (int m = 0; m < ms.models.length; m++) {
            String n = ms.modelNames[m];
            if (ms.models[m] instanceof TunedDnn t) { out[m] = t.trainSeconds; continue; }
            if (n.equals("DNN")) continue;                               // DJL training time was not recorded by the original code
            if (known.containsKey(n)) { out[m] = known.get(n); continue; }
            double[][] xtr = ModelSuite.rows(ds, ms.scaler, 0), xv = ModelSuite.rows(ds, ms.scaler, 1);
            int[] ytr = ModelSuite.labels(ds, 0), yv = ModelSuite.labels(ds, 1);
            long t0 = System.nanoTime();
            if (ms.models[m] instanceof LogisticModel) LogisticModel.fit(xtr, ytr, Cfg.NC, 300, 0.05, 1e-4);
            else GradientBoostedModel.fit(xtr, ytr, xv, yv, Cfg.NC, new GradientBoostedModel.Params(), null);
            out[m] = (System.nanoTime() - t0) / 1e9;
        }
        StringBuilder sb = new StringBuilder("model,train_seconds,note\n");
        for (int m = 0; m < ms.models.length; m++)
            sb.append(ms.modelNames[m]).append(',').append(Double.isNaN(out[m]) ? "n/a" : String.format(Locale.ROOT, "%.1f", out[m]))
                    .append(',').append(Double.isNaN(out[m]) ? "DJL training time was not recorded" : ms.models[m] instanceof TunedDnn ? "recorded during TuneDnn" : "re-trained in memory for timing (same settings), one CPU core").append('\n');
        Files.writeString(f, sb.toString());
        return out;
    }

    // ------------------------------------------------------------------ the five analysis questions

    static String performanceAnalysis(DataStore ds, ModelSuite ms, ForecastAnalysis.H[] fh) {
        StringBuilder sb = new StringBuilder();
        int M = ms.models.length;
        ModelEval.Report[] val = new ModelEval.Report[M], test = new ModelEval.Report[M];
        for (int m = 0; m < M; m++) { val[m] = ModelEval.report(ds, ms, m, 1, null); test[m] = ModelEval.report(ds, ms, m, 2, null); }
        int bv = 0, bt = 0;
        for (int m = 1; m < M; m++) { if (val[m].macroF1 > val[bv].macroF1) bv = m; if (test[m].macroF1 > test[bt].macroF1) bt = m; }
        int pm = ms.indexOf(ms.primary.name());
        ModelEval.Report p = test[pm];

        sb.append("MODEL PERFORMANCE ANALYSIS (all figures are computed from the trained models; test = Jul-Dec 2025)\n\n");
        sb.append("1. Which model performs best?\n");
        sb.append(String.format(Locale.ROOT, "   Model selection uses VALIDATION data only (Jan-Jun 2025): best validation macro-F1 is %s (%.3f). ", ms.modelNames[bv], val[bv].macroF1));
        sb.append(String.format(Locale.ROOT, "On the untouched test period the highest macro-F1 is %s (%.3f). ", ms.modelNames[bt], test[bt].macroF1));
        sb.append("Test macro-F1 by model: ");
        for (int m = 0; m < M; m++) sb.append(String.format(Locale.ROOT, "%s %.3f%s", ms.modelNames[m], test[m].macroF1, m + 1 < M ? ", " : ".\n"));
        sb.append("   Models within 0.01 macro-F1 of the best test score are effectively tied: ");
        boolean any = false;
        for (int m = 0; m < M; m++) if (test[bt].macroF1 - test[m].macroF1 <= 0.01) { sb.append(any ? ", " : "").append(ms.modelNames[m]); any = true; }
        sb.append(". Hourly observations are strongly autocorrelated, so small gaps are not evidence of a real difference.\n");
        sb.append("   ").append(ms.primaryNote).append(".\n\n");

        int hard = 0;
        for (int c = 1; c < Cfg.NC; c++) if (p.f1[c] < p.f1[hard]) hard = c;
        sb.append("2. Which UHI category is hardest to predict?\n");
        sb.append(String.format(Locale.ROOT, "   For %s on the test period the lowest F1 is %s (F1 %.3f, precision %.3f, recall %.3f); F1 by class: ", p.model, Cfg.CLASS_NAMES[hard], p.f1[hard], p.precision[hard], p.recall[hard]));
        for (int c = 0; c < Cfg.NC; c++) sb.append(String.format(Locale.ROOT, "%s %.3f%s", Cfg.CLASS_NAMES[c], p.f1[c], c + 1 < Cfg.NC ? ", " : ".\n\n"));

        sb.append("3. Where does the DNN make mistakes?\n");
        int bi = 0, bj = 1; long bestOff = -1, wrong = 0, adjWrong = 0;
        for (int i = 0; i < Cfg.NC; i++) for (int j = 0; j < Cfg.NC; j++) if (i != j) {
            wrong += p.cm[i][j]; if (Math.abs(i - j) == 1) adjWrong += p.cm[i][j];
            if (p.cm[i][j] > bestOff) { bestOff = p.cm[i][j]; bi = i; bj = j; }
        }
        sb.append(String.format(Locale.ROOT, "   %.0f%% of the errors are to a neighbouring class; the most frequent confusion is actual %s predicted as %s (%d rows). ",
                wrong == 0 ? 0 : 100.0 * adjWrong / wrong, Cfg.CLASS_NAMES[bi], Cfg.CLASS_NAMES[bj], bestOff));
        int worstL = 0, bestL = 0; double[] la = new double[ds.nLoc];
        for (int l = 0; l < ds.nLoc; l++) { boolean[] mk = new boolean[ds.nLoc]; mk[l] = true; la[l] = ModelEval.report(ds, ms, pm, 2, mk).accuracy; if (la[l] < la[worstL]) worstL = l; if (la[l] > la[bestL]) bestL = l; }
        sb.append(String.format(Locale.ROOT, "Accuracy is lowest at %s (%.1f%%) and highest at %s (%.1f%%). ", ds.locShort[worstL], la[worstL] * 100, ds.locShort[bestL], la[bestL] * 100));
        double[] ma = new double[12]; int[] mn = new int[12];
        for (int i = 0; i < ds.n; i++) if (ds.split[i] == 2) { mn[ds.month[i]]++; if (ModelEval.argmax(ms.proba[pm][i]) == ds.cls[i]) ma[ds.month[i]]++; }
        int wm = -1, bm = -1;
        for (int m = 0; m < 12; m++) if (mn[m] > 0) { ma[m] /= mn[m]; if (wm < 0 || ma[m] < ma[wm]) wm = m; if (bm < 0 || ma[m] > ma[bm]) bm = m; }
        String[] MN = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        if (wm >= 0) sb.append(String.format(Locale.ROOT, "Among test months, accuracy is lowest in %s (%.1f%%) and highest in %s (%.1f%%).\n\n", MN[wm], ma[wm] * 100, MN[bm], ma[bm] * 100));

        sb.append("4. Does the DNN generalise to the test period?\n");
        double trAcc = Double.NaN;
        int[][] cm = new int[Cfg.NC][Cfg.NC];
        for (int i = 0; i < ds.n; i += 5) if (ds.split[i] == 0) cm[ds.cls[i]][ms.models[pm].predict(ms.scaler.scale(ds.x[i]))]++;
        trAcc = new Metrics(cm).accuracy();
        sb.append(String.format(Locale.ROOT, "   %s accuracy: training (2024) %.1f%%, validation (Jan-Jun 2025) %.1f%%, test (Jul-Dec 2025) %.1f%%. ", p.model, trAcc * 100, val[pm].accuracy * 100, p.accuracy * 100));
        sb.append(String.format(Locale.ROOT, "The %.1f-point drop from validation to test is a distribution shift between the two periods (they also cover different months, so season and time are mixed); this analysis does not isolate the cause. ",
                (val[pm].accuracy - p.accuracy) * 100));
        sb.append("Quote the test figure as the honest estimate for new data.\n\n");

        sb.append("5. How does forecasting performance change with time horizon?\n   ");
        for (ForecastAnalysis.H h : fh)
            sb.append(String.format(Locale.ROOT, "+%dh: accuracy %.1f%%, air-temperature MAE %.2f C%s", h.h, h.acc * 100, h.tMae, h == fh[fh.length - 1] ? ".\n" : "; "));
        sb.append(String.format(Locale.ROOT, "   Accuracy changes by %.1f points between +1 h and +24 h; the air-temperature forecast is a climatology + decaying-persistence model, not the neural network.\n", (fh[0].acc - fh[fh.length - 1].acc) * 100));
        return sb.toString();
    }

    private static void say(Consumer<String> log, String s) { if (log != null) log.accept(s); }

    public static void main(String[] args) throws Exception {
        long t0 = System.currentTimeMillis();
        System.out.println("Project root: " + Cfg.root());
        DataStore ds = new DataStore(Cfg.data());
        ModelSuite ms = ModelSuite.loadOrTrain(ds, System.out::println);
        ms.computePredictions(ds);
        runAll(ds, ms, System.out::println);
        System.out.println("Done in " + (System.currentTimeMillis() - t0) / 1000 + " s");
    }
}
