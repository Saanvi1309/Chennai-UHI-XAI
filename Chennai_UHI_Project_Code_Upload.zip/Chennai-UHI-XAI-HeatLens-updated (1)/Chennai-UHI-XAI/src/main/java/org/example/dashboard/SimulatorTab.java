package org.example.dashboard;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.util.Duration;
import org.example.analytics.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Mitigation what-if simulator: edit green cover / building / road / water features and re-predict the UHI class. */
final class SimulatorTab extends ScrollPane {
    private final AppState st;
    private final ComboBox<String> model = new ComboBox<>();
    private final CheckBox[] loc = new CheckBox[6];
    private final Slider green = slider(), build = slider(), road = slider(), water = slider();
    private final Label gl = new Label(), bl = new Label(), rl = new Label(), wl = new Label();
    private final Ui.Kpi kDelta = new Ui.Kpi("UHI CHANGE", Palette.TEAL).compact(), kExt = new Ui.Kpi("EXTREME SHARE", Palette.CLASS[3]).compact(),
            kDan = new Ui.Kpi("DANGER+ SHARE", Palette.RISK[3]).compact(), kHi = new Ui.Kpi("HEAT-INDEX CHANGE", Palette.RISK[2]).compact();
    private final BarChart<String, Number> classChart = new BarChart<>(new CategoryAxis(), new NumberAxis());
    private final BarChart<String, Number> locChart = new BarChart<>(new CategoryAxis(), new NumberAxis());
    private final LineChart<Number, Number> sweep = new LineChart<>(new NumberAxis(0, 100, 10), new NumberAxis());
    private final TableView<String[]> levers = Ui.table(new String[]{"Lever (set to 100%)", "DNN", "DNN (tuned)", "Gradient boosting", "Logistic regression"}, new double[]{220, 80, 100, 130, 140});
    private final Label status = Ui.label("", "note");
    private final PauseTransition debounce = new PauseTransition(Duration.millis(260)), sweepDebounce = new PauseTransition(Duration.millis(700));
    private boolean leversDone;
    private long sweepToken;

    SimulatorTab(AppState st) {
        this.st = st;
        DataStore ds = st.ds;
        model.getItems().addAll(st.ms.modelNames);
        model.setValue(st.ms.primary.name());
        model.valueProperty().addListener((o, a, b) -> trigger());
        green.setValue(40);

        VBox controls = new VBox(8);
        controls.setPadding(new Insets(2));
        controls.setPrefWidth(300);
        controls.getChildren().addAll(Ui.label("MODEL", "side-h"), model, Ui.label("APPLY TO GRID POINTS", "side-h"));
        for (int l = 0; l < ds.nLoc; l++) {
            String hint = Cfg.areaHint(ds.locLat[l], ds.locLon[l]);
            loc[l] = new CheckBox(ds.locShort[l] + (hint.isEmpty() ? "" : "  " + hint));
            loc[l].setTooltip(new Tooltip(ds.locName[l]));
            loc[l].setSelected(l == 3);
            loc[l].selectedProperty().addListener((o, a, b) -> trigger());
            controls.getChildren().add(loc[l]);
        }
        controls.getChildren().addAll(Ui.label("INTERVENTIONS", "side-h"),
                lever("Green cover increase", green, gl), lever("Building density reduction", build, bl),
                lever("Road density reduction", road, rl), lever("Closer to water (distance cut)", water, wl));
        FlowPane presets = new FlowPane(6, 6);
        presets.getChildren().addAll(preset("Tree-planting drive", 60, 0, 0, 0), preset("Cool roofs + de-paving", 0, 40, 40, 0),
                preset("Everything at 50%", 50, 50, 50, 50), preset("Reset", 0, 0, 0, 0));
        controls.getChildren().addAll(Ui.label("PRESETS", "side-h"), presets);
        for (Slider s : List.of(green, build, road, water)) s.valueProperty().addListener((o, a, b) -> { updateLabels(); trigger(); });
        updateLabels();

        Label warn = new Label("How to read this: the models are statistical, not physical. The dataset has only six grid points, and building density, road density and water distance never change over time inside a point, "
                + "so the models cannot learn a real response to them (they show \u2248 0 below). Green cover (NDVI) does vary over time, but the response the models give it is small and not consistent across points "
                + "(typically under 0.1 \u00B0C, sometimes even warmer). Logistic regression extrapolates linearly and overreacts. Use this tab to see how the models behave and to explore scenarios - "
                + "not as a prediction of real-world cooling. Ward- or pixel-level data with many sample points would be needed for quantitative estimates.");
        warn.setWrapText(true);
        VBox banner = new VBox(warn);
        banner.getStyleClass().add("banner");

        HBox kp = new HBox(12, kDelta, kExt, kDan, kHi);
        classChart.setAnimated(false); classChart.setPrefHeight(260); classChart.setCategoryGap(18); classChart.setLegendVisible(false);
        locChart.setAnimated(false); locChart.setPrefHeight(260); locChart.setCategoryGap(18); locChart.setLegendVisible(false);
        ((NumberAxis) classChart.getYAxis()).setLabel("% of hours");
        ((NumberAxis) locChart.getYAxis()).setLabel("Expected UHI anomaly (\u00B0C)");
        sweep.setCreateSymbols(false); sweep.setAnimated(false); sweep.setPrefHeight(260); sweep.setLegendVisible(false);
        ((NumberAxis) sweep.getXAxis()).setLabel("Strength of the whole scenario (% of the slider settings)");
        ((NumberAxis) sweep.getYAxis()).setLabel("Change in expected UHI anomaly (\u00B0C)");
        ((NumberAxis) sweep.getYAxis()).setForceZeroInRange(true);
        HBox charts = new HBox(12, Ui.card("UHI class mix: baseline vs scenario", new VBox(6, classChart, Ui.legend(new int[]{0x94A3B8, Palette.TEAL}, new String[]{"Baseline", "Scenario"}))), Ui.card("Selected grid points: baseline vs scenario", new VBox(6, locChart, Ui.legend(new int[]{0x94A3B8, Palette.TEAL}, new String[]{"Baseline", "Scenario"}))));
        for (var n : charts.getChildren()) HBox.setHgrow(n, Priority.ALWAYS);
        VBox sweepBox = Ui.card("Sensitivity sweep: how the three models respond as the scenario is ramped up", "Negative = cooler than the baseline. Disagreement between models signals low reliability.", new VBox(6, sweep, Ui.legend(new int[]{Palette.CLASS[3], Palette.TEAL, 0x9467BD}, st.ms.modelNames)));
        VBox levBox = Ui.card("Which levers can the models actually feel?", "Change in expected UHI anomaly (\u00B0C) when one lever is set to 100% on the rows of the selected grid points.", levers);

        VBox right = new VBox(12, banner, kp, charts, sweepBox, levBox);
        HBox.setHgrow(right, Priority.ALWAYS);
        VBox left = Ui.card("Scenario", new VBox(8, controls, status));
        left.setPrefWidth(330); left.setMinWidth(330); left.setMaxHeight(Region.USE_PREF_SIZE);
        setContent(Ui.page(new HBox(12, left, right)));
        setFitToWidth(true);
        getStyleClass().add("page-scroll");
        debounce.setOnFinished(e -> run());
        sweepDebounce.setOnFinished(e -> runSweep());
        st.onView(this::trigger);
    }

    private static Slider slider() { Slider s = new Slider(0, 100, 0); s.setBlockIncrement(5); s.setMajorTickUnit(25); return s; }

    private VBox lever(String name, Slider s, Label value) {
        HBox h = new HBox(8, new Label(name), new Region(), value);
        HBox.setHgrow(h.getChildren().get(1), Priority.ALWAYS);
        return new VBox(2, h, s);
    }

    private Button preset(String name, double g, double b, double r, double w) {
        Button x = new Button(name);
        x.getStyleClass().add("chip");
        x.setOnAction(e -> { green.setValue(g); build.setValue(b); road.setValue(r); water.setValue(w); });
        return x;
    }

    private void updateLabels() {
        gl.setText(fmt("+", green.getValue()));
        bl.setText(fmt("-", build.getValue()));
        rl.setText(fmt("-", road.getValue()));
        wl.setText(fmt("-", water.getValue()));
    }

    private static String fmt(String sign, double v) { return v < 0.5 ? "0%" : String.format(Locale.ROOT, "%s%.0f%%", sign, v); }

    private void trigger() { debounce.playFromStart(); sweepDebounce.playFromStart(); leversDone = false; }

    private Simulator.Scenario scenario() { return new Simulator.Scenario(green.getValue(), build.getValue(), road.getValue(), water.getValue()); }

    private int[] rows() {
        List<Integer> r = new ArrayList<>();
        for (int row : st.rows) if (loc[st.ds.loc[row]].isSelected()) r.add(row);
        return r.stream().mapToInt(i -> i).toArray();
    }

    private void run() {
        int[] rows = rows();
        if (rows.length == 0) { status.setText("No rows: select a grid point that is also inside the current filters."); return; }
        UhiClassifier m = st.ms.byName(model.getValue());
        Simulator.Result r = Simulator.run(st.ds, st.ms.scaler, m, rows, scenario(), 4000);
        status.setText(String.format(Locale.ROOT, "Based on %,d sampled hours \u00B7 model: %s", r.n, m.name()));
        kDelta.set(String.format(Locale.ROOT, "%+.2f \u00B0C", r.deltaC()), String.format(Locale.ROOT, "%+.2f \u2192 %+.2f \u00B0C", r.expBefore, r.expAfter));
        kExt.set(Ui.pct0(r.shareBefore[3]) + " \u2192 " + Ui.pct0(r.shareAfter[3]), String.format(Locale.ROOT, "Low %s \u2192 %s", Ui.pct0(r.shareBefore[0]), Ui.pct0(r.shareAfter[0])));
        double db = r.riskBefore[3] + r.riskBefore[4], da = r.riskAfter[3] + r.riskAfter[4];
        kDan.set(Ui.pct0(db) + " \u2192 " + Ui.pct0(da), "NWS-based levels");
        kHi.set(String.format(Locale.ROOT, "%+.2f \u00B0C", r.deltaC()), "T and humidity unchanged");

        XYChart.Series<String, Number> b = new XYChart.Series<>(), a = new XYChart.Series<>();
        b.setName("Baseline"); a.setName("Scenario");
        for (int c = 0; c < Cfg.NC; c++) { b.getData().add(new XYChart.Data<>(Cfg.CLASS_NAMES[c], r.shareBefore[c] * 100)); a.getData().add(new XYChart.Data<>(Cfg.CLASS_NAMES[c], r.shareAfter[c] * 100)); }
        classChart.getData().setAll(List.of(b, a));
        Ui.colorSeriesBars(classChart, new int[]{0x94A3B8, Palette.TEAL});
        XYChart.Series<String, Number> lb = new XYChart.Series<>(), la = new XYChart.Series<>();
        lb.setName("Baseline"); la.setName("Scenario");
        for (int l = 0; l < st.ds.nLoc; l++) if (loc[l].isSelected()) { lb.getData().add(new XYChart.Data<>(st.ds.locShort[l], r.locExpBefore[l])); la.getData().add(new XYChart.Data<>(st.ds.locShort[l], r.locExpAfter[l])); }
        locChart.getData().setAll(List.of(lb, la));
        Ui.colorSeriesBars(locChart, new int[]{0x94A3B8, Palette.TEAL});
    }

    private void runSweep() {
        final int[] rows = rows();
        if (rows.length == 0) return;
        final Simulator.Scenario sc = scenario();
        final long token = ++sweepToken;
        Task<List<double[]>> t = new Task<>() {
            @Override protected List<double[]> call() {
                List<double[]> out = new ArrayList<>();
                for (UhiClassifier m : st.ms.models) out.add(Simulator.sweep(st.ds, st.ms.scaler, m, rows, sc, 1500));
                return out;
            }
        };
        t.setOnSucceeded(e -> {
            if (token != sweepToken) return;
            List<XYChart.Series<Number, Number>> ss = new ArrayList<>();
            for (int k = 0; k < st.ms.models.length; k++) {
                XYChart.Series<Number, Number> s = new XYChart.Series<>();
                s.setName(st.ms.modelNames[k]);
                double[] v = t.getValue().get(k);
                for (int i = 0; i <= 10; i++) s.getData().add(new XYChart.Data<>(i * 10, v[i]));
                ss.add(s);
            }
            sweep.getData().setAll(ss);
            int[] cols = {Palette.CLASS[3], Palette.TEAL, 0x9467BD};
            for (int k = 0; k < ss.size(); k++) Ui.styleLine(sweep.getData().get(k), cols[k % cols.length], 2.4, false);
        });
        Thread th = new Thread(t, "uhi-sweep");
        th.setDaemon(true);
        th.start();
        if (!leversDone) { leversDone = true; runLevers(rows); }
    }

    private void runLevers(int[] rows) {
        Task<List<String[]>> t = new Task<>() {
            @Override protected List<String[]> call() {
                String[] names = {"Green cover +100%", "Building density -100%", "Road density -100%", "Water distance -100%"};
                Simulator.Scenario[] sc = {new Simulator.Scenario(100, 0, 0, 0), new Simulator.Scenario(0, 100, 0, 0), new Simulator.Scenario(0, 0, 100, 0), new Simulator.Scenario(0, 0, 0, 100)};
                List<String[]> out = new ArrayList<>();
                for (int i = 0; i < sc.length; i++) {
                    String[] row = new String[5];
                    row[0] = names[i];
                    row[1] = "-"; row[2] = "-"; row[3] = "-"; row[4] = "-";
                    for (UhiClassifier m : st.ms.models) {
                        double d = Simulator.run(st.ds, st.ms.scaler, m, rows, sc[i], 1500).deltaC();
                        String v = Math.abs(d) < 0.02 ? "\u2248 0" : String.format(Locale.ROOT, "%+.2f \u00B0C", d);
                        if (m.name().equals("DNN")) row[1] = v; else if (m.name().equals("DNN (tuned)")) row[2] = v; else if (m.name().equals("Gradient Boosting")) row[3] = v; else row[4] = v;
                    }
                    out.add(row);
                }
                return out;
            }
        };
        t.setOnSucceeded(e -> Ui.fill(levers, t.getValue()));
        Thread th = new Thread(t, "uhi-levers");
        th.setDaemon(true);
        th.start();
    }
}
