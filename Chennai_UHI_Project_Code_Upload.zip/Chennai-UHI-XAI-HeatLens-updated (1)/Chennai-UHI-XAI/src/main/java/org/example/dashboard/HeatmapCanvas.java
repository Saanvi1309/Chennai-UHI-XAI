package org.example.dashboard;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Tooltip;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import org.example.analytics.Palette;

/** Generic labelled grid heat-map drawn on a canvas, with hover tooltips. */
final class HeatmapCanvas extends Canvas {
    interface ColorFn { int color(double v, double min, double max); }

    private double[][] v = new double[0][0];
    private boolean[][] has;
    private String[] rowL = new String[0], colL = new String[0];
    private ColorFn fn = (x, a, b) -> Palette.diverging(x, Math.max(Math.abs(a), Math.abs(b)));
    private String unit = "";
    private double min, max;
    private final Tooltip tip = new Tooltip();
    private final AppState st;
    private static final double LEFT = 38, TOP = 6, BOTTOM = 22;

    HeatmapCanvas(AppState st, double w, double h) {
        super(w, h);
        this.st = st;
        Tooltip.install(this, tip);
        tip.setShowDelay(javafx.util.Duration.millis(100));
        setOnMouseMoved(e -> {
            int r = rows() == 0 ? -1 : (int) ((e.getY() - TOP) / cellH()), c = (int) ((e.getX() - LEFT) / cellW());
            if (r >= 0 && r < rows() && c >= 0 && c < cols() && has[r][c])
                tip.setText(rowL[r] + "  " + colL[c] + "\n" + String.format("%.2f %s", v[r][c], unit));
            else tip.setText("");
        });
        st.dark.addListener((o, a, b) -> draw());
        widthProperty().addListener((o, a, b) -> draw());
    }

    private int rows() { return v.length; }
    private int cols() { return v.length == 0 ? 0 : v[0].length; }
    private double cellW() { return (getWidth() - LEFT - 4) / Math.max(1, cols()); }
    private double cellH() { return (getHeight() - TOP - BOTTOM) / Math.max(1, rows()); }

    void setData(double[][] values, boolean[][] present, String[] rowLabels, String[] colLabels, ColorFn f, String unit) {
        this.v = values; this.has = present; this.rowL = rowLabels; this.colL = colLabels; this.fn = f; this.unit = unit;
        min = Double.MAX_VALUE; max = -Double.MAX_VALUE;
        for (int r = 0; r < values.length; r++) for (int c = 0; c < values[r].length; c++) if (present[r][c]) { min = Math.min(min, values[r][c]); max = Math.max(max, values[r][c]); }
        if (min > max) { min = 0; max = 1; }
        draw();
    }

    void draw() {
        GraphicsContext g = getGraphicsContext2D();
        g.clearRect(0, 0, getWidth(), getHeight());
        boolean dark = st.dark.get();
        Color ink = dark ? Color.web("#CBD5E1") : Color.web("#4B5563");
        Color empty = dark ? Color.web("#1E293B") : Color.web("#F3F4F6");
        double cw = cellW(), ch = cellH();
        g.setFont(Font.font(10));
        g.setFill(ink);
        g.setTextAlign(TextAlignment.RIGHT);
        for (int r = 0; r < rows(); r++) g.fillText(rowL[r], LEFT - 6, TOP + r * ch + ch * 0.5 + 3.5);
        g.setTextAlign(TextAlignment.CENTER);
        int step = cols() > 12 ? 3 : 1;
        for (int c = 0; c < cols(); c += step) g.fillText(colL[c], LEFT + c * cw + cw / 2, getHeight() - 6);
        for (int r = 0; r < rows(); r++) for (int c = 0; c < cols(); c++) {
            g.setFill(has[r][c] ? Ui.color(fn.color(v[r][c], min, max)) : empty);
            g.fillRect(LEFT + c * cw, TOP + r * ch, Math.max(1, cw - 1), Math.max(1, ch - 1));
        }
    }
}
