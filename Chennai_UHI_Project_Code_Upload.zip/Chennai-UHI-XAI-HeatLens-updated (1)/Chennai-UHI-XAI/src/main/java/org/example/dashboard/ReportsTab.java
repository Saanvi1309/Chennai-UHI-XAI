package org.example.dashboard;

import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import org.example.analytics.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Reports page: PDF and CSV exports. Charts can also be saved as PNG with the "Save PNG" buttons on the cards. */
final class ReportsTab extends ScrollPane {
    ReportsTab(AppState st) {
        Label how = Ui.note("All files are written to the exports/ folder. PDF reports use the stored results and the current models; the XAI report explains the hour selected on the Explainable AI page (or the latest test-period Extreme hour at P4 if none is selected).");
        how.getStyleClass().add("banner");
        VBox list = new VBox(10);
        list.getChildren().addAll(
                item(st, "View report (PDF)", "KPIs, patterns, forecast and insights for the current filters.", () -> {
                    return ReportExporter.exportPdf(st.ds, st.ms, st.filter, st.rows, st.stats, st.viewInsights, st.forecast, st.forecastInsights, Cfg.exports().resolve("uhi_report_" + ReportExporter.stamp() + ".pdf")); }),
                item(st, "Model performance report (PDF)", "Metrics, training history, forecasting validation, XAI, hotspots and planning priorities, plus the written analysis.", () -> {
                    AnalysisReports.setTemperatures(st.ms);
                    return AnalysisReports.modelPerformancePdf(st.ds, st.ms, Cfg.exports().resolve("model_performance_report_" + ReportExporter.stamp() + ".pdf")); }),
                item(st, "Explanation report for the selected location (PDF)", "Prediction, probabilities, waterfall and all 28 feature contributions for one hour.", () -> {
                    AnalysisReports.setTemperatures(st.ms);
                    int row = st.xaiRow;
                    if (row < 0) for (int i = st.ds.n - 1; i >= 0; i--) if (st.ds.split[i] == 2 && st.ds.loc[i] == 3 && st.ds.cls[i] == 3 && st.ds.hour[i] == 8) { row = i; break; }
                    Xai.Explanation e = Xai.explain(st.ms.primary, st.ds, st.ms.scaler, row, -1, Xai.background(st.ds, st.ms.scaler, 200), 100, 7);
                    return AnalysisReports.xaiReportPdf(st.ds, st.ms, st.ms.primary, e, Cfg.exports().resolve("xai_report_" + ReportExporter.stamp() + ".pdf")); }),
                item(st, "Summary CSV of this view", "Headline numbers for the current filters.", () -> ReportExporter.exportSummaryCsv(st.ds, st.filter, st.stats, Cfg.exports().resolve("uhi_summary_" + ReportExporter.stamp() + ".csv"))),
                item(st, "Filtered hourly rows (CSV)", "Every hour in the current view with model predictions.", () -> ReportExporter.exportRowsCsv(st.ds, st.ms, st.rows, Cfg.exports().resolve("uhi_filtered_rows_" + ReportExporter.stamp() + ".csv"))),
                item(st, "All analysis tables (CSV bundle)", "Copies every file in results/ (metrics, XAI, forecast, hotspots, planning) into a time-stamped exports/ folder.", () -> {
                    Path dir = Cfg.exports().resolve("results_" + ReportExporter.stamp());
                    Files.createDirectories(dir);
                    try (var s = Files.list(Cfg.results())) { for (Path f : (Iterable<Path>) s::iterator) Files.copy(f, dir.resolve(f.getFileName())); }
                    return dir; }));
        VBox png = new VBox(6, Ui.label("Downloadable visualisations", "card-title"), Ui.note("Use the 'Save PNG' button under the heat map, correlation matrix, training curves, confusion matrix, forecast charts and XAI plots. Images are saved in exports/."));
        png.getStyleClass().add("card");
        png.setPadding(new Insets(12));
        setContent(Ui.page(how, Ui.card("Exports", list), png));
        setFitToWidth(true);
        getStyleClass().add("page-scroll");
    }

    private Node item(AppState st, String title, String text, java.util.concurrent.Callable<Path> job) {
        Button b = new Button("Create");
        b.setOnAction(e -> Ui.runExport(st, this, job));
        Label t = Ui.label(title, "insight-title"), d = Ui.note(text);
        VBox v = new VBox(2, t, d);
        HBox.setHgrow(v, Priority.ALWAYS);
        HBox h = new HBox(12, v, b);
        h.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        h.getStyleClass().add("insight");
        h.setStyle("-ins: " + Ui.css(Palette.TEAL) + ";");
        return h;
    }
}
