package org.example.analytics;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

/**
 * Verifies that the timestamps really support the claimed 1-24 h forecast horizons. Nothing is interpolated or filled:
 * the check only counts missing/duplicate hours and how many (origin, origin+h) pairs have an observed target.
 */
public final class TimeAlignment {
    private TimeAlignment() {}

    public record LocCheck(String loc, int rows, int expected, int missing, int duplicates, int minStep, int maxStep, boolean hourly) {}
    public record HorizonCheck(int horizon, long pairs, long observed) {
        public double coverage() { return pairs == 0 ? 0 : (double) observed / pairs; }
    }

    public static LocCheck[] locations(DataStore ds) {
        LocCheck[] out = new LocCheck[ds.nLoc];
        for (int l = 0; l < ds.nLoc; l++) {
            int rows = 0, first = Integer.MAX_VALUE, last = -1;
            int[] seen = new int[ds.nHours];
            for (int i = 0; i < ds.n; i++) if (ds.loc[i] == l) { rows++; seen[ds.hourIdx[i]]++; first = Math.min(first, ds.hourIdx[i]); last = Math.max(last, ds.hourIdx[i]); }
            int expected = last - first + 1, dup = 0, missing = 0, minStep = Integer.MAX_VALUE, maxStep = 0, prev = -1;
            for (int t = first; t <= last; t++) {
                if (seen[t] == 0) missing++;
                if (seen[t] > 1) dup += seen[t] - 1;
                if (seen[t] > 0) { if (prev >= 0) { minStep = Math.min(minStep, t - prev); maxStep = Math.max(maxStep, t - prev); } prev = t; }
            }
            out[l] = new LocCheck(ds.locShort[l], rows, expected, missing, dup, minStep == Integer.MAX_VALUE ? 0 : minStep, maxStep, missing == 0 && dup == 0 && maxStep == 1);
        }
        return out;
    }

    public static HorizonCheck[] horizons(DataStore ds, int[] hs) {
        HorizonCheck[] out = new HorizonCheck[hs.length];
        for (int a = 0; a < hs.length; a++) {
            long pairs = 0, ok = 0;
            for (int t = 0; t + hs[a] < ds.nHours; t++) for (int l = 0; l < ds.nLoc; l++) {
                if (ds.rowAt[t][l] < 0) continue;
                pairs++;
                if (ds.rowAt[t + hs[a]][l] >= 0) ok++;
            }
            out[a] = new HorizonCheck(hs[a], pairs, ok);
        }
        return out;
    }

    public static boolean allHourly(DataStore ds) {
        for (LocCheck c : locations(ds)) if (!c.hourly()) return false;
        return true;
    }

    public static void write(DataStore ds, Path dir) throws IOException {
        StringBuilder sb = new StringBuilder("location,first_timestamp_utc,last_timestamp_utc,rows,expected_rows,missing_hours,duplicate_timestamps,min_step_h,max_step_h,regular_hourly\n");
        LocCheck[] lc = locations(ds);
        for (int l = 0; l < lc.length; l++) {
            int first = Integer.MAX_VALUE, last = -1;
            for (int t = 0; t < ds.nHours; t++) if (ds.rowAt[t][l] >= 0) { first = Math.min(first, t); last = Math.max(last, t); }
            LocCheck c = lc[l];
            sb.append(String.format(Locale.ROOT, "%s,%s,%s,%d,%d,%d,%d,%d,%d,%s%n", c.loc(), ds.time(first), ds.time(last), c.rows(), c.expected(), c.missing(), c.duplicates(), c.minStep(), c.maxStep(), c.hourly() ? "PASS" : "FAIL"));
        }
        Files.writeString(dir.resolve("time_alignment_check.csv"), sb.toString());
        StringBuilder hs = new StringBuilder("horizon_h,origin_pairs,pairs_with_observed_target,coverage_percent,supported_without_interpolation\n");
        for (HorizonCheck h : horizons(ds, ModelSuite.FORECAST_HORIZONS))
            hs.append(String.format(Locale.ROOT, "%d,%d,%d,%.2f,%s%n", h.horizon(), h.pairs(), h.observed(), h.coverage() * 100, h.coverage() >= 0.999 ? "YES" : "NO"));
        Files.writeString(dir.resolve("time_alignment_horizons.csv"), hs.toString());
    }
}
