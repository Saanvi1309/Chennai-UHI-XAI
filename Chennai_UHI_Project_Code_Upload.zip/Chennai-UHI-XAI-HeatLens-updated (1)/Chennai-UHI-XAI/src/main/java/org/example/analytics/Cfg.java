package org.example.analytics;

import java.nio.file.Files;
import java.nio.file.Path;

/** Shared constants and project paths for the analytics + dashboard layer. */
public final class Cfg {
    private Cfg() {}

    public static final String[] FEATURES = {
            "latitude", "longitude", "air_temperature", "dew_point_temperature", "cloud_cover",
            "u10", "v10", "wind_speed", "wind_direction", "relative_humidity", "pressure", "rainfall",
            "red_band", "nir_band", "ndvi", "ndbi", "ndwi", "land_use_type", "elevation",
            "distance_to_coast", "distance_to_green_space", "distance_to_road", "distance_to_water",
            "building_density", "road_density", "spatial_match_distance_km",
            "dynamic_nearest_distance_km", "landsat_temporal_gap_days"
    };
    public static final int NF = FEATURES.length;

    // indices into FEATURES
    public static final int F_AIR_T = 2, F_DEW = 3, F_CLOUD = 4, F_WIND = 7, F_RH = 9, F_PRESS = 10,
            F_RAIN = 11, F_RED = 12, F_NIR = 13, F_NDVI = 14, F_DGREEN = 20, F_DROAD = 21,
            F_DWATER = 22, F_BLD = 23, F_ROAD = 24;

    public static final String[] CLASS_NAMES = {"Low", "Moderate", "High", "Extreme"};
    public static final int NC = 4;

    public static final String FINAL_CSV = "data/processed/Chennai_UHI_Final.csv";

    private static Path root;

    /** Project root = folder that contains data/processed/Chennai_UHI_Final.csv. */
    public static synchronized Path root() {
        if (root != null) return root;
        Path p = Path.of(System.getProperty("user.dir")).toAbsolutePath();
        for (int i = 0; i < 5 && p != null; i++) {
            if (Files.exists(p.resolve(FINAL_CSV))) return root = p;
            Path sub = p.resolve("Chennai-UHI-XAI");
            if (Files.exists(sub.resolve(FINAL_CSV))) return root = sub;
            p = p.getParent();
        }
        return root = Path.of(System.getProperty("user.dir")).toAbsolutePath();
    }

    public static Path data() { return root().resolve(FINAL_CSV); }
    public static Path models() { return root().resolve("models"); }
    public static Path results() { return root().resolve("results"); }
    public static Path exports() { return root().resolve("exports"); }

    /** Data timestamps are UTC (air temperature peaks at 09:00 UTC = 14:30 IST). Everything shown to the user is IST. */
    public static final int TZ_MIN = 330;
    public static final String TZ_NAME = "IST";

    /** Clock label (IST) for the start of a UTC hour bin, e.g. 7 -> "12:30". */
    public static String hourLabel(int utcHour) {
        int m = (((utcHour % 24) + 24) % 24 * 60 + TZ_MIN) % 1440;
        return String.format("%02d:%02d", m / 60, m % 60);
    }

    /** Charts list the 24 UTC hour bins starting at 00:30 IST (= 19:00 UTC) so the day reads chronologically. */
    public static int hourAt(int i) { return (19 + i) % 24; }

    public static java.time.LocalDateTime local(java.time.LocalDateTime utc) { return utc.plusMinutes(TZ_MIN); }

    public static String prettyFeature(String f) {
        String s = f.replace('_', ' ');
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    /** Approximate nearest-area hints for the six grid points (edit freely). */
    public static String areaHint(double lat, double lon) {
        int la = (int) Math.round(lat * 100), lo = (int) Math.round(lon * 100);
        if (la == 1275 && lo == 8000) return "Chengalpattu side";
        if (la == 1275 && lo == 8025) return "Kovalam-ECR coast";
        if (la == 1300 && lo == 8000) return "Sriperumbudur side";
        if (la == 1300 && lo == 8025) return "Guindy-Adyar (city)";
        if (la == 1325 && lo == 8000) return "Tiruvallur side";
        if (la == 1325 && lo == 8025) return "Ponneri-Ennore (north)";
        return "";
    }
}
