package org.example.dashboard;

import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import org.example.analytics.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Forecast validation: timestamp alignment, horizon table, actual vs predicted temperature, confidence, location and hour errors. */
final class ForecastEvalTab extends ScrollPane {
    private final AppState st;
    private final ComboBox<String> locBox = new ComboBox<>(), horBox = new ComboBox<>();
    private final LineChart<Number, Number> avp = new LineChart<>(new NumberAxis(), new NumberAxis());
    private final LineChart<Number, Number> accChart = new LineChart<>(new NumberAxis(), new NumberAxis());
    private final Label avpNote = Ui.note("");

    ForecastEvalTab(AppState st) {
        this.st = st;
        DataStore ds = st.ds;
        Label how = Ui.note("Held-out test period (Jul-Dec 2025). Every value is computed from the trained forecaster against observed data. The 1-24 h horizons are only claimed because the timestamp check below finds "
                + "complete hourly records; nothing was interpolated. The class forecast is a gradient-boosting model with the horizon as an input (validated against a neural-network challenger); "
                + "air temperature is forecast with climatology + decaying persistence.");
        how.getStyleClass().add("banner");
        TableView<String[]> align = Ui.csvTable("time_alignment_check.csv", new int[]{0, 3, 4, 5, 6, 7, 8, 9}, new String[]{"Point", "Rows", "Expected", "Missing hours", "Duplicates", "Min step (h)", "Max step (h)", "Regular hourly"},
                new double[]{60, 80, 80, 100, 90, 90, 90, 110}, null);
        TableView<String[]> cover = Ui.csvTable("time_alignment_horizons.csv", new int[]{0, 1, 2, 3, 4}, new String[]{"Horizon (h)", "Origin pairs", "With observed target", "Coverage %", "Supported without interpolation"},
                new double[]{90, 110, 150, 100, 220}, null);
        VBox cAlign = Ui.card("Timestamp alignment check", "Verifies that hourly forecast horizons are supported by the data.", new VBox(8, align, cover));

        TableView<String[]> hor = Ui.csvTable("forecast_horizon_table.csv", new int[]{0, 1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15, 17},
                new String[]{"Horizon (h)", "Test rows", "Accuracy", "Macro-F1", "Temp MAE \u00B0C", "Temp RMSE \u00B0C", "Temp R\u00B2", "Anomaly MAE", "Anomaly RMSE", "Anomaly R\u00B2", "Mean confidence", "ECE", "Persistence MAE", "Climatology MAE", "Yesterday acc."},
                new double[]{70, 70, 70, 70, 80, 85, 60, 90, 95, 85, 100, 55, 105, 105, 95}, null);
        hor.getItems().forEach(r -> { r[2] = Ui.p1(r[2]); r[3] = Ui.p1(r[3]); r[10] = Ui.p1(r[10]); r[14] = Ui.p1(r[14]);
            for (int i : new int[]{4, 5, 6, 7, 8, 9, 11, 12, 13}) r[i] = Ui.d3(r[i]); });
        VBox cHor = Ui.card("Forecast performance by horizon", "MAE / RMSE / R\u00B2 for air temperature and for the probability-weighted UHI anomaly; accuracy for the UHI class.", hor);

        accChart.setAnimated(false); accChart.setPrefHeight(280); accChart.setCreateSymbols(true);
        ((NumberAxis) accChart.getXAxis()).setLabel("Horizon (hours ahead)");
        ((NumberAxis) accChart.getYAxis()).setLabel("Accuracy (%)");
        ((NumberAxis) accChart.getYAxis()).setForceZeroInRange(false);
        XYChart.Series<Number, Number> a = new XYChart.Series<>(), b = new XYChart.Series<>();
        a.setName("Forecast"); b.setName("Same hour yesterday");
        for (String[] r : Results.body("forecast_horizon_table.csv")) { a.getData().add(new XYChart.Data<>(Results.num(r[0]), Results.num(r[2]) * 100)); b.getData().add(new XYChart.Data<>(Results.num(r[0]), Results.num(r[17]) * 100)); }
        accChart.getData().setAll(List.of(a, b));
        VBox cAcc = Ui.pngCard("Accuracy vs horizon", null, accChart, "forecast_accuracy_by_horizon");

        for (int l = 0; l < ds.nLoc; l++) locBox.getItems().add(ds.locName[l]);
        locBox.getSelectionModel().select(3);
        horBox.getItems().addAll("+6 h", "+24 h");
        horBox.getSelectionModel().select(0);
        locBox.valueProperty().addListener((o, x, y) -> drawAvp());
        horBox.valueProperty().addListener((o, x, y) -> drawAvp());
        avp.setAnimated(false); avp.setCreateSymbols(false); avp.setPrefHeight(320);
        ((NumberAxis) avp.getXAxis()).setLabel("Hours since start of the last 7 days (UTC)");
        ((NumberAxis) avp.getYAxis()).setLabel("Air temperature (\u00B0C)");
        ((NumberAxis) avp.getYAxis()).setForceZeroInRange(false);
        VBox cAvp = Ui.pngCard("Actual vs predicted air temperature (last 7 days of data)", "Each point on the x axis is a target hour; the forecast was issued h hours before it using only earlier data.", new VBox(6, new HBox(10, locBox, horBox), avp, avpNote), "forecast_actual_vs_predicted");

        TableView<String[]> byLoc = Ui.csvTable("forecast_by_location.csv", new int[]{0, 1, 2, 3, 4, 5}, new String[]{"Horizon (h)", "Point", "Rows", "Accuracy", "Temp MAE \u00B0C", "Temp RMSE \u00B0C"},
                new double[]{90, 60, 80, 90, 100, 110}, r -> r[0].equals("1") || r[0].equals("6") || r[0].equals("24"));
        byLoc.getItems().forEach(r -> { r[3] = Ui.p1(r[3]); r[4] = Ui.d3(r[4]); r[5] = Ui.d3(r[5]); });
        VBox cLoc = Ui.card("Location-wise forecasting and error analysis", "Accuracy and temperature error per grid point at +1, +6 and +24 h.", byLoc);
        TableView<String[]> conf = Ui.csvTable("forecast_confidence.csv", new int[]{0, 1, 2, 3, 4, 5}, new String[]{"Horizon (h)", "Confidence from", "to", "Rows", "Mean confidence", "Observed accuracy"},
                new double[]{90, 110, 60, 80, 120, 120}, r -> (r[0].equals("6") || r[0].equals("24")) && Results.num(r[3]) > 0);
        conf.getItems().forEach(r -> { r[4] = Ui.p1(r[4]); r[5] = Ui.p1(r[5]); });
        VBox cConf = Ui.card("Forecast confidence", "Forecast confidence = probability of the predicted class. Observed accuracy should track it.", conf);
        setContent(Ui.page(how, cAlign, cHor, Ui.row(cAcc, cAvp), Ui.row(cLoc, cConf)));
        setFitToWidth(true);
        getStyleClass().add("page-scroll");
        drawAvp();
    }

    private void drawAvp() {
        DataStore ds = st.ds;
        ForecastModel fm = st.ms.forecast;
        int l = Math.max(0, locBox.getSelectionModel().getSelectedIndex());
        int h = horBox.getSelectionModel().getSelectedIndex() == 1 ? 24 : 6;
        XYChart.Series<Number, Number> act = new XYChart.Series<>(), pred = new XYChart.Series<>();
        act.setName("Observed"); pred.setName("Forecast");
        int start = ds.nHours - 1 - 24 * 7, k = 0, okCls = 0, n = 0;
        double abs = 0;
        for (int t = start - h; t + h < ds.nHours; t++) {
            int rt = ds.rowAt[t + h][l];
            if (rt < 0 || ds.rowAt[t][l] < 0) continue;
            double p = fm.predictTemp(ds, t, l, h), a = ds.x[rt][Cfg.F_AIR_T];
            act.getData().add(new XYChart.Data<>(k, a)); pred.getData().add(new XYChart.Data<>(k, p));
            abs += Math.abs(a - p);
            double[] pr = fm.predictProba(ds, t, l, h);
            if (ModelEval.argmax(pr) == ds.cls[rt]) okCls++;
            n++; k++;
        }
        avp.getData().setAll(List.of(act, pred));
        Ui.styleLine(avp.getData().get(0), 0x374151, 2.0, false);
        Ui.styleLine(avp.getData().get(1), Palette.TEAL, 2.0, true);
        avpNote.setText(n == 0 ? "" : String.format(Locale.ROOT, "Last 7 days, %s, +%d h: temperature MAE %.2f \u00B0C, UHI-class accuracy %.0f%% (%d hours). These are the most recent data days and belong to the test period.", ds.locShort[l], h, abs / n, 100.0 * okCls / n, n));
    }
}
