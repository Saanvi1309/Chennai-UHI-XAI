package org.example.analytics;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Tiny dependency-free PDF writer: A4 pages, Helvetica text, rectangles and lines (top-left origin). */
public final class PdfDoc {
    public static final double W = 595, H = 842;
    private static final Charset CP1252 = Charset.forName("windows-1252");
    private static final int[] WIDTHS = {278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278,
            556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556, 1015, 667, 667, 722, 722, 667, 611,
            778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278,
            469, 556, 333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278,
            556, 500, 722, 500, 500, 500, 334, 260, 334, 584};

    public static double width(String s, double size, boolean bold) {
        double w = 0;
        for (char c : s.toCharArray()) w += (c >= 32 && c <= 126) ? WIDTHS[c - 32] : (c == '\u00B0' ? 400 : c == '\u00B7' ? 278 : 556);
        return w * size / 1000.0 * (bold ? 1.06 : 1.0);
    }

    public static final class Page {
        private final StringBuilder sb = new StringBuilder();

        private static String rgb(int c) {
            return String.format(Locale.ROOT, "%.3f %.3f %.3f", ((c >> 16) & 255) / 255.0, ((c >> 8) & 255) / 255.0, (c & 255) / 255.0);
        }

        public void rect(double x, double y, double w, double h, int fill) {
            sb.append(rgb(fill)).append(" rg ").append(f(x)).append(' ').append(f(H - y - h)).append(' ').append(f(w)).append(' ').append(f(h)).append(" re f\n");
        }

        public void strokeRect(double x, double y, double w, double h, int color, double lw) {
            sb.append(rgb(color)).append(" RG ").append(f(lw)).append(" w ").append(f(x)).append(' ').append(f(H - y - h)).append(' ').append(f(w)).append(' ').append(f(h)).append(" re S\n");
        }

        public void line(double x1, double y1, double x2, double y2, int color, double lw) {
            sb.append(rgb(color)).append(" RG ").append(f(lw)).append(" w ").append(f(x1)).append(' ').append(f(H - y1)).append(" m ")
                    .append(f(x2)).append(' ').append(f(H - y2)).append(" l S\n");
        }

        /** y is the text baseline measured from the top of the page. */
        public void text(double x, double y, double size, boolean bold, int color, String s) {
            sb.append("BT ").append(rgb(color)).append(" rg /").append(bold ? "F2" : "F1").append(' ').append(f(size)).append(" Tf ")
                    .append(f(x)).append(' ').append(f(H - y)).append(" Td (").append(esc(s)).append(") Tj ET\n");
        }

        public void textRight(double xr, double y, double size, boolean bold, int color, String s) {
            text(xr - width(s, size, bold), y, size, bold, color, s);
        }

        public void textCenter(double xc, double y, double size, boolean bold, int color, String s) {
            text(xc - width(s, size, bold) / 2, y, size, bold, color, s);
        }

        /** Wraps text into maxW; returns the y after the last line. */
        public double paragraph(double x, double y, double maxW, double size, boolean bold, int color, String s, double lead) {
            StringBuilder cur = new StringBuilder();
            for (String word : s.split(" ")) {
                String t = cur.length() == 0 ? word : cur + " " + word;
                if (width(t, size, bold) > maxW && cur.length() > 0) {
                    text(x, y, size, bold, color, cur.toString());
                    y += lead; cur = new StringBuilder(word);
                } else cur = new StringBuilder(t);
            }
            if (cur.length() > 0) { text(x, y, size, bold, color, cur.toString()); y += lead; }
            return y;
        }

        private static String f(double v) { return String.format(Locale.ROOT, "%.2f", v); }

        private static String esc(String s) {
            StringBuilder o = new StringBuilder();
            for (byte b : s.getBytes(CP1252)) {
                int c = b & 0xFF;
                if (c == '(' || c == ')' || c == '\\') o.append('\\').append((char) c);
                else if (c >= 32 && c < 127) o.append((char) c);
                else o.append(String.format("\\%03o", c));
            }
            return o.toString();
        }
    }

    private final List<Page> pages = new ArrayList<>();

    public Page newPage() { Page p = new Page(); pages.add(p); return p; }

    public void save(Path file) throws IOException {
        Files.createDirectories(file.toAbsolutePath().getParent());
        Files.write(file, build());
    }

    public byte[] build() throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        List<Integer> offs = new ArrayList<>();
        int n = pages.size();
        // objects: 1 catalog, 2 pages, 3 F1, 4 F2, then per page: page obj + content obj
        w(out, "%PDF-1.4\n");
        offs.add(out.size()); w(out, "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");
        StringBuilder kids = new StringBuilder();
        for (int i = 0; i < n; i++) kids.append(5 + 2 * i).append(" 0 R ");
        offs.add(out.size()); w(out, "2 0 obj\n<< /Type /Pages /Kids [" + kids + "] /Count " + n + " >>\nendobj\n");
        offs.add(out.size()); w(out, "3 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>\nendobj\n");
        offs.add(out.size()); w(out, "4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>\nendobj\n");
        for (int i = 0; i < n; i++) {
            byte[] content = pages.get(i).sb.toString().getBytes(StandardCharsets.ISO_8859_1);
            offs.add(out.size());
            w(out, (5 + 2 * i) + " 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents "
                    + (6 + 2 * i) + " 0 R >>\nendobj\n");
            offs.add(out.size());
            w(out, (6 + 2 * i) + " 0 obj\n<< /Length " + content.length + " >>\nstream\n");
            out.write(content);
            w(out, "\nendstream\nendobj\n");
        }
        int xref = out.size();
        w(out, "xref\n0 " + (offs.size() + 1) + "\n0000000000 65535 f \n");
        for (int o : offs) w(out, String.format(Locale.ROOT, "%010d 00000 n \n", o));
        w(out, "trailer\n<< /Size " + (offs.size() + 1) + " /Root 1 0 R >>\nstartxref\n" + xref + "\n%%EOF\n");
        return out.toByteArray();
    }

    private static void w(ByteArrayOutputStream o, String s) throws IOException { o.write(s.getBytes(StandardCharsets.ISO_8859_1)); }
}
