package org.example;

import ai.djl.Model;
import ai.djl.ndarray.NDArray;
import ai.djl.ndarray.NDManager;
import ai.djl.ndarray.types.DataType;
import ai.djl.ndarray.types.Shape;
import ai.djl.nn.Block;
import ai.djl.nn.SequentialBlock;
import ai.djl.nn.Activation;
import ai.djl.nn.core.Linear;
import ai.djl.nn.norm.Dropout;
import ai.djl.training.DefaultTrainingConfig;
import ai.djl.training.EasyTrain;
import ai.djl.training.Trainer;
import ai.djl.training.dataset.ArrayDataset;
import ai.djl.training.loss.SoftmaxCrossEntropyLoss;
import ai.djl.training.optimizer.Optimizer;
import ai.djl.training.tracker.Tracker;
import ai.djl.training.evaluator.Accuracy;

import java.nio.FloatBuffer;
import java.nio.LongBuffer;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.io.input.BOMInputStream;

public class UHITrainer {

    private static final int NUM_FEATURES = 28;
    private static final int NUM_CLASSES = 4;

    private static final int BATCH_SIZE = 128;
    private static final int EPOCHS = 50;

    private static final String[] FEATURES = {
            "latitude",
            "longitude",
            "air_temperature",
            "dew_point_temperature",
            "cloud_cover",
            "u10",
            "v10",
            "wind_speed",
            "wind_direction",
            "relative_humidity",
            "pressure",
            "rainfall",
            "red_band",
            "nir_band",
            "ndvi",
            "ndbi",
            "ndwi",
            "land_use_type",
            "elevation",
            "distance_to_coast",
            "distance_to_green_space",
            "distance_to_road",
            "distance_to_water",
            "building_density",
            "road_density",
            "spatial_match_distance_km",
            "dynamic_nearest_distance_km",
            "landsat_temporal_gap_days"
    };

    private static final String TARGET = "UHI_Class";


    public static void main(String[] args) throws Exception {

        String trainFile =
                "data/processed/train_scaled.csv";

        String validationFile =
                "data/processed/validation_scaled.csv";

        System.out.println("======================================");
        System.out.println("UHI DEEP NEURAL NETWORK TRAINING");
        System.out.println("======================================");

        System.out.println();
        System.out.println("Training file: " + trainFile);
        System.out.println("Validation file: " + validationFile);
        System.out.println();

        try (NDManager manager =
                     NDManager.newBaseManager()) {

            System.out.println("Loading training data...");

            DatasetData trainingData =
                    loadDataset(manager, trainFile);

            System.out.println(
                    "Training rows: "
                            + trainingData.rows
            );

            System.out.println();
            System.out.println("Loading validation data...");

            DatasetData validationData =
                    loadDataset(manager, validationFile);

            System.out.println(
                    "Validation rows: "
                            + validationData.rows
            );


            ArrayDataset trainDataset =
                    new ArrayDataset.Builder()
                            .setData(trainingData.features)
                            .optLabels(trainingData.labels)
                            .setSampling(
                                    BATCH_SIZE,
                                    true
                            )
                            .build();


            ArrayDataset validationDataset =
                    new ArrayDataset.Builder()
                            .setData(validationData.features)
                            .optLabels(validationData.labels)
                            .setSampling(
                                    BATCH_SIZE,
                                    false
                            )
                            .build();


            System.out.println();
            System.out.println("Creating neural network...");

            Block network =
                    new SequentialBlock()

                            .add(
                                    Linear.builder()
                                            .setUnits(128)
                                            .build()
                            )

                            .add(Activation::relu)

                            .add(
                                    Dropout.builder()
                                            .optRate(0.30f)
                                            .build()
                            )

                            .add(
                                    Linear.builder()
                                            .setUnits(64)
                                            .build()
                            )

                            .add(Activation::relu)

                            .add(
                                    Dropout.builder()
                                            .optRate(0.20f)
                                            .build()
                            )

                            .add(
                                    Linear.builder()
                                            .setUnits(32)
                                            .build()
                            )

                            .add(Activation::relu)

                            .add(
                                    Linear.builder()
                                            .setUnits(NUM_CLASSES)
                                            .build()
                            );


            try (Model model =
                         Model.newInstance("UHI-DNN")) {

                model.setBlock(network);


                Optimizer optimizer =
                        Optimizer.adam()
                                .optLearningRateTracker(
                                        Tracker.fixed(0.001f)
                                )
                                .build();


                DefaultTrainingConfig config =
                        new DefaultTrainingConfig(
                                new SoftmaxCrossEntropyLoss()
                        )
                                .optOptimizer(optimizer)
                                .addEvaluator(
                                        new Accuracy()
                                );


                try (Trainer trainer =
                             model.newTrainer(config)) {

                    trainer.initialize(
                            new Shape(
                                    1,
                                    NUM_FEATURES
                            )
                    );


                    System.out.println();
                    System.out.println(
                            "======================================"
                    );
                    System.out.println(
                            "MODEL TRAINING STARTED"
                    );
                    System.out.println(
                            "======================================"
                    );

                    System.out.println(
                            "Input features : "
                                    + NUM_FEATURES
                    );

                    System.out.println(
                            "Output classes  : "
                                    + NUM_CLASSES
                    );

                    System.out.println(
                            "Batch size      : "
                                    + BATCH_SIZE
                    );

                    System.out.println(
                            "Learning rate   : 0.001"
                    );

                    System.out.println(
                            "Epochs          : "
                                    + EPOCHS
                    );

                    System.out.println();


                    EasyTrain.fit(
                            trainer,
                            EPOCHS,
                            trainDataset,
                            validationDataset
                    );


                    System.out.println();
                    System.out.println(
                            "======================================"
                    );
                    System.out.println(
                            "TRAINING COMPLETED!"
                    );
                    System.out.println(
                            "======================================"
                    );


                    Path modelPath =
                            Path.of("models");

                    model.save(
                            modelPath,
                            "uhi-dnn"
                    );


                    System.out.println(
                            "Model saved to:"
                    );

                    System.out.println(
                            "models/uhi-dnn"
                    );
                }
            }

            trainingData.features.close();
            trainingData.labels.close();

            validationData.features.close();
            validationData.labels.close();
        }
    }


    private static DatasetData loadDataset(
            NDManager manager,
            String filePath
    ) throws Exception {

        List<Float> featureValues =
                new ArrayList<>();

        List<Long> labelValues =
                new ArrayList<>();

        long rows = 0;


        try (
                CSVParser parser =
                        CSVParser.parse(
                                Path.of(filePath),
                                StandardCharsets.UTF_8,
                                CSVFormat.DEFAULT.builder()
                                        .setHeader()
                                        .setSkipHeaderRecord(true)
                                        .build()
                        )
        ) {

            for (String feature : FEATURES) {

                if (!parser.getHeaderMap()
                        .containsKey(feature)) {

                    throw new IllegalStateException(
                            "Missing feature: "
                                    + feature
                    );
                }
            }


            if (!parser.getHeaderMap()
                    .containsKey(TARGET)) {

                throw new IllegalStateException(
                        "Missing target column: "
                                + TARGET
                );
            }


            for (CSVRecord record : parser) {

                rows++;


                for (String feature : FEATURES) {

                    double value =
                            Double.parseDouble(
                                    record.get(feature)
                                            .trim()
                            );


                    if (!Double.isFinite(value)) {

                        throw new IllegalStateException(
                                "Invalid value at row "
                                        + rows
                                        + ": "
                                        + feature
                        );
                    }


                    featureValues.add(
                            (float) value
                    );
                }


                String target =
                        record.get(TARGET)
                                .trim();


                labelValues.add(
                        convertClass(target)
                );
            }
        }


        float[] featureArray =
                new float[featureValues.size()];


        for (int i = 0;
             i < featureValues.size();
             i++) {

            featureArray[i] =
                    featureValues.get(i);
        }


        long[] labelArray =
                new long[labelValues.size()];


        for (int i = 0;
             i < labelValues.size();
             i++) {

            labelArray[i] =
                    labelValues.get(i);
        }


        NDArray features =
                manager.create(
                        FloatBuffer.wrap(
                                featureArray
                        ),
                        new Shape(
                                rows,
                                NUM_FEATURES
                        ),
                        DataType.FLOAT32
                );


        NDArray labels =
                manager.create(
                        LongBuffer.wrap(
                                labelArray
                        ),
                        new Shape(rows),
                        DataType.INT64
                );


        return new DatasetData(
                features,
                labels,
                rows
        );
    }


    private static long convertClass(
            String className
    ) {

        switch (className) {

            case "Low":
                return 0;

            case "Moderate":
                return 1;

            case "High":
                return 2;

            case "Extreme":
                return 3;

            default:

                throw new IllegalArgumentException(
                        "Unknown UHI class: "
                                + className
                );
        }
    }


    private static class DatasetData {

        NDArray features;
        NDArray labels;
        long rows;


        DatasetData(
                NDArray features,
                NDArray labels,
                long rows
        ) {

            this.features = features;
            this.labels = labels;
            this.rows = rows;
        }
    }
}