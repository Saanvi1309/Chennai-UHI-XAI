package org.example;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class TrainingData {

    private static final String[] FEATURES = {
            "latitude",
            "longitude",
            "air_temperature",
            "dew_point_temperature",
            "cloud_cover",
            "u10",
            "v10",
            "wind_speed",
            "wind_direction",
            "relative_humidity",
            "pressure",
            "rainfall",
            "red_band",
            "nir_band",
            "ndvi",
            "ndbi",
            "ndwi",
            "land_use_type",
            "elevation",
            "distance_to_coast",
            "distance_to_green_space",
            "distance_to_road",
            "distance_to_water",
            "building_density",
            "road_density",
            "spatial_match_distance_km",
            "dynamic_nearest_distance_km",
            "landsat_temporal_gap_days"
    };

    private static final String TARGET = "UHI_Class";

    public static void main(String[] args) throws Exception {

        String trainFile =
                "data/processed/train_scaled.csv";

        String validationFile =
                "data/processed/validation_scaled.csv";

        String testFile =
                "data/processed/test_scaled.csv";

        System.out.println("======================================");
        System.out.println("NEURAL NETWORK DATA CHECK");
        System.out.println("======================================");

        checkDataset(trainFile, "TRAINING");
        checkDataset(validationFile, "VALIDATION");
        checkDataset(testFile, "TESTING");

        System.out.println();
        System.out.println("======================================");
        System.out.println("DATA PREPARATION CHECK COMPLETED!");
        System.out.println("======================================");
    }

    private static void checkDataset(
            String filePath,
            String datasetName
    ) throws Exception {

        System.out.println();
        System.out.println(datasetName);
        System.out.println("--------------------------------------");

        Map<String, Integer> classCounts = new HashMap<>();

        long rows = 0;

        try (
                CSVParser parser = CSVParser.parse(
                        Path.of(filePath),
                        StandardCharsets.UTF_8,
                        CSVFormat.DEFAULT.builder()
                                .setHeader()
                                .setSkipHeaderRecord(true)
                                .build()
                )
        ) {

            // Check that all expected features exist
            for (String feature : FEATURES) {

                if (!parser.getHeaderMap().containsKey(feature)) {

                    throw new IllegalStateException(
                            "Missing feature: " + feature
                    );
                }
            }

            if (!parser.getHeaderMap().containsKey(TARGET)) {

                throw new IllegalStateException(
                        "Missing target column: " + TARGET
                );
            }

            for (CSVRecord record : parser) {

                rows++;

                // Check every feature is a valid number
                for (String feature : FEATURES) {

                    String value = record.get(feature).trim();

                    double number =
                            Double.parseDouble(value);

                    if (!Double.isFinite(number)) {

                        throw new IllegalStateException(
                                "Invalid number in feature "
                                        + feature
                                        + " at row "
                                        + rows
                        );
                    }
                }

                // Convert target to class number
                String target =
                        record.get(TARGET).trim();

                int classNumber =
                        convertClass(target);

                String className =
                        className(classNumber);

                classCounts.put(
                        className,
                        classCounts.getOrDefault(
                                className,
                                0
                        ) + 1
                );
            }
        }

        System.out.println("Rows: " + rows);

        System.out.println();
        System.out.println("UHI class counts:");

        System.out.println(
                "Low       (0): "
                        + classCounts.getOrDefault("Low", 0)
        );

        System.out.println(
                "Moderate  (1): "
                        + classCounts.getOrDefault("Moderate", 0)
        );

        System.out.println(
                "High      (2): "
                        + classCounts.getOrDefault("High", 0)
        );

        System.out.println(
                "Extreme   (3): "
                        + classCounts.getOrDefault("Extreme", 0)
        );
    }

    private static int convertClass(String className) {

        switch (className) {

            case "Low":
                return 0;

            case "Moderate":
                return 1;

            case "High":
                return 2;

            case "Extreme":
                return 3;

            default:
                throw new IllegalArgumentException(
                        "Unknown UHI class: " + className
                );
        }
    }

    private static String className(int classNumber) {

        switch (classNumber) {

            case 0:
                return "Low";

            case 1:
                return "Moderate";

            case 2:
                return "High";

            case 3:
                return "Extreme";

            default:
                throw new IllegalArgumentException(
                        "Invalid class number: "
                                + classNumber
                );
        }
    }
}