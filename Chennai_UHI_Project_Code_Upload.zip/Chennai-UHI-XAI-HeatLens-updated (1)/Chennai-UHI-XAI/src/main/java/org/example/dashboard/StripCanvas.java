package org.example.dashboard;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Tooltip;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import org.example.analytics.*;

import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.function.IntConsumer;

/** 24-hour forecast strip: per grid point, forecast UHI class / actual class (if known) / heat-risk level. */
final class StripCanvas extends Canvas {
    private final AppState st;
    private final Tooltip tip = new Tooltip();
    private IntConsumer onPick = l -> {};
    private int selected = 0;
    private static final double LEFT = 46, TOP = 22, ROW = 46;

    StripCanvas(AppState st, double w) {
        super(w, TOP + 6 * ROW + 28);
        this.st = st;
        Tooltip.install(this, tip);
        tip.setShowDelay(javafx.util.Duration.millis(80));
        setOnMouseMoved(e -> {
            ForecastModel.Forecast f = st.forecast;
            tip.setText("");
            if (f == null) return;
            int l = (int) ((e.getY() - TOP) / ROW), h = (int) ((e.getX() - LEFT) / cw());
            if (l < 0 || l >= f.nLoc || h < 0 || h >= ForecastModel.MAX_H) return;
            double[] p = f.proba[l][h];
            tip.setText(String.format(Locale.ROOT, "%s  %s%nForecast UHI: %s  (L %.0f%% / M %.0f%% / H %.0f%% / E %.0f%%)%n%s%nAir temp %.1f \u00B0C, humidity %.0f%%%nAdjusted heat index %.1f \u00B0C -> %s",
                    st.ds.locShort[l], Cfg.local(st.ds.time(f.origin + h + 1)).format(DateTimeFormatter.ofPattern("EEE d MMM HH:mm", Locale.ENGLISH)) + " IST",
                    Cfg.CLASS_NAMES[f.cls[l][h]], p[0] * 100, p[1] * 100, p[2] * 100, p[3] * 100,
                    f.actual[l][h] >= 0 ? "Actual UHI class: " + Cfg.CLASS_NAMES[f.actual[l][h]] : "Actual: not in dataset (true forecast)",
                    f.tempC[l][h], f.rh[l], f.adjHi[l][h], HeatRisk.LEVELS[f.level[l][h]]));
        });
        setOnMouseClicked(e -> {
            int l = (int) ((e.getY() - TOP) / ROW);
            if (l >= 0 && l < st.ds.nLoc) { selected = l; draw(); onPick.accept(l); }
        });
        st.dark.addListener((o, a, b) -> draw());
        widthProperty().addListener((o, a, b) -> draw());
    }

    void onPick(IntConsumer c) { onPick = c; }
    void select(int l) { selected = l; draw(); }
    private double cw() { return (getWidth() - LEFT - 4) / ForecastModel.MAX_H; }

    void draw() {
        GraphicsContext g = getGraphicsContext2D();
        g.clearRect(0, 0, getWidth(), getHeight());
        ForecastModel.Forecast f = st.forecast;
        if (f == null) return;
        boolean dark = st.dark.get();
        Color ink = dark ? Color.web("#E5E7EB") : Color.web("#111827"), muted = dark ? Color.web("#94A3B8") : Color.web("#6B7280");
        double cw = cw();
        g.setFont(Font.font(10));
        g.setTextAlign(TextAlignment.CENTER);
        g.setFill(muted);
        for (int h = 0; h < ForecastModel.MAX_H; h += 3)
            g.fillText(Cfg.local(st.ds.time(f.origin + h + 1)).format(DateTimeFormatter.ofPattern("HH:mm")), LEFT + h * cw + cw / 2, 13);
        for (int l = 0; l < f.nLoc; l++) {
            double y = TOP + l * ROW;
            if (l == selected) { g.setFill(dark ? Color.web("#334155") : Color.web("#E6F2F5")); g.fillRoundRect(0, y - 3, getWidth(), ROW - 2, 8, 8); }
            g.setFill(ink);
            g.setFont(Font.font("System", FontWeight.BOLD, 12));
            g.setTextAlign(TextAlignment.LEFT);
            g.fillText(st.ds.locShort[l], 8, y + 22);
            for (int h = 0; h < ForecastModel.MAX_H; h++) {
                double x = LEFT + h * cw;
                g.setFill(Ui.color(Palette.CLASS[f.cls[l][h]]));
                g.fillRect(x, y, cw - 1, 14);
                if (f.actual[l][h] >= 0) {
                    g.setFill(Ui.color(Palette.CLASS[f.actual[l][h]]));
                    g.fillRect(x, y + 15, cw - 1, 8);
                } else {
                    g.setFill(dark ? Color.web("#273449") : Color.web("#E5E7EB"));
                    g.fillRect(x, y + 15, cw - 1, 8);
                }
                g.setFill(Ui.color(Palette.RISK[f.level[l][h]]));
                g.fillRect(x, y + 24, cw - 1, 14);
            }
        }
        g.setFont(Font.font(9.5));
        g.setFill(muted);
        g.setTextAlign(TextAlignment.LEFT);
        g.fillText("Each row: forecast UHI class (top) | actual class if the hour exists in the dataset (middle, thin) | forecast heat-risk level (bottom). Times in IST.", 8, TOP + 6 * ROW + 16);
    }
}
