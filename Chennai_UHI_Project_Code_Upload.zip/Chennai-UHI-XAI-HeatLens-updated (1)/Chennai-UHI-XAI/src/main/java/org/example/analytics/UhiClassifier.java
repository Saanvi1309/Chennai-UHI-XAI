package org.example.analytics;

/** Common interface: scaled 28-feature row in, 4 class probabilities out. */
public interface UhiClassifier {
    String name();
    double[] predictProba(double[] scaledFeatures);

    default int predict(double[] scaledFeatures) {
        double[] p = predictProba(scaledFeatures);
        int b = 0;
        for (int i = 1; i < p.length; i++) if (p[i] > p[b]) b = i;
        return b;
    }

    static void softmaxInPlace(double[] z) {
        double m = Double.NEGATIVE_INFINITY;
        for (double v : z) m = Math.max(m, v);
        double s = 0;
        for (int i = 0; i < z.length; i++) { z[i] = Math.exp(z[i] - m); s += z[i]; }
        for (int i = 0; i < z.length; i++) z[i] /= s;
    }
}
