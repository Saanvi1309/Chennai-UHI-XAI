package org.example;

import ai.djl.Model;
import ai.djl.ndarray.NDArray;
import ai.djl.ndarray.NDList;
import ai.djl.ndarray.NDManager;
import ai.djl.ndarray.types.DataType;
import ai.djl.ndarray.types.Shape;
import ai.djl.nn.Activation;
import ai.djl.nn.SequentialBlock;
import ai.djl.nn.core.Linear;
import ai.djl.nn.norm.Dropout;
import ai.djl.training.ParameterStore;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.Reader;
import java.nio.FloatBuffer;
import java.nio.file.Files;
import java.nio.file.Path;

public class UHIEvaluator {

    private static final int NUM_FEATURES = 28;
    private static final int NUM_CLASSES = 4;
    private static final int BATCH_SIZE = 128;

    private static final String[] CLASS_NAMES = {
            "Low",
            "Moderate",
            "High",
            "Extreme"
    };

    public static void main(String[] args) throws Exception {

        System.out.println("======================================");
        System.out.println("UHI MODEL EVALUATION");
        System.out.println("======================================");

        Path projectPath = Path.of(System.getProperty("user.dir"));

        Path modelDir = projectPath.resolve("models");
        Path testFile = projectPath.resolve(
                "data/processed/test_scaled.csv"
        );

        System.out.println();
        System.out.println("Model directory:");
        System.out.println(modelDir.toAbsolutePath());

        System.out.println();
        System.out.println("Test file:");
        System.out.println(testFile.toAbsolutePath());

        if (!Files.exists(modelDir)) {
            System.out.println("ERROR: Models directory not found!");
            return;
        }

        if (!Files.exists(testFile)) {
            System.out.println("ERROR: Test file not found!");
            return;
        }

        System.out.println();
        System.out.println("Required files found.");

        // --------------------------------------------------
        // CREATE THE SAME NETWORK USED DURING TRAINING
        // --------------------------------------------------

        System.out.println();
        System.out.println("Creating neural network...");

        SequentialBlock network = new SequentialBlock();

        network.add(
                Linear.builder()
                        .setUnits(128)
                        .build()
        );

        network.add(Activation::relu);

        network.add(
                Dropout.builder()
                        .optRate(0.30f)
                        .build()
        );

        network.add(
                Linear.builder()
                        .setUnits(64)
                        .build()
        );

        network.add(Activation::relu);

        network.add(
                Dropout.builder()
                        .optRate(0.20f)
                        .build()
        );

        network.add(
                Linear.builder()
                        .setUnits(32)
                        .build()
        );

        network.add(Activation::relu);

        network.add(
                Linear.builder()
                        .setUnits(NUM_CLASSES)
                        .build()
        );

        System.out.println("Network created.");

        // --------------------------------------------------
        // LOAD TRAINED MODEL PARAMETERS
        // --------------------------------------------------

        System.out.println();
        System.out.println("Loading trained model...");

        Model model = Model.newInstance("uhi-dnn");

        model.setBlock(network);

        model.load(modelDir, "uhi-dnn");

        System.out.println("Trained model loaded successfully!");

        // --------------------------------------------------
        // READ TEST DATA
        // --------------------------------------------------

        System.out.println();
        System.out.println("Loading test data...");

        int[][] confusionMatrix =
                new int[NUM_CLASSES][NUM_CLASSES];

        long totalRecords = 0;
        long correctRecords = 0;

        try (
                NDManager manager = NDManager.newBaseManager();
                Reader reader = Files.newBufferedReader(testFile);
                CSVParser parser = CSVFormat.DEFAULT
                        .builder()
                        .setHeader()
                        .setSkipHeaderRecord(true)
                        .build()
                        .parse(reader)
        ) {

            float[] featureArray =
                    new float[BATCH_SIZE * NUM_FEATURES];

            int[] labelArray =
                    new int[BATCH_SIZE];

            int batchCount = 0;

            ParameterStore parameterStore =
                    new ParameterStore(manager, false);

            for (CSVRecord record : parser) {

                for (int i = 0; i < NUM_FEATURES; i++) {

                    featureArray[
                            batchCount * NUM_FEATURES + i
                            ] = Float.parseFloat(
                            record.get(i)
                    );
                }

                String className = record.get(NUM_FEATURES);

                int actualClass;

                switch (className) {
                    case "Low":
                        actualClass = 0;
                        break;

                    case "Moderate":
                        actualClass = 1;
                        break;

                    case "High":
                        actualClass = 2;
                        break;

                    case "Extreme":
                        actualClass = 3;
                        break;

                    default:
                        throw new IllegalArgumentException(
                                "Unknown UHI class: " + className
                        );
                }

                labelArray[batchCount] = actualClass;

                batchCount++;

                // Process full batch
                if (batchCount == BATCH_SIZE) {

                    EvaluationResult result =
                            evaluateBatch(
                                    model,
                                    parameterStore,
                                    manager,
                                    featureArray,
                                    labelArray,
                                    batchCount
                            );

                    correctRecords += result.correct;
                    totalRecords += result.total;

                    for (int i = 0; i < NUM_CLASSES; i++) {
                        for (int j = 0; j < NUM_CLASSES; j++) {
                            confusionMatrix[i][j]
                                    += result.matrix[i][j];
                        }
                    }

                    batchCount = 0;
                }
            }

            // Process final smaller batch
            if (batchCount > 0) {

                EvaluationResult result =
                        evaluateBatch(
                                model,
                                parameterStore,
                                manager,
                                featureArray,
                                labelArray,
                                batchCount
                        );

                correctRecords += result.correct;
                totalRecords += result.total;

                for (int i = 0; i < NUM_CLASSES; i++) {
                    for (int j = 0; j < NUM_CLASSES; j++) {
                        confusionMatrix[i][j]
                                += result.matrix[i][j];
                    }
                }
            }
        }

        // --------------------------------------------------
        // CALCULATE METRICS
        // --------------------------------------------------

        double accuracy =
                (double) correctRecords / totalRecords;

        double macroPrecision = 0.0;
        double macroRecall = 0.0;
        double macroF1 = 0.0;

        double[] precision =
                new double[NUM_CLASSES];

        double[] recall =
                new double[NUM_CLASSES];

        double[] f1 =
                new double[NUM_CLASSES];

        for (int c = 0; c < NUM_CLASSES; c++) {

            int truePositive = confusionMatrix[c][c];

            int falsePositive = 0;
            int falseNegative = 0;

            for (int r = 0; r < NUM_CLASSES; r++) {
                if (r != c) {
                    falsePositive += confusionMatrix[r][c];
                }
            }

            for (int col = 0; col < NUM_CLASSES; col++) {
                if (col != c) {
                    falseNegative += confusionMatrix[c][col];
                }
            }

            if (truePositive + falsePositive > 0) {
                precision[c] =
                        (double) truePositive
                                / (truePositive + falsePositive);
            }

            if (truePositive + falseNegative > 0) {
                recall[c] =
                        (double) truePositive
                                / (truePositive + falseNegative);
            }

            if (precision[c] + recall[c] > 0) {
                f1[c] =
                        2.0 * precision[c] * recall[c]
                                / (precision[c] + recall[c]);
            }

            macroPrecision += precision[c];
            macroRecall += recall[c];
            macroF1 += f1[c];
        }

        macroPrecision /= NUM_CLASSES;
        macroRecall /= NUM_CLASSES;
        macroF1 /= NUM_CLASSES;

        // --------------------------------------------------
        // DISPLAY RESULTS
        // --------------------------------------------------

        System.out.println();
        System.out.println("======================================");
        System.out.println("UHI MODEL EVALUATION RESULTS");
        System.out.println("======================================");

        System.out.println();
        System.out.println("Total test records : " + totalRecords);
        System.out.println("Correct predictions: " + correctRecords);

        System.out.println();
        System.out.printf(
                "Accuracy          : %.4f%n",
                accuracy
        );

        System.out.printf(
                "Macro Precision   : %.4f%n",
                macroPrecision
        );

        System.out.printf(
                "Macro Recall      : %.4f%n",
                macroRecall
        );

        System.out.printf(
                "Macro F1-score    : %.4f%n",
                macroF1
        );

        System.out.println();
        System.out.println("CLASS-WISE RESULTS");
        System.out.println("--------------------------------------");

        for (int c = 0; c < NUM_CLASSES; c++) {

            System.out.printf(
                    "%-10s Precision=%.4f  Recall=%.4f  F1=%.4f%n",
                    CLASS_NAMES[c],
                    precision[c],
                    recall[c],
                    f1[c]
            );
        }

        System.out.println();
        System.out.println("CONFUSION MATRIX");
        System.out.println("--------------------------------------");

        System.out.println(
                "Actual \\ Predicted"
        );

        System.out.printf(
                "%-15s %8s %10s %8s %10s%n",
                "",
                "Low",
                "Moderate",
                "High",
                "Extreme"
        );

        for (int i = 0; i < NUM_CLASSES; i++) {

            System.out.printf(
                    "%-15s",
                    CLASS_NAMES[i]
            );

            for (int j = 0; j < NUM_CLASSES; j++) {

                System.out.printf(
                        "%10d",
                        confusionMatrix[i][j]
                );
            }

            System.out.println();
        }

        System.out.println();
        System.out.println("======================================");
        System.out.println("EVALUATION COMPLETED");
        System.out.println("======================================");

        model.close();
    }

    private static EvaluationResult evaluateBatch(
            Model model,
            ParameterStore parameterStore,
            NDManager manager,
            float[] featureArray,
            int[] labelArray,
            int batchSize
    ) {

        float[] batchFeatures =
                new float[batchSize * NUM_FEATURES];

        int[] batchLabels =
                new int[batchSize];

        System.arraycopy(
                featureArray,
                0,
                batchFeatures,
                0,
                batchSize * NUM_FEATURES
        );

        System.arraycopy(
                labelArray,
                0,
                batchLabels,
                0,
                batchSize
        );

        NDArray input =
                manager.create(
                        FloatBuffer.wrap(batchFeatures),
                        new Shape(batchSize, NUM_FEATURES),
                        DataType.FLOAT32
                );

        NDList inputList =
                new NDList(input);

        NDList outputList =
                model.getBlock().forward(
                        parameterStore,
                        inputList,
                        false
                );

        NDArray output =
                outputList.singletonOrThrow();

        long[] predictions =
                output.argMax(1).toLongArray();

        EvaluationResult result =
                new EvaluationResult();

        result.total = batchSize;

        for (int i = 0; i < batchSize; i++) {

            int actual = batchLabels[i];

            int predicted =
                    (int) predictions[i];

            if (actual == predicted) {
                result.correct++;
            }

            result.matrix[actual][predicted]++;
        }

        outputList.close();
        input.close();

        return result;
    }

    private static class EvaluationResult {

        long total = 0;
        long correct = 0;

        int[][] matrix =
                new int[NUM_CLASSES][NUM_CLASSES];
    }
}