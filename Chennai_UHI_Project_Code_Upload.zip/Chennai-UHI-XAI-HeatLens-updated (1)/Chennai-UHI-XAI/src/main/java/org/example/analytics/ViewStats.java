package org.example.analytics;

/** Aggregates over the rows selected by the current filter. */
public final class ViewStats {
    public int n;
    public double meanAnomaly, meanAirT, meanRh, meanHeatIndex, meanAdjHi, maxAdjHi;
    public double[] classShare = new double[Cfg.NC];
    public double[] riskShare = new double[5];
    public long[] classCount = new long[Cfg.NC];
    public long[] riskCount = new long[5];
    // per location
    public int[] locN; public double[] locMeanAnom, locExtremeShare, locDangerShare, locMeanAdjHi;
    // per hour of day / month
    public double[] hourMeanAnom = new double[24], hourExtremeShare = new double[24], hourMeanAdjHi = new double[24];
    public int[] hourN = new int[24];
    public double[] monthExtremeShare = new double[12], monthDangerShare = new double[12], monthMeanAdjHi = new double[12];
    public int[] monthN = new int[12];
    // hour x month heat-map (mean anomaly) and per-location hour profile
    public double[][] hm = new double[12][24];
    public int[][] hmN = new int[12][24];
    public double[][] locHourMeanAnom;
    // loc x month x hour counts for hot-spot search
    public int[][][] cellN, cellExtreme;
    public double[] locClassMean;  // not used by UI; reserved

    public static ViewStats compute(DataStore ds, int[] rows) {
        ViewStats v = new ViewStats();
        v.n = rows.length;
        int L = ds.nLoc;
        v.locN = new int[L]; v.locMeanAnom = new double[L]; v.locExtremeShare = new double[L];
        v.locDangerShare = new double[L]; v.locMeanAdjHi = new double[L];
        v.locHourMeanAnom = new double[L][24];
        int[][] lh = new int[L][24];
        v.cellN = new int[L][12][24]; v.cellExtreme = new int[L][12][24];
        int[] hExt = new int[24], mExt = new int[12], mDan = new int[12];
        int[] lExt = new int[L], lDan = new int[L];
        double sA = 0, sT = 0, sR = 0, sH = 0, sAdj = 0;
        v.maxAdjHi = Double.NEGATIVE_INFINITY;
        for (int r : rows) {
            int l = ds.loc[r], h = ds.hour[r], m = ds.month[r], c = ds.cls[r], k = ds.risk[r];
            sA += ds.anomaly[r]; sT += ds.x[r][Cfg.F_AIR_T]; sR += ds.x[r][Cfg.F_RH];
            sH += ds.heatIndex[r]; sAdj += ds.adjHi[r];
            v.maxAdjHi = Math.max(v.maxAdjHi, ds.adjHi[r]);
            v.classCount[c]++; v.riskCount[k]++;
            v.locN[l]++; v.locMeanAnom[l] += ds.anomaly[r]; v.locMeanAdjHi[l] += ds.adjHi[r];
            v.hourN[h]++; v.hourMeanAnom[h] += ds.anomaly[r]; v.hourMeanAdjHi[h] += ds.adjHi[r];
            v.monthN[m]++; v.monthMeanAdjHi[m] += ds.adjHi[r];
            v.hm[m][h] += ds.anomaly[r]; v.hmN[m][h]++;
            v.locHourMeanAnom[l][h] += ds.anomaly[r]; lh[l][h]++;
            v.cellN[l][m][h]++;
            if (c == 3) { lExt[l]++; hExt[h]++; mExt[m]++; v.cellExtreme[l][m][h]++; }
            if (k >= 3) { lDan[l]++; mDan[m]++; }
        }
        if (v.n == 0) { v.maxAdjHi = Double.NaN; return v; }
        v.meanAnomaly = sA / v.n; v.meanAirT = sT / v.n; v.meanRh = sR / v.n;
        v.meanHeatIndex = sH / v.n; v.meanAdjHi = sAdj / v.n;
        for (int c = 0; c < Cfg.NC; c++) v.classShare[c] = (double) v.classCount[c] / v.n;
        for (int k = 0; k < 5; k++) v.riskShare[k] = (double) v.riskCount[k] / v.n;
        for (int l = 0; l < L; l++) if (v.locN[l] > 0) {
            v.locMeanAnom[l] /= v.locN[l]; v.locMeanAdjHi[l] /= v.locN[l];
            v.locExtremeShare[l] = (double) lExt[l] / v.locN[l]; v.locDangerShare[l] = (double) lDan[l] / v.locN[l];
        }
        for (int h = 0; h < 24; h++) if (v.hourN[h] > 0) {
            v.hourMeanAnom[h] /= v.hourN[h]; v.hourMeanAdjHi[h] /= v.hourN[h];
            v.hourExtremeShare[h] = (double) hExt[h] / v.hourN[h];
        }
        for (int m = 0; m < 12; m++) if (v.monthN[m] > 0) {
            v.monthMeanAdjHi[m] /= v.monthN[m];
            v.monthExtremeShare[m] = (double) mExt[m] / v.monthN[m];
            v.monthDangerShare[m] = (double) mDan[m] / v.monthN[m];
            for (int h = 0; h < 24; h++) if (v.hmN[m][h] > 0) v.hm[m][h] /= v.hmN[m][h];
        }
        for (int l = 0; l < L; l++) for (int h = 0; h < 24; h++) if (lh[l][h] > 0) v.locHourMeanAnom[l][h] /= lh[l][h];
        return v;
    }
}
