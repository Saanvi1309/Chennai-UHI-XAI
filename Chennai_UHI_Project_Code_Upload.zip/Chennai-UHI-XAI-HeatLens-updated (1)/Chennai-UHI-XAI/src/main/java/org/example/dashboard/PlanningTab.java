package org.example.dashboard;

import javafx.concurrent.Task;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import org.example.analytics.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Urban planning intelligence: transparent priority scores per grid point and a model-based mitigation impact comparison. */
final class PlanningTab extends ScrollPane {
    private final AppState st;
    private final TableView<String[]> prio = Ui.table(new String[]{"Point", "Area", "Heat rank", "Anomaly \u00B0C", "NDVI", "Green dist. m", "Building dens.", "Road dens.", "Water dist. m",
            "Trees", "Green space", "Cool roofs", "Roadside", "Water", "Suggested intervention"}, new double[]{45, 150, 70, 80, 55, 90, 95, 80, 90, 55, 85, 75, 75, 55, 420});
    private final TableView<String[]> impact = Ui.table(new String[]{"Point", "Current predicted class", "Baseline predicted LST \u00B0C", "Scenario predicted LST \u00B0C", "Difference \u00B0C", "Reliability of the simulated change", "Suggested intervention"},
            new double[]{45, 150, 170, 170, 100, 300, 420});
    private final ComboBox<String> preset = new ComboBox<>();
    private final Label corr = Ui.note(""), status = Ui.note("");

    PlanningTab(AppState st, Node simulator) {
        this.st = st;
        Label how = Ui.note("Scores (0 = low, 1 = high) are transparent screening rules over the SIX measured grid cells (each about 0.25\u00B0, roughly 28 km), built from observed heat exposure and the static land-cover indicators in the dataset. "
                + "They indicate where a measure is most worth investigating, not where to build. Simulated temperatures come from editing the DNN's input features: a MODEL-BASED SIMULATION, not a guaranteed real-world temperature reduction. "
                + "Cool roofs cannot be simulated because the dataset has no roof-albedo feature.");
        how.getStyleClass().add("banner");
        Label rules = Ui.note("Tree plantation = 0.5 heat + 0.3 vegetation deficit + 0.2 distance to green space.  Green-space planning = 0.5 distance to green + 0.3 vegetation deficit + 0.2 heat.  "
                + "Cool roofs = 0.5 building density + 0.5 heat (only where building density > 0).  Roadside vegetation = 0.5 road density + 0.3 heat + 0.2 vegetation deficit (only where road density > 0).  "
                + "Water-body conservation = 0.6 closeness to water + 0.4 heat.  A point whose best score is below 0.5 gets 'maintain current cover'. Inputs are min-max scaled across the six points.");
        VBox cPrio = Ui.card("Planning priorities: trees, green space, cool roofs, roadside vegetation, water bodies, heat-risk rank", "Follows the filters on the left.", new VBox(8, prio, rules, corr));
        for (String s : PlanningEngine.PRESETS) preset.getItems().add(s);
        preset.getSelectionModel().select(0);
        preset.valueProperty().addListener((o, a, b) -> runImpact());
        VBox cImp = Ui.card("Mitigation impact comparison (baseline vs simulated scenario)", "Uses " + st.ms.primary.name() + " on the non-training hours in view. Predicted LST = observed grid-median reference LST + the model's expected anomaly. "
                + "Changes smaller than the model error (about 0.3 \u00B0C) are not distinguishable from noise; warming responses to a cooling measure are flagged as model artefacts (the six points make the static features act as location IDs).",
                new VBox(8, new HBox(10, new Label("Scenario"), preset), impact, status));
        Tab t1 = new Tab("Planning intelligence", Ui.scroll(Ui.page(how, cPrio, cImp)));
        Tab t2 = new Tab("Mitigation simulator (sliders)", simulator);
        TabPane tp = new TabPane(t1, t2);
        tp.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        setContent(tp);
        setFitToWidth(true);
        getStyleClass().add("page-scroll");
        st.onView(this::update);
    }

    private void update() {
        DataStore ds = st.ds;
        PlanningEngine.LocPlan[] pl = PlanningEngine.plans(ds, st.rows);
        List<String[]> rows = new ArrayList<>();
        for (PlanningEngine.LocPlan p : pl) {
            String[] r = new String[15];
            r[0] = ds.locShort[p.loc]; r[1] = Cfg.areaHint(ds.locLat[p.loc], ds.locLon[p.loc]); r[2] = String.valueOf(p.heatRank);
            r[3] = Double.isNaN(p.meanAnomaly) ? "-" : String.format(Locale.ROOT, "%+.2f", p.meanAnomaly);
            r[4] = Ui.num(p.ndvi, 2); r[5] = Ui.num(p.distGreen, 0); r[6] = Ui.num(p.building, 0); r[7] = Ui.num(p.road, 3); r[8] = Ui.num(p.distWater, 0);
            for (int k = 0; k < 5; k++) r[9 + k] = Double.isNaN(p.score[k]) ? "n/a" : Ui.num(p.score[k], 2);
            r[14] = PlanningEngine.intervention(p);
            rows.add(r);
        }
        Ui.fill(prio, rows);
        double c = PlanningEngine.buildingHeatCorrelation(ds, st.rows);
        corr.setText(String.format(Locale.ROOT, "Building-density analysis: rank correlation between building density and mean UHI anomaly across the six points = %.2f (n = 6, indicative only; building density is 0 at three of the six points).", c));
        runImpact();
    }

    private void runImpact() {
        if (st.rows == null || st.rows.length == 0) return;
        final DataStore ds = st.ds;
        final int[] base = st.rows;
        final int k = Math.max(0, preset.getSelectionModel().getSelectedIndex());
        status.setText("Running the DNN on the edited inputs...");
        Task<List<String[]>> task = new Task<>() {
            @Override protected List<String[]> call() {
                int c = 0;
                for (int r : base) if (ds.split[r] != 0) c++;
                int[] use = new int[c]; c = 0;
                for (int r : base) if (ds.split[r] != 0) use[c++] = r;
                if (use.length == 0) use = base;
                PlanningEngine.LocPlan[] pl = PlanningEngine.plans(ds, base);
                PlanningEngine.Impact[] im = PlanningEngine.impacts(ds, st.ms.scaler, st.ms.primary, use, PlanningEngine.preset(k), pl, 2500);
                List<String[]> out = new ArrayList<>();
                for (PlanningEngine.Impact i : im)
                    out.add(new String[]{ds.locShort[i.loc()], i.currentClass() < 0 ? "-" : Cfg.CLASS_NAMES[i.currentClass()], Ui.num(i.baseLst(), 2), Ui.num(i.scenLst(), 2),
                            Double.isNaN(i.delta()) ? "-" : String.format(Locale.ROOT, "%+.2f", i.scenLst() - i.baseLst()), i.reliability(), i.intervention()});
                return out;
            }
        };
        task.setOnSucceeded(e -> { Ui.fill(impact, task.getValue()); status.setText("Model-based simulation on non-training hours; not a guaranteed real-world reduction."); });
        task.setOnFailed(e -> status.setText("Simulation failed: " + task.getException()));
        Thread th = new Thread(task, "uhi-impact");
        th.setDaemon(true);
        th.start();
    }
}
