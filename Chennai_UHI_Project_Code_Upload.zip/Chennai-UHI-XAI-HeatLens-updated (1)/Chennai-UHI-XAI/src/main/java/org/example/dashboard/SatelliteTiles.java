package org.example.dashboard;

import javafx.application.Platform;
import javafx.scene.image.Image;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Loads web-mercator map tiles (Esri World Imagery satellite + optional place-name overlay) on background threads,
 * keeps them in memory and in a small on-disk cache (~/.heatlens/tiles) so the map also works offline after the first view.
 */
final class SatelliteTiles {
    static final String SATELLITE = "sat";
    static final String LABELS = "lbl";

    private static final Map<String, Image> MEM = new ConcurrentHashMap<>();
    private static final Map<String, Long> FAILED = new ConcurrentHashMap<>();
    private static final Map<String, List<Runnable>> WAITING = new ConcurrentHashMap<>();
    private static final ExecutorService POOL = Executors.newFixedThreadPool(6, r -> {
        Thread t = new Thread(r, "uhi-tiles");
        t.setDaemon(true);
        return t;
    });
    private static final Path DIR = Path.of(System.getProperty("user.home"), ".heatlens", "tiles");
    private static volatile int okCount, failCount;

    private SatelliteTiles() {}

    static boolean anyLoaded() { return okCount > 0; }
    static boolean looksOffline() { return okCount == 0 && failCount >= 3; }

    private static String key(String layer, int z, int x, int y) { return layer + "/" + z + "/" + x + "/" + y; }

    private static String url(String layer, int z, int x, int y) {
        String svc = LABELS.equals(layer) ? "Reference/World_Boundaries_and_Places/MapServer" : "World_Imagery/MapServer";
        return "https://server.arcgisonline.com/ArcGIS/rest/services/" + svc + "/tile/" + z + "/" + y + "/" + x;
    }

    /** Returns the tile if already in memory (never blocks). */
    static Image peek(String layer, int z, int x, int y) { return MEM.get(key(layer, z, x, y)); }

    /** Returns the tile if available, otherwise schedules a load and calls onLoaded (on the FX thread) when it arrives. */
    static Image get(String layer, int z, int x, int y, Runnable onLoaded) {
        String k = key(layer, z, x, y);
        Image img = MEM.get(k);
        if (img != null) return img;
        Long failedAt = FAILED.get(k);
        if (failedAt != null && System.currentTimeMillis() - failedAt < 20_000) return null;
        synchronized (WAITING) {
            List<Runnable> w = WAITING.get(k);
            if (w != null) { w.add(onLoaded); return null; }
            w = new ArrayList<>();
            w.add(onLoaded);
            WAITING.put(k, w);
        }
        POOL.execute(() -> load(layer, z, x, y, k));
        return null;
    }

    private static void load(String layer, int z, int x, int y, String k) {
        Image img = null;
        try {
            Path f = DIR.resolve(layer).resolve(String.valueOf(z)).resolve(x + "_" + y + ".img");
            byte[] data = null;
            if (Files.isRegularFile(f)) data = Files.readAllBytes(f);
            if (data == null || data.length < 100) {
                HttpURLConnection c = (HttpURLConnection) new URL(url(layer, z, x, y)).openConnection();
                c.setConnectTimeout(6000);
                c.setReadTimeout(9000);
                c.setRequestProperty("User-Agent", "HeatLens-UHI-Dashboard/1.0 (research)");
                if (c.getResponseCode() == 200) {
                    try (InputStream in = c.getInputStream(); ByteArrayOutputStream bo = new ByteArrayOutputStream()) {
                        in.transferTo(bo);
                        data = bo.toByteArray();
                    }
                    try {
                        Files.createDirectories(f.getParent());
                        Files.write(f, data);
                    } catch (Exception ignore) { /* cache is optional */ }
                }
            }
            if (data != null && data.length >= 100) {
                Image im = new Image(new ByteArrayInputStream(data));
                if (!im.isError()) img = im;
            }
        } catch (Exception ignore) { /* handled below */ }
        final Image res = img;
        if (res != null) { MEM.put(k, res); okCount++; FAILED.remove(k); }
        else { FAILED.put(k, System.currentTimeMillis()); failCount++; }
        List<Runnable> w;
        synchronized (WAITING) { w = WAITING.remove(k); }
        if (w != null) Platform.runLater(() -> { for (Runnable r : w) r.run(); });
    }
}
