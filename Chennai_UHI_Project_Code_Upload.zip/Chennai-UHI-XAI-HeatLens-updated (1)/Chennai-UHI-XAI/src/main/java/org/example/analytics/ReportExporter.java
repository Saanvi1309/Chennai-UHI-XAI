package org.example.analytics;

import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/** One-click exports of the filtered dashboard view: PDF report, summary CSV and raw-rows CSV. */
public final class ReportExporter {
    private ReportExporter() {}

    private static final String[] MON = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

    public static String stamp() { return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")); }

    // =========================================================== CSV

    public static Path exportSummaryCsv(DataStore ds, Filter f, ViewStats v, Path out) throws IOException {
        Files.createDirectories(out.toAbsolutePath().getParent());
        try (Writer w = Files.newBufferedWriter(out, StandardCharsets.UTF_8)) {
            w.write("section,key,value\n");
            line(w, "filter", "description", f.describe(ds).replace(',', ';'));
            line(w, "kpi", "rows", String.valueOf(v.n));
            line(w, "kpi", "mean_uhi_anomaly_c", fmt(v.meanAnomaly));
            line(w, "kpi", "mean_air_temp_c", fmt(v.meanAirT));
            line(w, "kpi", "mean_relative_humidity_pct", fmt(v.meanRh));
            line(w, "kpi", "mean_heat_index_c", fmt(v.meanHeatIndex));
            line(w, "kpi", "mean_adjusted_heat_index_c", fmt(v.meanAdjHi));
            for (int c = 0; c < Cfg.NC; c++) line(w, "uhi_class_share", Cfg.CLASS_NAMES[c], fmt(v.classShare[c]));
            for (int k = 0; k < 5; k++) line(w, "heat_risk_share", HeatRisk.LEVELS[k], fmt(v.riskShare[k]));
            for (int l = 0; l < ds.nLoc; l++) {
                line(w, "location_mean_anomaly_c", ds.locShort[l], fmt(v.locMeanAnom[l]));
                line(w, "location_extreme_share", ds.locShort[l], fmt(v.locExtremeShare[l]));
                line(w, "location_danger_or_worse_share", ds.locShort[l], fmt(v.locDangerShare[l]));
                line(w, "location_mean_adjusted_heat_index_c", ds.locShort[l], fmt(v.locMeanAdjHi[l]));
            }
            for (int h = 0; h < 24; h++) {
                line(w, "hour_ist_mean_anomaly_c", Cfg.hourLabel(h), fmt(v.hourMeanAnom[h]));
                line(w, "hour_ist_extreme_share", Cfg.hourLabel(h), fmt(v.hourExtremeShare[h]));
                line(w, "hour_ist_mean_adjusted_heat_index_c", Cfg.hourLabel(h), fmt(v.hourMeanAdjHi[h]));
            }
            for (int m = 0; m < 12; m++) {
                line(w, "month_extreme_share", MON[m], fmt(v.monthExtremeShare[m]));
                line(w, "month_danger_or_worse_share", MON[m], fmt(v.monthDangerShare[m]));
                line(w, "month_mean_adjusted_heat_index_c", MON[m], fmt(v.monthMeanAdjHi[m]));
            }
        }
        return out;
    }

    public static Path exportRowsCsv(DataStore ds, ModelSuite ms, int[] rows, Path out) throws IOException {
        Files.createDirectories(out.toAbsolutePath().getParent());
        try (Writer w = Files.newBufferedWriter(out, StandardCharsets.UTF_8)) {
            StringBuilder h = new StringBuilder("timestamp_utc,timestamp_ist,location,latitude,longitude,air_temperature_c,relative_humidity_pct,"
                    + "land_surface_temperature_c,uhi_anomaly_c,uhi_class,heat_index_c,adjusted_heat_index_c,heat_risk_level");
            boolean pred = ms != null && ms.proba != null;
            if (pred) for (String n : ms.modelNames) h.append(",pred_").append(n.toLowerCase(Locale.ROOT).replace(' ', '_'));
            w.write(h.append('\n').toString());
            DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            for (int r : rows) {
                LocalDateTime utc = ds.time(ds.hourIdx[r]);
                StringBuilder sb = new StringBuilder();
                sb.append(df.format(utc)).append(',').append(df.format(Cfg.local(utc))).append(',').append(ds.locShort[ds.loc[r]]).append(',')
                        .append(ds.locLat[ds.loc[r]]).append(',').append(ds.locLon[ds.loc[r]]).append(',')
                        .append(fmt(ds.x[r][Cfg.F_AIR_T])).append(',').append(fmt(ds.x[r][Cfg.F_RH])).append(',')
                        .append(fmt(ds.lst[r])).append(',').append(fmt(ds.anomaly[r])).append(',').append(Cfg.CLASS_NAMES[ds.cls[r]]).append(',')
                        .append(fmt(ds.heatIndex[r])).append(',').append(fmt(ds.adjHi[r])).append(',').append(HeatRisk.LEVELS[ds.risk[r]]);
                if (pred) for (int m = 0; m < ms.models.length; m++) {
                    float[] p = ms.proba[m][r];
                    if (p == null) { sb.append(','); continue; }
                    int b = 0;
                    for (int c = 1; c < p.length; c++) if (p[c] > p[b]) b = c;
                    sb.append(',').append(Cfg.CLASS_NAMES[b]);
                }
                w.write(sb.append('\n').toString());
            }
        }
        return out;
    }

    private static void line(Writer w, String a, String b, String c) throws IOException { w.write(a + "," + b + "," + c + "\n"); }
    private static String fmt(double d) { return String.format(Locale.ROOT, "%.4f", d); }

    // =========================================================== PDF

    public static Path exportPdf(DataStore ds, ModelSuite ms, Filter f, int[] rows, ViewStats v, List<InsightEngine.Insight> insights,
                                 ForecastModel.Forecast fc, List<InsightEngine.Insight> fcInsights, Path out) throws IOException {
        PdfDoc doc = new PdfDoc();
        String when = LocalDateTime.now().format(DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm"));

        // ---------------- page 1 : overview
        PdfDoc.Page p = doc.newPage();
        header(p, "Chennai Urban Heat Island - View Report", "Generated " + when + "   |   Times in " + Cfg.TZ_NAME + " (data timestamps are UTC)");
        double y = p.paragraph(40, 88, 515, 7.5, false, Palette.GREY, "Filters: " + f.describe(ds), 10);
        y += 6;
        String[][] kpis = {
                {"Hours in view", String.format(Locale.ROOT, "%,d", v.n)},
                {"Mean UHI anomaly", String.format(Locale.ROOT, "%+.2f \u00B0C", v.meanAnomaly)},
                {"Extreme UHI share", pct(v.classShare[3])},
                {"Danger or worse", pct(v.riskShare[3] + v.riskShare[4])},
                {"Mean air temperature", String.format(Locale.ROOT, "%.1f \u00B0C", v.meanAirT)},
                {"Mean humidity", String.format(Locale.ROOT, "%.0f %%", v.meanRh)}};
        for (int i = 0; i < 6; i++) tile(p, 40 + (i % 3) * 175, y + (i / 3) * 56, 165, 46, kpis[i][0], kpis[i][1]);
        y += 122;
        bars(p, 40, y, 250, 150, "UHI class distribution", Cfg.CLASS_NAMES, v.classShare, Palette.CLASS, true);
        bars(p, 305, y, 250, 150, "Heat-risk level distribution", new String[]{"Normal", "Caution", "Ext. Caution", "Danger", "Ext. Danger"}, v.riskShare, Palette.RISK, true);
        y += 170;
        p.text(40, y, 11, true, Palette.NAVY, "By location");
        y += 8;
        String[] hd = {"Point", "Hours", "Mean anomaly", "Extreme", "Danger+", "Adj. heat index"};
        double[] cw = {215, 50, 70, 55, 55, 70};
        tableHeader(p, 40, y, hd, cw);
        y += 16;
        for (int l = 0; l < ds.nLoc; l++) {
            if (v.locN[l] == 0) continue;
            String[] row = {ds.locName[l], String.valueOf(v.locN[l]), String.format(Locale.ROOT, "%+.2f \u00B0C", v.locMeanAnom[l]),
                    pct(v.locExtremeShare[l]), pct(v.locDangerShare[l]), String.format(Locale.ROOT, "%.1f \u00B0C", v.locMeanAdjHi[l])};
            tableRow(p, 40, y, row, cw, l % 2 == 0);
            y += 15;
        }
        footer(p, 1);

        // ---------------- page 2 : patterns
        p = doc.newPage();
        header(p, "Daily and seasonal patterns", "Mean UHI anomaly = land surface temperature minus the median of the grid points at the same hour");
        double[][] series = new double[ds.nLoc][];
        String[] names = new String[ds.nLoc];
        int[] cols = {0x1F77B4, 0xFF7F0E, 0x2CA02C, 0xD62728, 0x9467BD, 0x8C564B};
        int[] lc = new int[ds.nLoc];
        for (int l = 0; l < ds.nLoc; l++) { series[l] = new double[24]; for (int i = 0; i < 24; i++) series[l][i] = v.locHourMeanAnom[l][Cfg.hourAt(i)]; names[l] = ds.locShort[l]; lc[l] = cols[l % cols.length]; }
        lines(p, 40, 90, 515, 200, "Mean UHI anomaly by hour of day (" + Cfg.TZ_NAME + ")", series, names, lc);
        double[] monthBars = new double[12];
        System.arraycopy(v.monthExtremeShare, 0, monthBars, 0, 12);
        bars(p, 40, 310, 250, 150, "Extreme-UHI share by month", MON, monthBars, new int[]{Palette.CLASS[3]}, true);
        double[] dang = new double[12];
        System.arraycopy(v.monthDangerShare, 0, dang, 0, 12);
        bars(p, 305, 310, 250, 150, "Danger-or-worse heat stress by month", MON, dang, new int[]{Palette.RISK[3]}, true);
        heat(p, 40, 485, 515, 215, "Mean UHI anomaly: month x hour of day (" + Cfg.TZ_NAME + ")", v);
        footer(p, 2);

        // ---------------- page 3 : insights + forecast
        p = doc.newPage();
        header(p, "Alerts, insights and recommendations", "Rule-based text generated from the filtered view and the 24-hour forecast");
        y = 92;
        if (fc != null) {
            p.text(40, y, 11, true, Palette.NAVY, "24-hour forecast (issued " + Cfg.local(ds.time(fc.origin)).format(DateTimeFormatter.ofPattern("EEE d MMM HH:mm")) + " " + Cfg.TZ_NAME + ")");
            y += 10;
            strip(p, 40, y, 515, fc, ds);
            y += 14 + fc.nLoc * 16 + 40;
        }
        List<InsightEngine.Insight> all = new java.util.ArrayList<>();
        if (fcInsights != null) all.addAll(fcInsights);
        all.addAll(insights);
        for (InsightEngine.Insight in : all) {
            if (y > 770) { footer(p, 3); p = doc.newPage(); header(p, "Alerts, insights and recommendations (cont.)", ""); y = 92; }
            int color = switch (in.kind()) { case "alert" -> Palette.RISK[3]; case "warn" -> Palette.RISK[2]; case "rec" -> Palette.TEAL; default -> Palette.GREY; };
            p.rect(40, y - 9, 4, 12, color);
            p.text(50, y, 9, true, Palette.INK, in.title());
            y = p.paragraph(50, y + 11, 505, 8, false, 0x374151, in.text(), 10.5) + 5;
        }
        footer(p, 3);

        // ---------------- page 4 : models
        p = doc.newPage();
        header(p, "Model comparison and forecast accuracy", "DNN vs gradient boosting vs logistic regression, scored on validation/test rows inside the filtered view");
        y = 96;
        if (ms != null && ms.proba != null) {
            ModelSuite.Row[] rs = ms.compare(ds, rows, true, true);
            String[] mh = {"Model", "Rows", "Accuracy", "Macro-F1", "+/-1 class", "Log-loss", "F1 Low", "F1 Mod.", "F1 High", "F1 Extr."};
            double[] mw = {110, 40, 52, 52, 52, 48, 40, 40, 40, 41};
            tableHeader(p, 40, y, mh, mw);
            y += 16;
            int i = 0;
            for (ModelSuite.Row r : rs) {
                String[] row = {r.name(), String.valueOf(r.n()), pct(r.accuracy()), pct(r.macroF1()), pct(r.adjacentAccuracy()),
                        String.format(Locale.ROOT, "%.3f", r.logLoss()), pct(r.f1()[0]), pct(r.f1()[1]), pct(r.f1()[2]), pct(r.f1()[3])};
                tableRow(p, 40, y, row, mw, i++ % 2 == 0);
                y += 15;
            }
            y += 12;
        }
        if (ms != null && ms.forecast != null && ms.forecast.testEval != null) {
            ForecastModel.Eval e = ms.forecast.testEval;
            p.text(40, y, 11, true, Palette.NAVY, "Forecast accuracy on the test period (Jul-Dec 2025)");
            y += 8;
            String[] fh = {"Horizon", "Forecast acc.", "Macro-F1", "Yesterday", "Climatology", "Temp MAE", "Humidity MAE"};
            double[] fw = {60, 75, 70, 70, 75, 80, 85};
            tableHeader(p, 40, y, fh, fw);
            y += 16;
            for (int i = 0; i < e.horizons.length; i++) {
                String[] row = {"+" + e.horizons[i] + " h", pct(e.acc[i]), pct(e.macroF1[i]), pct(e.yesterdayAcc[i]), pct(e.climAcc[i]),
                        String.format(Locale.ROOT, "%.2f \u00B0C", e.maeT[i]), String.format(Locale.ROOT, "%.1f %%", e.maeRh[i])};
                tableRow(p, 40, y, row, fw, i % 2 == 0);
                y += 15;
            }
            y += 14;
        }
        p.text(40, y, 11, true, Palette.NAVY, "Notes and limitations");
        y += 14;
        String[] notes = {
                "The dataset has 6 grid points, so static features (land use, building density, ...) act as location identifiers and the what-if simulator can only respond to the green-cover lever.",
                "UHI classes are quartile bands of the anomaly versus the median grid point, i.e. relative rankings, not absolute urban-minus-rural intensity.",
                "Heat-risk level = NWS heat index (air temperature + humidity) plus the UHI anomaly, mapped to five bands (26.7 / 32.2 / 39.4 / 51.1 \u00B0C).",
                "Forecast heat-risk uses a climatology + decaying-persistence forecast for temperature and humidity, and the forecast class for the UHI term.",
                "Data timestamps are UTC; this report converts to IST (UTC+5:30)."};
        for (String n : notes) y = p.paragraph(48, y, 500, 8, false, 0x374151, "\u00B7 " + n, 10.5) + 3;
        footer(p, 4);

        doc.save(out);
        return out;
    }

    // ----------------------------------------------------------- PDF drawing helpers

    private static String pct(double v) { return Double.isNaN(v) ? "-" : String.format(Locale.ROOT, "%.1f%%", v * 100); }

    private static void header(PdfDoc.Page p, String title, String sub) {
        p.rect(0, 0, PdfDoc.W, 66, Palette.NAVY);
        p.rect(0, 66, PdfDoc.W, 3, Palette.TEAL);
        p.text(40, 32, 17, true, 0xFFFFFF, title);
        p.text(40, 51, 8.5, false, 0xCBD5E1, sub);
    }

    private static void footer(PdfDoc.Page p, int n) {
        p.line(40, 812, 555, 812, 0xE5E7EB, 0.6);
        p.text(40, 826, 7.5, false, Palette.GREY, "Chennai UHI XAI dashboard   |   statistical model output, not an official warning");
        p.textRight(555, 826, 7.5, false, Palette.GREY, "Page " + n);
    }

    private static void tile(PdfDoc.Page p, double x, double y, double w, double h, String label, String value) {
        p.rect(x, y, w, h, Palette.LIGHT);
        p.rect(x, y, 3, h, Palette.TEAL);
        p.text(x + 12, y + 17, 8, false, Palette.GREY, label);
        p.text(x + 12, y + 37, 15, true, Palette.NAVY, value);
    }

    private static void tableHeader(PdfDoc.Page p, double x, double y, String[] h, double[] w) {
        double tw = 0;
        for (double d : w) tw += d;
        p.rect(x, y, tw, 15, Palette.NAVY);
        double cx = x;
        for (int i = 0; i < h.length; i++) { p.text(cx + 4, y + 10.5, 7.5, true, 0xFFFFFF, h[i]); cx += w[i]; }
    }

    private static void tableRow(PdfDoc.Page p, double x, double y, String[] r, double[] w, boolean shade) {
        double tw = 0;
        for (double d : w) tw += d;
        if (shade) p.rect(x, y, tw, 15, 0xF9FAFB);
        double cx = x;
        for (int i = 0; i < r.length; i++) {
            String s = r[i];
            while (PdfDoc.width(s, 7.5, false) > w[i] - 6 && s.length() > 3) s = s.substring(0, s.length() - 2);
            p.text(cx + 4, y + 10.5, 7.5, false, Palette.INK, s);
            cx += w[i];
        }
    }

    private static void bars(PdfDoc.Page p, double x, double y, double w, double h, String title, String[] labels, double[] vals, int[] colors, boolean pct) {
        p.text(x, y + 10, 10, true, Palette.NAVY, title);
        double top = y + 26, bottom = y + h - 18, ph = bottom - top;
        double max = 0;
        for (double v : vals) max = Math.max(max, v);
        if (max <= 0) max = 1;
        max *= 1.15;
        p.line(x, bottom, x + w, bottom, 0x9CA3AF, 0.7);
        double slot = w / vals.length, bw = slot * 0.62;
        for (int i = 0; i < vals.length; i++) {
            double bh = vals[i] / max * ph;
            double bx = x + i * slot + (slot - bw) / 2;
            p.rect(bx, bottom - bh, bw, bh, colors[i % colors.length]);
            String s = pct ? String.format(Locale.ROOT, "%.0f%%", vals[i] * 100) : String.format(Locale.ROOT, "%.1f", vals[i]);
            p.textCenter(bx + bw / 2, bottom - bh - 3, 7, false, Palette.INK, s);
            p.textCenter(bx + bw / 2, bottom + 11, 7, false, Palette.GREY, labels[i]);
        }
    }

    private static void lines(PdfDoc.Page p, double x, double y, double w, double h, String title, double[][] s, String[] names, int[] colors) {
        p.text(x, y + 10, 10, true, Palette.NAVY, title);
        double left = x + 34, right = x + w - 6, top = y + 24, bottom = y + h - 38;
        double mn = Double.MAX_VALUE, mx = -Double.MAX_VALUE;
        for (double[] a : s) for (double v : a) { mn = Math.min(mn, v); mx = Math.max(mx, v); }
        if (mx - mn < 1e-6) { mx = mn + 1; }
        double pad = (mx - mn) * 0.08;
        mn -= pad; mx += pad;
        for (int g = 0; g <= 4; g++) {
            double gv = mn + (mx - mn) * g / 4, gy = bottom - (bottom - top) * g / 4;
            p.line(left, gy, right, gy, 0xE5E7EB, 0.5);
            p.textRight(left - 4, gy + 2.5, 7, false, Palette.GREY, String.format(Locale.ROOT, "%.1f", gv));
        }
        if (mn < 0 && mx > 0) { double zy = bottom - (bottom - top) * (0 - mn) / (mx - mn); p.line(left, zy, right, zy, 0x6B7280, 0.8); }
        for (int hr = 0; hr < 24; hr += 3) {
            double hx = left + (right - left) * hr / 23.0;
            p.textCenter(hx, bottom + 11, 7, false, Palette.GREY, Cfg.hourLabel(Cfg.hourAt(hr)));
        }
        for (int k = 0; k < s.length; k++) {
            for (int hr = 0; hr < 23; hr++) {
                double x1 = left + (right - left) * hr / 23.0, x2 = left + (right - left) * (hr + 1) / 23.0;
                double y1 = bottom - (bottom - top) * (s[k][hr] - mn) / (mx - mn), y2 = bottom - (bottom - top) * (s[k][hr + 1] - mn) / (mx - mn);
                p.line(x1, y1, x2, y2, colors[k], 1.3);
            }
        }
        double lx = left;
        for (int k = 0; k < s.length; k++) {
            p.rect(lx, bottom + 24, 8, 8, colors[k]);
            p.text(lx + 11, bottom + 31, 7.5, false, Palette.INK, names[k]);
            lx += 30 + PdfDoc.width(names[k], 7.5, false);
        }
    }

    private static void heat(PdfDoc.Page p, double x, double y, double w, double h, String title, ViewStats v) {
        p.text(x, y + 10, 10, true, Palette.NAVY, title);
        double left = x + 30, top = y + 20, cw = (w - 36) / 24.0, ch = (h - 48) / 12.0;
        double mx = 0;
        for (int m = 0; m < 12; m++) for (int hr = 0; hr < 24; hr++) if (v.hmN[m][Cfg.hourAt(hr)] > 0) mx = Math.max(mx, Math.abs(v.hm[m][Cfg.hourAt(hr)]));
        for (int m = 0; m < 12; m++) {
            p.text(x, top + m * ch + ch * 0.7, 7, false, Palette.GREY, MON[m]);
            for (int hr = 0; hr < 24; hr++) {
                int uh = Cfg.hourAt(hr);
                int col = v.hmN[m][uh] == 0 ? 0xF3F4F6 : Palette.diverging(v.hm[m][uh], mx);
                p.rect(left + hr * cw, top + m * ch, cw - 0.6, ch - 0.6, col);
            }
        }
        for (int hr = 0; hr < 24; hr += 3) p.textCenter(left + hr * cw + cw / 2, top + 12 * ch + 10, 7, false, Palette.GREY, Cfg.hourLabel(Cfg.hourAt(hr)));
        p.text(left, top + 12 * ch + 24, 7.5, false, Palette.GREY, String.format(Locale.ROOT, "Blue = cooler than the median point, red = warmer (colour range +/-%.2f \u00B0C)", mx));
    }

    private static void strip(PdfDoc.Page p, double x, double y, double w, ForecastModel.Forecast fc, DataStore ds) {
        double label = 38, cw = (w - label) / ForecastModel.MAX_H, rh = 13;
        for (int h = 0; h < ForecastModel.MAX_H; h += 3)
            p.textCenter(x + label + h * cw + cw / 2, y + 8, 6.5, false, Palette.GREY, Cfg.local(ds.time(fc.origin + h + 1)).format(DateTimeFormatter.ofPattern("HH:mm")));
        double yy = y + 12;
        for (int l = 0; l < fc.nLoc; l++) {
            p.text(x, yy + 9, 7.5, true, Palette.INK, ds.locShort[l]);
            for (int h = 0; h < ForecastModel.MAX_H; h++) {
                p.rect(x + label + h * cw, yy, cw - 0.5, rh / 2 - 0.5, Palette.CLASS[fc.cls[l][h]]);
                p.rect(x + label + h * cw, yy + rh / 2, cw - 0.5, rh / 2 - 0.5, Palette.RISK[fc.level[l][h]]);
            }
            yy += 16;
        }
        double ly = yy + 8;
        double lx = x;
        for (int c = 0; c < Cfg.NC; c++) { p.rect(lx, ly - 7, 8, 8, Palette.CLASS[c]); p.text(lx + 11, ly, 7, false, Palette.INK, Cfg.CLASS_NAMES[c]); lx += 52; }
        lx += 14;
        for (int k = 0; k < 5; k++) { p.rect(lx, ly - 7, 8, 8, Palette.RISK[k]); p.text(lx + 11, ly, 7, false, Palette.INK, HeatRisk.LEVELS[k]); lx += 24 + PdfDoc.width(HeatRisk.LEVELS[k], 7, false); }
        p.text(x, ly + 12, 6.5, false, Palette.GREY, "Top half of each row = forecast UHI class, bottom half = heat-risk level.");
    }
}
