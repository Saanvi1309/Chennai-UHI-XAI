package org.example.analytics;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Locale;

/**
 * Extended model evaluation: per-class precision / recall / F1, macro and weighted F1, one-vs-rest ROC-AUC, log-loss,
 * Brier score, expected calibration error (raw and temperature-scaled), numeric UHI-anomaly error (MAE / RMSE / R2),
 * inference time and breakdowns by location. All numbers are computed from the predictions of the loaded models.
 */
public final class ModelEval {
    private ModelEval() {}

    public static final class Report {
        public String model, split;
        public int n;
        public double accuracy, macroPrecision, macroRecall, macroF1, weightedF1, adjacentAccuracy, macroAuc;
        public double logLoss, logLossCalibrated, eceRaw, eceCalibrated, brier;
        public double anomalyMae, anomalyRmse, anomalyR2, anomalyBias;
        public double[] precision = new double[Cfg.NC], recall = new double[Cfg.NC], f1 = new double[Cfg.NC], auc = new double[Cfg.NC];
        public int[] support = new int[Cfg.NC];
        public int[][] cm = new int[Cfg.NC][Cfg.NC];
    }

    public static String splitName(int sp) { return sp == 0 ? "train" : sp == 1 ? "validation" : "test"; }

    /** rows == null means every row of the split. */
    public static Report report(DataStore ds, ModelSuite ms, int m, int split, boolean[] locMask) {
        Report r = new Report();
        r.model = ms.modelNames[m]; r.split = splitName(split);
        int cnt = 0;
        for (int i = 0; i < ds.n; i++) if (ds.split[i] == split && (locMask == null || locMask[ds.loc[i]]) && ms.proba[m][i] != null) cnt++;
        r.n = cnt;
        if (cnt == 0) return r;
        double[][] score = new double[Cfg.NC][cnt];
        boolean[][] pos = new boolean[Cfg.NC][cnt];
        double[] conf = new double[cnt], confCal = new double[cnt];
        boolean[] ok = new boolean[cnt], okCal = new boolean[cnt];
        double ll = 0, llc = 0, br = 0, sAbs = 0, sSq = 0, sBias = 0, meanY = 0;
        double[] ea = new double[cnt], ya = new double[cnt];
        int k = 0;
        for (int i = 0; i < ds.n; i++) {
            if (ds.split[i] != split || (locMask != null && !locMask[ds.loc[i]]) || ms.proba[m][i] == null) continue;
            float[] p = ms.proba[m][i];
            double[] pc = ms.calibratedProba(m, i);
            int y = ds.cls[i], b = argmax(p), bc = argmax(pc);
            r.cm[y][b]++;
            r.support[y]++;
            ll -= Math.log(Math.max(p[y], 1e-9));
            llc -= Math.log(Math.max(pc[y], 1e-9));
            for (int c = 0; c < Cfg.NC; c++) { score[c][k] = p[c]; pos[c][k] = c == y; double d = p[c] - (c == y ? 1 : 0); br += d * d; }
            conf[k] = p[b]; ok[k] = b == y; confCal[k] = pc[bc]; okCal[k] = bc == y;
            double e = 0;
            for (int c = 0; c < Cfg.NC; c++) e += p[c] * ds.classMeanAnomaly[c];
            ea[k] = e; ya[k] = ds.anomaly[i]; meanY += ya[k];
            k++;
        }
        Metrics mt = new Metrics(r.cm);
        r.accuracy = mt.accuracy(); r.adjacentAccuracy = mt.adjacentAccuracy(); r.macroF1 = mt.macroF1();
        double wf = 0, mp = 0, mr = 0, ma = 0;
        for (int c = 0; c < Cfg.NC; c++) {
            r.precision[c] = mt.precision(c); r.recall[c] = mt.recall(c); r.f1[c] = mt.f1(c);
            r.auc[c] = auc(score[c], pos[c]);
            wf += r.f1[c] * r.support[c]; mp += r.precision[c]; mr += r.recall[c]; ma += r.auc[c];
        }
        r.weightedF1 = wf / cnt; r.macroPrecision = mp / Cfg.NC; r.macroRecall = mr / Cfg.NC; r.macroAuc = ma / Cfg.NC;
        r.logLoss = ll / cnt; r.logLossCalibrated = llc / cnt; r.brier = br / cnt;
        r.eceRaw = ece(conf, ok, null); r.eceCalibrated = ece(confCal, okCal, null);
        meanY /= cnt;
        double ssTot = 0;
        for (int i = 0; i < cnt; i++) {
            double d = ea[i] - ya[i];
            sAbs += Math.abs(d); sSq += d * d; sBias += d; ssTot += (ya[i] - meanY) * (ya[i] - meanY);
        }
        r.anomalyMae = sAbs / cnt; r.anomalyRmse = Math.sqrt(sSq / cnt); r.anomalyBias = sBias / cnt;
        r.anomalyR2 = ssTot == 0 ? Double.NaN : 1 - sSq / ssTot;
        return r;
    }

    public static int argmax(float[] p) {
        if (p == null || p.length == 0) {
            throw new IllegalArgumentException(
                    "Probability array cannot be null or empty"
            );
        }

        int best = 0;

        for (int i = 1; i < p.length; i++) {
            if (p[i] > p[best]) {
                best = i;
            }
        }

        return best;
    }

    public static int argmax(double[] p) {
        if (p == null || p.length == 0) {
            throw new IllegalArgumentException(
                    "Probability array cannot be null or empty"
            );
        }

        int best = 0;

        for (int i = 1; i < p.length; i++) {
            if (p[i] > p[best]) {
                best = i;
            }
        }

        return best;
    }

    /** Rank-based (Mann-Whitney) ROC-AUC with average ranks for ties. */
    public static double auc(double[] score, boolean[] pos) {
        int n = score.length;
        Integer[] idx = new Integer[n];
        for (int i = 0; i < n; i++) idx[i] = i;
        Arrays.sort(idx, Comparator.comparingDouble(i -> score[i]));
        double sumRanksPos = 0; long nPos = 0;
        int i = 0;
        while (i < n) {
            int j = i;
            while (j + 1 < n && score[idx[j + 1]] == score[idx[i]]) j++;
            double avg = (i + j) / 2.0 + 1;
            for (int q = i; q <= j; q++) if (pos[idx[q]]) { sumRanksPos += avg; nPos++; }
            i = j + 1;
        }
        long nNeg = n - nPos;
        if (nPos == 0 || nNeg == 0) return Double.NaN;
        return (sumRanksPos - nPos * (nPos + 1) / 2.0) / ((double) nPos * nNeg);
    }

    /** Expected calibration error with 10 equal-width confidence bins; optionally fills bins[b] = {count, meanConf, accuracy}. */
    public static double ece(double[] conf, boolean[] ok, double[][] bins) {
        int B = 10;
        double[] cnt = new double[B], sc = new double[B], sa = new double[B];
        for (int i = 0; i < conf.length; i++) {
            int b = Math.min(B - 1, (int) (conf[i] * B));
            cnt[b]++; sc[b] += conf[i]; sa[b] += ok[i] ? 1 : 0;
        }
        double e = 0;
        for (int b = 0; b < B; b++) {
            if (cnt[b] == 0) continue;
            e += cnt[b] / conf.length * Math.abs(sa[b] / cnt[b] - sc[b] / cnt[b]);
            if (bins != null) { bins[b][0] = cnt[b]; bins[b][1] = sc[b] / cnt[b]; bins[b][2] = sa[b] / cnt[b]; }
        }
        return e;
    }

    /** Average prediction time in microseconds per row (after warm-up), scaled features precomputed. */
    public static double inferenceMicros(UhiClassifier m, double[][] xs) {
        int warm = Math.min(2000, xs.length);
        double sink = 0;
        for (int i = 0; i < warm; i++) sink += m.predictProba(xs[i])[0];
        long t0 = System.nanoTime();
        for (double[] x : xs) sink += m.predictProba(x)[0];
        long t = System.nanoTime() - t0;
        if (sink == 12345.678) System.out.print("");
        return t / 1e3 / xs.length;
    }

    // ------------------------------------------------------------------ files

    public static void writeAll(DataStore ds, ModelSuite ms, Path dir, double[] trainSeconds) throws IOException {
        Files.createDirectories(dir);
        int M = ms.models.length;
        double[][] xs = new double[Math.min(20000, ds.n)][];
        int q = 0;
        for (int i = 0; i < ds.n && q < xs.length; i += 5) if (ds.split[i] == 2) xs[q++] = ms.scaler.scale(ds.x[i]);
        xs = Arrays.copyOf(xs, q);
        double[] infer = new double[M];
        for (int m = 0; m < M; m++) infer[m] = inferenceMicros(ms.models[m], xs);

        StringBuilder sum = new StringBuilder("model,split,rows,accuracy,macro_precision,macro_recall,macro_f1,weighted_f1,adjacent_accuracy,macro_roc_auc_ovr,log_loss,log_loss_temperature_scaled,ece_raw,ece_temperature_scaled,brier,anomaly_mae_c,anomaly_rmse_c,anomaly_r2,anomaly_bias_c,train_seconds,inference_us_per_row\n");
        StringBuilder cls = new StringBuilder("model,split,class,support,precision,recall,f1,roc_auc_ovr\n");
        StringBuilder rel = new StringBuilder("model,variant,bin_low,bin_high,rows,mean_confidence,accuracy\n");
        StringBuilder loc = new StringBuilder("model,split,location,rows,accuracy,macro_f1,adjacent_accuracy,anomaly_mae_c,anomaly_bias_c\n");
        StringBuilder tmp = new StringBuilder("model,temperature,fitted_on\n");
        for (int m = 0; m < M; m++) {
            tmp.append(String.format(Locale.ROOT, "%s,%.4f,validation split only%n", ms.modelNames[m], ms.temps[m]));
            for (int sp = 1; sp <= 2; sp++) {
                Report r = report(ds, ms, m, sp, null);
                sum.append(String.format(Locale.ROOT, "%s,%s,%d,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%s,%.2f%n",
                        r.model, r.split, r.n, r.accuracy, r.macroPrecision, r.macroRecall, r.macroF1, r.weightedF1, r.adjacentAccuracy, r.macroAuc,
                        r.logLoss, r.logLossCalibrated, r.eceRaw, r.eceCalibrated, r.brier, r.anomalyMae, r.anomalyRmse, r.anomalyR2, r.anomalyBias,
                        Double.isNaN(trainSeconds[m]) ? "n/a" : String.format(Locale.ROOT, "%.1f", trainSeconds[m]), infer[m]));
                for (int c = 0; c < Cfg.NC; c++)
                    cls.append(String.format(Locale.ROOT, "%s,%s,%s,%d,%.4f,%.4f,%.4f,%.4f%n", r.model, r.split, Cfg.CLASS_NAMES[c], r.support[c], r.precision[c], r.recall[c], r.f1[c], r.auc[c]));
                for (int l = 0; l < ds.nLoc; l++) {
                    boolean[] mask = new boolean[ds.nLoc];
                    mask[l] = true;
                    Report rl = report(ds, ms, m, sp, mask);
                    loc.append(String.format(Locale.ROOT, "%s,%s,%s,%d,%.4f,%.4f,%.4f,%.4f,%.4f%n", rl.model, rl.split, ds.locShort[l], rl.n, rl.accuracy, rl.macroF1, rl.adjacentAccuracy, rl.anomalyMae, rl.anomalyBias));
                }
            }
            // reliability diagrams on the test split
            for (int v = 0; v < 2; v++) {
                double[] conf = new double[ds.n]; boolean[] ok = new boolean[ds.n];
                int k = 0;
                for (int i = 0; i < ds.n; i++) {
                    if (ds.split[i] != 2 || ms.proba[m][i] == null) continue;
                    double[] p = v == 0 ? toDouble(ms.proba[m][i]) : ms.calibratedProba(m, i);
                    int b = argmax(p);
                    conf[k] = p[b]; ok[k] = b == ds.cls[i]; k++;
                }
                double[][] bins = new double[10][3];
                ece(Arrays.copyOf(conf, k), Arrays.copyOf(ok, k), bins);
                for (int b = 0; b < 10; b++)
                    rel.append(String.format(Locale.ROOT, "%s,%s,%.1f,%.1f,%d,%.4f,%.4f%n", ms.modelNames[m], v == 0 ? "raw" : "temperature_scaled", b / 10.0, (b + 1) / 10.0, (int) bins[b][0], bins[b][1], bins[b][2]));
            }
        }
        Files.writeString(dir.resolve("eval_summary.csv"), sum.toString());
        Files.writeString(dir.resolve("eval_per_class.csv"), cls.toString());
        Files.writeString(dir.resolve("calibration_reliability.csv"), rel.toString());
        Files.writeString(dir.resolve("calibration_temperatures.csv"), tmp.toString());
        Files.writeString(dir.resolve("eval_by_location.csv"), loc.toString());

        // actual vs predicted UHI category (primary DNN, test period) and generalisation across splits
        int pm = ms.indexOf(ms.primary.name());
        StringBuilder avp = new StringBuilder("split,class,actual_rows,predicted_rows,actual_share,predicted_share\n");
        StringBuilder gen = new StringBuilder("model,split,rows,accuracy,macro_f1\n");
        for (int m = 0; m < M; m++) {
            if (!(ms.models[m] instanceof DnnModel || ms.models[m] instanceof TunedDnn)) continue;
            for (int sp = 0; sp <= 2; sp++) {
                int[][] cm = new int[Cfg.NC][Cfg.NC];
                for (int i = 0; i < ds.n; i++) {
                    if (ds.split[i] != sp) continue;
                    if (sp == 0 && i % 5 != 0) continue;           // every 5th training row is enough for the train score
                    int b = sp == 0 ? ms.models[m].predict(ms.scaler.scale(ds.x[i])) : argmax(ms.proba[m][i]);
                    cm[ds.cls[i]][b]++;
                }
                Metrics mt = new Metrics(cm);
                gen.append(String.format(Locale.ROOT, "%s,%s,%d,%.4f,%.4f%n", ms.modelNames[m], splitName(sp), mt.n, mt.accuracy(), mt.macroF1()));
                if (m == pm && sp == 2)
                    for (int c = 0; c < Cfg.NC; c++) {
                        long act = 0, pre = 0;
                        for (int j = 0; j < Cfg.NC; j++) { act += cm[c][j]; pre += cm[j][c]; }
                        avp.append(String.format(Locale.ROOT, "test,%s,%d,%d,%.4f,%.4f%n", Cfg.CLASS_NAMES[c], act, pre, (double) act / mt.n, (double) pre / mt.n));
                    }
            }
        }
        Files.writeString(dir.resolve("dnn_actual_vs_predicted.csv"), avp.toString());
        Files.writeString(dir.resolve("dnn_generalisation.csv"), gen.toString());
    }

    static double[] toDouble(float[] f) { double[] d = new double[f.length]; for (int i = 0; i < d.length; i++) d[i] = f[i]; return d; }
}
