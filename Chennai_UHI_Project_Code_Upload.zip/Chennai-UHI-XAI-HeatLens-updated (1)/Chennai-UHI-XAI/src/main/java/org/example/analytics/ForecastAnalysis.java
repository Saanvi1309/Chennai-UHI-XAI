package org.example.analytics;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

/**
 * Held-out (test period) evaluation of the 1-24 h forecaster. Every number is computed from the trained forecaster's
 * predictions against the observed values; baselines (persistence, same-hour-yesterday, climatology) are shown for context.
 */
public final class ForecastAnalysis {
    private ForecastAnalysis() {}

    public static final int[] HORIZONS = {1, 3, 6, 12, 24};

    public static final class H {
        public int h, n;
        public double acc, macroF1, adjAcc, meanConf, ece;
        public double tMae, tRmse, tR2, tMaePers, tRmsePers, tMaeClim, tRmseClim;
        public double aMae, aRmse, aR2;
        public double yesterdayAcc;
        public int[][] cm = new int[Cfg.NC][Cfg.NC];
        public int[] locN; public int[] locOk; public double[] locTAbs, locTSq;
        public int[] hourN = new int[24], hourOk = new int[24]; public double[] hourTAbs = new double[24];
        public double[][] bins = new double[10][3];
    }

    public static H[] run(DataStore ds, ForecastModel fm, int split) {
        H[] out = new H[HORIZONS.length];
        for (int a = 0; a < HORIZONS.length; a++) {
            int h = HORIZONS[a];
            H r = new H();
            r.h = h;
            r.locN = new int[ds.nLoc]; r.locOk = new int[ds.nLoc]; r.locTAbs = new double[ds.nLoc]; r.locTSq = new double[ds.nLoc];
            double sT = 0, sT2 = 0, sTp = 0, sTp2 = 0, sTc = 0, sTc2 = 0, sA = 0, sA2 = 0, sumYT = 0, sumYA = 0, confSum = 0;
            int yest = 0;
            double[] confs = new double[ds.n]; boolean[] oks = new boolean[ds.n];
            double[] ytAll = new double[ds.n], yaAll = new double[ds.n];
            int k = 0;
            for (int t = 0; t + h < ds.nHours; t++) for (int l = 0; l < ds.nLoc; l++) {
                int rt = ds.rowAt[t + h][l];
                if (rt < 0 || ds.split[rt] != split) continue;
                int r0 = ds.rowAt[t][l];
                if (r0 < 0) continue;
                double[] p = fm.predictProba(ds, t, l, h);
                int b = ModelEval.argmax(p), y = ds.cls[rt];
                r.cm[y][b]++;
                double ea = 0;
                for (int c = 0; c < Cfg.NC; c++) ea += p[c] * fm.classMeanAnomaly[c];
                double T = ds.x[rt][Cfg.F_AIR_T], pT = fm.predictTemp(ds, t, l, h);
                double pers = ds.x[r0][Cfg.F_AIR_T], clim = fm.climT[l][ds.month[rt]][ds.hour[rt]];
                sT += Math.abs(pT - T); sT2 += (pT - T) * (pT - T);
                sTp += Math.abs(pers - T); sTp2 += (pers - T) * (pers - T);
                sTc += Math.abs(clim - T); sTc2 += (clim - T) * (clim - T);
                double dA = ea - ds.anomaly[rt];
                sA += Math.abs(dA); sA2 += dA * dA;
                ytAll[k] = T; yaAll[k] = ds.anomaly[rt];
                sumYT += T; sumYA += ds.anomaly[rt];
                confSum += p[b]; confs[k] = p[b]; oks[k] = b == y; k++;
                r.locN[l]++; if (b == y) r.locOk[l]++; r.locTAbs[l] += Math.abs(pT - T); r.locTSq[l] += (pT - T) * (pT - T);
                int hi = ds.hour[rt];
                r.hourN[hi]++; if (b == y) r.hourOk[hi]++; r.hourTAbs[hi] += Math.abs(pT - T);
                if (ds.cls[ds.rowAtClamped(t + h - 24, l)] == y) yest++;
            }
            r.n = k;
            if (k == 0) { out[a] = r; continue; }
            Metrics mt = new Metrics(r.cm);
            r.acc = mt.accuracy(); r.macroF1 = mt.macroF1(); r.adjAcc = mt.adjacentAccuracy(); r.meanConf = confSum / k;
            r.yesterdayAcc = (double) yest / k;
            r.tMae = sT / k; r.tRmse = Math.sqrt(sT2 / k); r.tMaePers = sTp / k; r.tRmsePers = Math.sqrt(sTp2 / k);
            r.tMaeClim = sTc / k; r.tRmseClim = Math.sqrt(sTc2 / k);
            r.aMae = sA / k; r.aRmse = Math.sqrt(sA2 / k);
            double mT = sumYT / k, mA = sumYA / k, totT = 0, totA = 0;
            for (int i = 0; i < k; i++) { totT += (ytAll[i] - mT) * (ytAll[i] - mT); totA += (yaAll[i] - mA) * (yaAll[i] - mA); }
            r.tR2 = totT == 0 ? Double.NaN : 1 - sT2 / totT;
            r.aR2 = totA == 0 ? Double.NaN : 1 - sA2 / totA;
            r.ece = ModelEval.ece(java.util.Arrays.copyOf(confs, k), java.util.Arrays.copyOf(oks, k), r.bins);
            out[a] = r;
        }
        return out;
    }

    public static void write(DataStore ds, ForecastModel fm, Path dir, H[] res) throws IOException {
        Files.createDirectories(dir);
        StringBuilder t = new StringBuilder("horizon_h,test_rows,accuracy,macro_f1,adjacent_accuracy,air_temp_mae_c,air_temp_rmse_c,air_temp_r2,anomaly_mae_c,anomaly_rmse_c,anomaly_r2,"
                + "mean_confidence,ece,persistence_air_temp_mae_c,persistence_air_temp_rmse_c,climatology_air_temp_mae_c,climatology_air_temp_rmse_c,same_hour_yesterday_accuracy\n");
        StringBuilder loc = new StringBuilder("horizon_h,location,rows,accuracy,air_temp_mae_c,air_temp_rmse_c\n");
        StringBuilder hr = new StringBuilder("horizon_h,target_hour_ist,rows,accuracy,air_temp_mae_c\n");
        StringBuilder cf = new StringBuilder("horizon_h,confidence_bin_low,confidence_bin_high,rows,mean_confidence,accuracy\n");
        StringBuilder cm = new StringBuilder("horizon_h,actual,pred_low,pred_moderate,pred_high,pred_extreme\n");
        for (H r : res) {
            t.append(String.format(Locale.ROOT, "%d,%d,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f%n", r.h, r.n, r.acc, r.macroF1, r.adjAcc,
                    r.tMae, r.tRmse, r.tR2, r.aMae, r.aRmse, r.aR2, r.meanConf, r.ece, r.tMaePers, r.tRmsePers, r.tMaeClim, r.tRmseClim, r.yesterdayAcc));
            for (int l = 0; l < ds.nLoc; l++) if (r.locN[l] > 0)
                loc.append(String.format(Locale.ROOT, "%d,%s,%d,%.4f,%.4f,%.4f%n", r.h, ds.locShort[l], r.locN[l], (double) r.locOk[l] / r.locN[l], r.locTAbs[l] / r.locN[l], Math.sqrt(r.locTSq[l] / r.locN[l])));
            for (int i = 0; i < 24; i++) { int u = Cfg.hourAt(i); if (r.hourN[u] > 0)
                hr.append(String.format(Locale.ROOT, "%d,%s,%d,%.4f,%.4f%n", r.h, Cfg.hourLabel(u), r.hourN[u], (double) r.hourOk[u] / r.hourN[u], r.hourTAbs[u] / r.hourN[u])); }
            for (int b = 0; b < 10; b++) cf.append(String.format(Locale.ROOT, "%d,%.1f,%.1f,%d,%.4f,%.4f%n", r.h, b / 10.0, (b + 1) / 10.0, (int) r.bins[b][0], r.bins[b][1], r.bins[b][2]));
            for (int a = 0; a < Cfg.NC; a++) cm.append(String.format(Locale.ROOT, "%d,%s,%d,%d,%d,%d%n", r.h, Cfg.CLASS_NAMES[a], r.cm[a][0], r.cm[a][1], r.cm[a][2], r.cm[a][3]));
        }
        Files.writeString(dir.resolve("forecast_horizon_table.csv"), t.toString());
        Files.writeString(dir.resolve("forecast_by_location.csv"), loc.toString());
        Files.writeString(dir.resolve("forecast_error_by_hour.csv"), hr.toString());
        Files.writeString(dir.resolve("forecast_confidence.csv"), cf.toString());
        Files.writeString(dir.resolve("forecast_confusion_by_horizon.csv"), cm.toString());

        // actual-vs-predicted series for one grid point over the last 7 test days (origin t, target t+h)
        int l = Math.min(3, ds.nLoc - 1);
        StringBuilder av = new StringBuilder("horizon_h,location,target_time_utc,target_time_ist,actual_air_temp_c,predicted_air_temp_c,actual_class,predicted_class,confidence,actual_anomaly_c,expected_anomaly_c\n");
        for (int h : new int[]{6, 24}) {
            for (int tt = ds.nHours - 1 - 24 * 7 - h; tt + h < ds.nHours; tt++) {
                int rt = ds.rowAt[tt + h][l];
                if (rt < 0 || ds.rowAt[tt][l] < 0) continue;
                double[] p = fm.predictProba(ds, tt, l, h);
                int b = ModelEval.argmax(p);
                double ea = 0;
                for (int c = 0; c < Cfg.NC; c++) ea += p[c] * fm.classMeanAnomaly[c];
                av.append(String.format(Locale.ROOT, "%d,%s,%s,%s,%.3f,%.3f,%s,%s,%.4f,%.3f,%.3f%n", h, ds.locShort[l], ds.time(tt + h), Cfg.local(ds.time(tt + h)),
                        ds.x[rt][Cfg.F_AIR_T], fm.predictTemp(ds, tt, l, h), Cfg.CLASS_NAMES[ds.cls[rt]], Cfg.CLASS_NAMES[b], p[b], ds.anomaly[rt], ea));
            }
        }
        Files.writeString(dir.resolve("forecast_actual_vs_predicted_sample.csv"), av.toString());
    }
}
