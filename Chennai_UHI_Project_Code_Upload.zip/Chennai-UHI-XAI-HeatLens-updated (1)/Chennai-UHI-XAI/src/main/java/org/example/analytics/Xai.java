package org.example.analytics;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Monte-Carlo Shapley attributions (permutation sampling, interventional baseline) computed on the ACTUAL classifier that is
 * passed in (the trained DNN weights - never a surrogate model). The value function is the model's probability of the explained class.
 *
 * For every sampled permutation a random background row z (from the training split) is walked towards the explained row x by
 * switching one feature at a time; the change in probability when feature f is switched is credited to f. Averaged over
 * permutations this converges to the Shapley value, and the attributions add up exactly to p(x) - E[p(z)] (efficiency).
 */
public final class Xai {
    private Xai() {}

    /** Feature groups; the group value of a coalition is the sum of its members' Shapley values (additivity). */
    public static final String[] GROUPS = {"Weather", "Vegetation / spectral", "Location & land form (static)", "Data-matching metadata"};
    public static int groupOf(int f) {
        return switch (Cfg.FEATURES[f]) {
            case "air_temperature", "dew_point_temperature", "cloud_cover", "u10", "v10", "wind_speed", "wind_direction",
                 "relative_humidity", "pressure", "rainfall" -> 0;
            case "red_band", "nir_band", "ndvi", "ndbi", "ndwi" -> 1;
            case "spatial_match_distance_km", "dynamic_nearest_distance_km", "landsat_temporal_gap_days" -> 3;
            default -> 2;
        };
    }

    public record Explanation(int row, int explainedClass, int predictedClass, double prediction, double baseline,
                              double[] phi, double[] scaled, double[] raw, double[] proba) {
        /** Feature indices sorted by |phi| descending. */
        public Integer[] ranked() {
            Integer[] idx = new Integer[phi.length];
            for (int i = 0; i < idx.length; i++) idx[i] = i;
            Arrays.sort(idx, (a, b) -> Double.compare(Math.abs(phi[b]), Math.abs(phi[a])));
            return idx;
        }
        public double[] groupPhi() {
            double[] g = new double[GROUPS.length];
            for (int f = 0; f < phi.length; f++) g[groupOf(f)] += phi[f];
            return g;
        }
    }

    /** Background sample: rows from the training split (2024), evenly spaced, already scaled. */
    public static double[][] background(DataStore ds, Scaler sc, int n) {
        List<Integer> tr = new ArrayList<>();
        for (int i = 0; i < ds.n; i++) if (ds.split[i] == 0) tr.add(i);
        double[][] bg = new double[n][];
        for (int k = 0; k < n; k++) bg[k] = sc.scale(ds.x[tr.get((int) ((long) k * tr.size() / n))]);
        return bg;
    }

    public static Explanation explain(UhiClassifier model, DataStore ds, Scaler sc, int row, int targetClass,
                                      double[][] bg, int permutations, long seed) {
        double[] x = sc.scale(ds.x[row]);
        double[] px = model.predictProba(x);
        int pred = 0;
        for (int c = 1; c < px.length; c++) if (px[c] > px[pred]) pred = c;
        int target = targetClass < 0 ? pred : targetClass;
        int nf = x.length;
        double[] phi = new double[nf];
        double base = 0;
        Random rnd = new Random(seed ^ (row * 0x9E3779B97F4A7C15L));
        int[] perm = new int[nf];
        for (int p = 0; p < permutations; p++) {
            for (int i = 0; i < nf; i++) perm[i] = i;
            for (int i = nf - 1; i > 0; i--) { int j = rnd.nextInt(i + 1); int t = perm[i]; perm[i] = perm[j]; perm[j] = t; }
            double[] z = bg[rnd.nextInt(bg.length)].clone();
            double prev = model.predictProba(z)[target];
            base += prev;
            for (int k = 0; k < nf; k++) {
                int f = perm[k];
                z[f] = x[f];
                double cur = model.predictProba(z)[target];
                phi[f] += cur - prev;
                prev = cur;
            }
        }
        for (int f = 0; f < nf; f++) phi[f] /= permutations;
        base /= permutations;
        return new Explanation(row, target, pred, px[target], base, phi, x, ds.x[row].clone(), px);
    }

    // ------------------------------------------------------------------ global analysis

    public static final class Global {
        public int[] rows;
        public Explanation[] ex;                  // explanations of each sampled row for its predicted class
        public double[] meanAbs = new double[Cfg.NF];
        public double[][] meanAbsByClass = new double[Cfg.NC][Cfg.NF];   // |phi| for the probability of each class
        public double[] groupMeanAbs = new double[GROUPS.length];
        public double maxEfficiencyError;
        public String modelName;
    }

    /** Evenly spaced sample of test rows (test split is used only for explanation, never for model selection). */
    public static int[] sampleTestRows(DataStore ds, int n) {
        List<Integer> te = new ArrayList<>();
        for (int i = 0; i < ds.n; i++) if (ds.split[i] == 2) te.add(i);
        int[] out = new int[Math.min(n, te.size())];
        for (int k = 0; k < out.length; k++) out[k] = te.get((int) ((long) k * te.size() / out.length));
        return out;
    }

    public static Global global(UhiClassifier model, DataStore ds, Scaler sc, int nRows, int permutations, long seed) {
        Global g = new Global();
        g.modelName = model.name();
        g.rows = sampleTestRows(ds, nRows);
        double[][] bg = background(ds, sc, 200);
        g.ex = new Explanation[g.rows.length];
        for (int i = 0; i < g.rows.length; i++) {
            Explanation e = explain(model, ds, sc, g.rows[i], -1, bg, permutations, seed);
            g.ex[i] = e;
            double sum = 0;
            for (double v : e.phi()) sum += v;
            g.maxEfficiencyError = Math.max(g.maxEfficiencyError, Math.abs(sum - (e.prediction() - e.baseline())));
            for (int f = 0; f < Cfg.NF; f++) g.meanAbs[f] += Math.abs(e.phi()[f]);
        }
        for (int f = 0; f < Cfg.NF; f++) g.meanAbs[f] /= g.rows.length;
        // class-specific attributions on a smaller subsample (4 targets per row)
        int sub = Math.min(g.rows.length, 120);
        for (int i = 0; i < sub; i++) {
            int r = g.rows[(int) ((long) i * g.rows.length / sub)];
            for (int c = 0; c < Cfg.NC; c++) {
                Explanation e = explain(model, ds, sc, r, c, bg, permutations, seed + 17);
                for (int f = 0; f < Cfg.NF; f++) g.meanAbsByClass[c][f] += Math.abs(e.phi()[f]);
            }
        }
        for (int c = 0; c < Cfg.NC; c++) for (int f = 0; f < Cfg.NF; f++) g.meanAbsByClass[c][f] /= sub;
        for (int f = 0; f < Cfg.NF; f++) g.groupMeanAbs[groupOf(f)] += g.meanAbs[f];
        return g;
    }

    /**
     * Low vs Extreme comparison with a FIXED explained quantity: the signed Shapley values for P(Extreme), averaged over sampled
     * rows whose actual class is Low (row 0) or Extreme (row 1). Positive = pushes the model towards Extreme.
     * Also returns the mean P(Extreme) of each group as the last element of each row's companion array {nLow, nExt, pLow, pExt}.
     */
    public static double[][] lowVsExtreme(UhiClassifier model, DataStore ds, Scaler sc, Global g, int perms, long seed, double[] meta) {
        double[][] bg = background(ds, sc, 200);
        double[][] out = new double[2][Cfg.NF];
        int[] n = new int[2]; double[] pe = new double[2];
        for (Explanation e : g.ex) {
            int a = ds.cls[e.row()], k = a == 0 ? 0 : a == 3 ? 1 : -1;
            if (k < 0 || n[k] >= 60) continue;
            Explanation x = explain(model, ds, sc, e.row(), 3, bg, perms, seed);
            for (int f = 0; f < Cfg.NF; f++) out[k][f] += x.phi()[f];
            pe[k] += x.prediction(); n[k]++;
        }
        for (int k = 0; k < 2; k++) if (n[k] > 0) { for (int f = 0; f < Cfg.NF; f++) out[k][f] /= n[k]; pe[k] /= n[k]; }
        if (meta != null && meta.length >= 4) { meta[0] = n[0]; meta[1] = n[1]; meta[2] = pe[0]; meta[3] = pe[1]; }
        return out;
    }

    // ------------------------------------------------------------------ faithfulness (deletion) test

    /**
     * Deletion test: replace the k features with the largest |phi| by background values and measure how much the explained
     * class probability falls, versus replacing k random features. A faithful attribution drops the probability much more.
     * Returns rows {k, meanDropTop, meanDropRandom}.
     */
    public static double[][] deletionTest(UhiClassifier model, Global g, DataStore ds, Scaler sc, int[] ks, long seed) {
        double[][] bg = background(ds, sc, 200);
        double[][] out = new double[ks.length][3];
        Random rnd = new Random(seed);
        int used = Math.min(g.ex.length, 150);
        for (int a = 0; a < ks.length; a++) {
            int k = ks[a];
            double dTop = 0, dRnd = 0;
            for (int i = 0; i < used; i++) {
                Explanation e = g.ex[i];
                Integer[] rk = e.ranked();
                double[] z = bg[rnd.nextInt(bg.length)];
                double[] xt = e.scaled().clone(), xr = e.scaled().clone();
                for (int j = 0; j < k; j++) xt[rk[j]] = z[rk[j]];
                List<Integer> idx = new ArrayList<>();
                for (int f = 0; f < Cfg.NF; f++) idx.add(f);
                java.util.Collections.shuffle(idx, rnd);
                for (int j = 0; j < k; j++) xr[idx.get(j)] = z[idx.get(j)];
                dTop += e.prediction() - model.predictProba(xt)[e.explainedClass()];
                dRnd += e.prediction() - model.predictProba(xr)[e.explainedClass()];
            }
            out[a][0] = k; out[a][1] = dTop / used; out[a][2] = dRnd / used;
        }
        return out;
    }

    // ------------------------------------------------------------------ dependence

    /** Dependence data for one feature: raw value and phi for every sampled explanation. */
    public static double[][] dependence(Global g, int feature) {
        double[][] d = new double[g.ex.length][2];
        for (int i = 0; i < g.ex.length; i++) { d[i][0] = g.ex[i].raw()[feature]; d[i][1] = g.ex[i].phi()[feature]; }
        return d;
    }

    // ------------------------------------------------------------------ text + files

    public static String narrative(Explanation e, DataStore ds, int topN) {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(Locale.ROOT, "The model predicts %s with probability %.0f%% (average over background rows: %.0f%%). ",
                Cfg.CLASS_NAMES[e.explainedClass()], e.prediction() * 100, e.baseline() * 100));
        Integer[] rk = e.ranked();
        sb.append("Largest contributions: ");
        for (int i = 0; i < topN && i < rk.length; i++) {
            int f = rk[i];
            sb.append(String.format(Locale.ROOT, "%s = %s (%s%.1f pp)%s", Cfg.prettyFeature(Cfg.FEATURES[f]), fmt(e.raw()[f]),
                    e.phi()[f] >= 0 ? "+" : "", e.phi()[f] * 100, i + 1 < topN ? "; " : "."));
        }
        return sb.toString();
    }

    public static String fmt(double v) {
        double a = Math.abs(v);
        if (a >= 1000) return String.format(Locale.ROOT, "%.0f", v);
        if (a >= 10) return String.format(Locale.ROOT, "%.1f", v);
        return String.format(Locale.ROOT, "%.3f", v);
    }

    public static void writeGlobal(Global g, DataStore ds, Scaler sc, UhiClassifier model, Path dir) throws IOException {
        Files.createDirectories(dir);
        double tot = Arrays.stream(g.meanAbs).sum();
        Integer[] idx = new Integer[Cfg.NF];
        for (int i = 0; i < idx.length; i++) idx[i] = i;
        Arrays.sort(idx, (a, b) -> Double.compare(g.meanAbs[b], g.meanAbs[a]));
        StringBuilder sb = new StringBuilder("rank,feature,group,mean_abs_shapley_prob_points,share_of_total,mean_abs_low,mean_abs_moderate,mean_abs_high,mean_abs_extreme\n");
        int rank = 1;
        for (int f : idx)
            sb.append(String.format(Locale.ROOT, "%d,%s,%s,%.5f,%.5f,%.5f,%.5f,%.5f,%.5f%n", rank++, Cfg.FEATURES[f], GROUPS[groupOf(f)], g.meanAbs[f],
                    tot == 0 ? 0 : g.meanAbs[f] / tot, g.meanAbsByClass[0][f], g.meanAbsByClass[1][f], g.meanAbsByClass[2][f], g.meanAbsByClass[3][f]));
        Files.writeString(dir.resolve("xai_global_importance.csv"), sb.toString());

        StringBuilder gs = new StringBuilder("group,mean_abs_shapley_sum,share_of_total\n");
        for (int k = 0; k < GROUPS.length; k++) gs.append(String.format(Locale.ROOT, "%s,%.5f,%.5f%n", GROUPS[k], g.groupMeanAbs[k], tot == 0 ? 0 : g.groupMeanAbs[k] / tot));
        Files.writeString(dir.resolve("xai_group_importance.csv"), gs.toString());

        StringBuilder ss = new StringBuilder("row,location,timestamp_utc,actual_class,predicted_class,feature,feature_value_raw,feature_value_scaled,shapley_phi\n");
        for (Explanation e : g.ex)
            for (int f = 0; f < Cfg.NF; f++)
                ss.append(String.format(Locale.ROOT, "%d,%s,%s,%s,%s,%s,%.6f,%.6f,%.6f%n", e.row(), ds.locShort[ds.loc[e.row()]], ds.time(ds.hourIdx[e.row()]),
                        Cfg.CLASS_NAMES[ds.cls[e.row()]], Cfg.CLASS_NAMES[e.predictedClass()], Cfg.FEATURES[f], e.raw()[f], e.scaled()[f], e.phi()[f]));
        Files.writeString(dir.resolve("xai_summary_samples.csv"), ss.toString());

        double[][] del = deletionTest(model, g, ds, sc, new int[]{1, 2, 3, 5, 8}, 99);
        StringBuilder fs = new StringBuilder("features_removed_k,mean_prob_drop_top_k_by_shapley,mean_prob_drop_random_k\n");
        for (double[] r : del) fs.append(String.format(Locale.ROOT, "%d,%.5f,%.5f%n", (int) r[0], r[1], r[2]));
        Files.writeString(dir.resolve("xai_faithfulness.csv"), fs.toString());

        double[] meta = new double[4];
        double[][] le = lowVsExtreme(model, ds, sc, g, PERMS, 31, meta);
        StringBuilder cs = new StringBuilder("feature,mean_phi_for_P_extreme__actual_low_rows,mean_phi_for_P_extreme__actual_extreme_rows,difference\n");
        for (int f : idx) cs.append(String.format(Locale.ROOT, "%s,%.5f,%.5f,%.5f%n", Cfg.FEATURES[f], le[0][f], le[1][f], le[1][f] - le[0][f]));
        Files.writeString(dir.resolve("xai_low_vs_extreme.csv"), cs.toString());
        Files.writeString(dir.resolve("xai_low_vs_extreme_summary.csv"), String.format(Locale.ROOT,
                "group,rows_explained,mean_P_extreme%nactual Low,%d,%.4f%nactual Extreme,%d,%.4f%n", (int) meta[0], meta[2], (int) meta[1], meta[3]));

        Files.writeString(dir.resolve("xai_meta.csv"), String.format(Locale.ROOT,
                "model,explained_rows,permutations_per_row,background_rows,max_abs_efficiency_error%n%s,%d,%d,200,%.2e%n",
                g.modelName, g.ex.length, PERMS, g.maxEfficiencyError));
    }

    public static final int PERMS = 40;
}
