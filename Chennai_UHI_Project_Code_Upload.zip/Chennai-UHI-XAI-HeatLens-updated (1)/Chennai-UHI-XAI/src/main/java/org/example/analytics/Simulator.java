package org.example.analytics;

import java.util.Random;

/**
 * Mitigation what-if simulator. Interventions edit the model's input features, the chosen classifier
 * re-predicts the UHI class, and the result is compared with the baseline.
 * NOTE: statistical (correlational) model - indicative, not a physical simulation.
 */
public final class Simulator {
    private Simulator() {}

    /** All values are percentages 0-100. */
    public record Scenario(double green, double building, double road, double water) {
        public boolean isBaseline() { return green == 0 && building == 0 && road == 0 && water == 0; }
        public static Scenario scaled(Scenario s, double f) {
            return new Scenario(s.green * f, s.building * f, s.road * f, s.water * f);
        }
    }

    public static final class Result {
        public double[] shareBefore = new double[Cfg.NC], shareAfter = new double[Cfg.NC];
        public double expBefore, expAfter;                 // expected UHI anomaly (degC)
        public double[] locExpBefore, locExpAfter;         // per location
        public double[] riskBefore = new double[5], riskAfter = new double[5];
        public int n;
        public double deltaC() { return expAfter - expBefore; }
    }

    /** Apply the interventions to a raw feature row (a copy is returned). */
    public static double[] apply(double[] raw, Scenario s) {
        double[] x = raw.clone();
        double g = s.green / 100.0;
        if (g > 0) {
            double ndvi = x[Cfg.F_NDVI];
            double sum = x[Cfg.F_NIR] + x[Cfg.F_RED];
            double nd = ndvi + g * Math.max(0, 0.85 - ndvi);
            x[Cfg.F_NDVI] = nd;
            x[Cfg.F_NIR] = sum * (1 + nd) / 2.0;      // keep NDVI = (NIR-RED)/(NIR+RED) consistent
            x[Cfg.F_RED] = sum * (1 - nd) / 2.0;
            x[Cfg.F_DGREEN] = x[Cfg.F_DGREEN] * (1 - g);
        }
        x[Cfg.F_BLD] = x[Cfg.F_BLD] * (1 - s.building / 100.0);
        x[Cfg.F_ROAD] = x[Cfg.F_ROAD] * (1 - s.road / 100.0);
        x[Cfg.F_DWATER] = x[Cfg.F_DWATER] * (1 - s.water / 100.0);
        return x;
    }

    public static Result run(DataStore ds, Scaler sc, UhiClassifier model, int[] rows, Scenario s, int maxRows) {
        int[] use = rows;
        if (rows.length > maxRows) {
            use = new int[maxRows];
            Random rnd = new Random(5);
            for (int i = 0; i < maxRows; i++) use[i] = rows[rnd.nextInt(rows.length)];
        }
        Result res = new Result();
        res.n = use.length;
        res.locExpBefore = new double[ds.nLoc]; res.locExpAfter = new double[ds.nLoc];
        int[] ln = new int[ds.nLoc];
        for (int r : use) {
            double[] pb = model.predictProba(sc.scale(ds.x[r]));
            double[] pa = s.isBaseline() ? pb : model.predictProba(sc.scale(apply(ds.x[r], s)));
            double eb = 0, ea = 0;
            for (int c = 0; c < Cfg.NC; c++) {
                res.shareBefore[c] += pb[c]; res.shareAfter[c] += pa[c];
                eb += pb[c] * ds.classMeanAnomaly[c]; ea += pa[c] * ds.classMeanAnomaly[c];
            }
            res.expBefore += eb; res.expAfter += ea;
            res.locExpBefore[ds.loc[r]] += eb; res.locExpAfter[ds.loc[r]] += ea; ln[ds.loc[r]]++;
            res.riskBefore[HeatRisk.level(ds.heatIndex[r] + eb)]++;
            res.riskAfter[HeatRisk.level(ds.heatIndex[r] + ea)]++;
        }
        int n = Math.max(1, res.n);
        for (int c = 0; c < Cfg.NC; c++) { res.shareBefore[c] /= n; res.shareAfter[c] /= n; }
        res.expBefore /= n; res.expAfter /= n;
        for (int k = 0; k < 5; k++) { res.riskBefore[k] /= n; res.riskAfter[k] /= n; }
        for (int l = 0; l < ds.nLoc; l++) if (ln[l] > 0) { res.locExpBefore[l] /= ln[l]; res.locExpAfter[l] /= ln[l]; }
        return res;
    }

    /** Expected-anomaly change for strengths 0,10,...,100 % of the scenario. */
    public static double[] sweep(DataStore ds, Scaler sc, UhiClassifier model, int[] rows, Scenario full, int maxRows) {
        double[] out = new double[11];
        for (int i = 0; i <= 10; i++) out[i] = run(ds, sc, model, rows, Scenario.scaled(full, i / 10.0), maxRows).deltaC();
        return out;
    }
}
