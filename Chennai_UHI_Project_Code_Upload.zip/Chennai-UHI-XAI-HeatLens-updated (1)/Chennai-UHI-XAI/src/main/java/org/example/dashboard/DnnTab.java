package org.example.dashboard;

import javafx.scene.Node;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import org.example.analytics.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** DNN training history, tuning, calibration, actual-vs-predicted, and a per-hour prediction detail view. */
final class DnnTab extends ScrollPane {
    private final AppState st;
    private final BarChart<String, Number> avp = new BarChart<>(new CategoryAxis(), new NumberAxis());
    private final Canvas cmCanvas = new Canvas(560, 330), probCanvas = new Canvas(760, 200);
    private final ComboBox<String> cmModel = new ComboBox<>(), cmSplit = new ComboBox<>(), locBox = new ComboBox<>(), hourBox = new ComboBox<>();
    private final DatePicker date = new DatePicker();
    private final Label detail = Ui.note("");
    private final TableView<String[]> perClass = Ui.table(new String[]{"Class", "Support", "Precision", "Recall", "F1", "ROC-AUC"}, new double[]{90, 80, 90, 90, 80, 90});

    DnnTab(AppState st) {
        this.st = st;
        DataStore ds = st.ds;
        Label how = Ui.note("Same 28-128-64-32-4 ReLU architecture as the DJL network. The tuned copy is trained in pure Java with Adam, dropout, early stopping on validation loss and an optional learning-rate schedule; "
                + "the configuration is chosen by VALIDATION macro-F1 only, and the test period is used once for the final scores. " + st.ms.primaryNote + ".");
        how.getStyleClass().add("banner");

        // training curves of the selected configuration
        List<String[]> hist = Results.body("dnn_training_history.csv");
        LineChart<Number, Number> loss = curve("Loss", hist, 3, 5, false), acc = curve("Accuracy (%)", hist, 4, 6, true);
        VBox cLoss = Ui.pngCard("Training vs validation loss", "Selected configuration; training values are measured in evaluation mode (no dropout) on a fixed 10,000-row subsample.", loss, "dnn_loss_curve");
        VBox cAcc = Ui.pngCard("Training vs validation accuracy", null, acc, "dnn_accuracy_curve");
        TableView<String[]> tuning = Ui.csvTable("dnn_tuning_results.csv", new int[]{0, 1, 2, 3, 4, 5, 6, 9, 10, 11, 13, 14, 15},
                new String[]{"Config", "LR", "Batch", "Drop 1", "Drop 2", "Drop 3", "Schedule", "Epochs", "Best epoch", "Val loss", "Val macro-F1", "Seconds", "Selected"},
                new double[]{120, 60, 55, 55, 55, 55, 75, 60, 75, 70, 90, 70, 70}, null);
        VBox cTune = Ui.card("Hyper-parameter search", "Learning rate, batch size, dropout, learning-rate schedule, weight decay and class weights. The dataset's classes are nearly balanced, so class weights change little.", tuning);
        TableView<String[]> gen = Ui.csvTable("dnn_generalisation.csv", new int[]{0, 1, 2, 3, 4}, new String[]{"Model", "Split", "Rows", "Accuracy", "Macro-F1"}, new double[]{130, 100, 90, 90, 90}, null);
        gen.getItems().forEach(r -> { r[3] = Ui.p1(r[3]); r[4] = Ui.p1(r[4]); });
        VBox cGen = Ui.card("Does the DNN generalise?", "Training score uses every 5th 2024 row. Validation = Jan-Jun 2025, test = Jul-Dec 2025.", gen);
        TableView<String[]> cal = Ui.csvTable("calibration_temperatures.csv", new int[]{0, 1}, new String[]{"Model", "Temperature T (fitted on validation)"}, new double[]{160, 260}, null);
        TableView<String[]> calM = Ui.csvTable("eval_summary.csv", new int[]{0, 10, 11, 12, 13}, new String[]{"Model", "Log-loss raw", "Log-loss scaled", "ECE raw", "ECE scaled"}, new double[]{140, 90, 100, 80, 90},
                r -> r[1].equals("test"));
        calM.getItems().forEach(r -> { for (int i = 1; i < 5; i++) r[i] = Ui.d3(r[i]); });
        LineChart<Number, Number> rel = reliability();
        VBox cCal = Ui.card("Probability calibration (temperature scaling)", "A single temperature T is fitted on validation rows so that stated confidence matches observed accuracy better (test period shown). Ranking and accuracy are unchanged.", new VBox(8, cal, calM, rel));

        // predictions
        for (String n : st.ms.modelNames) cmModel.getItems().add(n);
        cmModel.setValue(st.ms.primary.name());
        cmSplit.getItems().addAll("test", "validation");
        cmSplit.setValue("test");
        cmModel.valueProperty().addListener((o, a, b) -> drawCm());
        cmSplit.valueProperty().addListener((o, a, b) -> drawCm());
        avp.setAnimated(false); avp.setPrefHeight(280);
        ((NumberAxis) avp.getYAxis()).setLabel("% of hours");
        List<XYChart.Series<String, Number>> as = new ArrayList<>();
        XYChart.Series<String, Number> sa = new XYChart.Series<>(), sp = new XYChart.Series<>();
        sa.setName("Actual"); sp.setName("Predicted");
        for (String[] r : Results.body("dnn_actual_vs_predicted.csv")) { sa.getData().add(new XYChart.Data<>(r[1], Results.num(r[4]) * 100)); sp.getData().add(new XYChart.Data<>(r[1], Results.num(r[5]) * 100)); }
        avp.getData().setAll(List.of(sa, sp));
        Ui.colorSeriesBars(avp, new int[]{0x94A3B8, Palette.TEAL});
        VBox cAvp = Ui.card("Actual vs predicted UHI category (" + st.ms.primary.name() + ", test)", null, new VBox(6, avp, Ui.legend(new int[]{0x94A3B8, Palette.TEAL}, new String[]{"Actual", "Predicted"})));
        VBox cCm = Ui.pngCard("Confusion matrix", "Rows = actual class, columns = predicted class; shading = share of the actual class.", new VBox(8, new HBox(10, cmModel, cmSplit), cmCanvas), "dnn_confusion_matrix");
        VBox cPer = Ui.card("Precision, recall and F1 by class (" + st.ms.primary.name() + ", test)", null, perClass);
        List<String[]> pcr = new ArrayList<>();
        for (String[] r : Results.body("eval_per_class.csv")) if (r[0].equals(st.ms.primary.name()) && r[1].equals("test")) pcr.add(new String[]{r[2], r[3], Ui.p1(r[4]), Ui.p1(r[5]), Ui.p1(r[6]), Ui.d3(r[7])});
        Ui.fill(perClass, pcr);

        // detail view
        for (int l = 0; l < ds.nLoc; l++) locBox.getItems().add(ds.locName[l]);
        locBox.getSelectionModel().select(3);
        for (int i = 0; i < 24; i++) { int u = Cfg.hourAt(i); hourBox.getItems().add(String.format("%02d:00 UTC (%s IST)", u, Cfg.hourLabel(u))); }
        hourBox.getSelectionModel().select(14);
        LocalDate dmin = LocalDate.of(2025, 1, 1), dmax = ds.time(ds.nHours - 1).toLocalDate();
        date.setValue(LocalDate.of(2025, 10, 28));
        date.setDayCellFactory(p -> new DateCell() { @Override public void updateItem(LocalDate x, boolean e) { super.updateItem(x, e); setDisable(e || x.isBefore(dmin) || x.isAfter(dmax)); } });
        Button show = new Button("Show prediction details");
        show.setOnAction(e -> detail());
        VBox cDet = Ui.card("Prediction detail view", "Pick a validation / test hour (2025): actual class, predicted class, raw and calibrated probabilities. Explanations are on the Explainable AI page.",
                new VBox(8, new HBox(10, locBox, date, hourBox, show), detail, probCanvas));

        VBox train = new VBox(12, how, Ui.row(cLoss, cAcc), cTune, Ui.row(cGen, cCal));
        VBox pred = new VBox(12, how2(), Ui.row(cAvp, cCm), cPer, cDet);
        train.setPadding(new javafx.geometry.Insets(14)); pred.setPadding(new javafx.geometry.Insets(14));
        setContent(Ui.tabs(new String[]{"Training & tuning", "Predictions & errors"}, Ui.scroll(train), Ui.scroll(pred)));
        setFitToWidth(true);
        getStyleClass().add("page-scroll");
        st.dark.addListener((o, a, b) -> { drawCm(); detail(); });
        drawCm();
        detail();
    }

    private Node how2() {
        Label l = Ui.note("Only validation and test rows are scored here; the DNN never saw them in training. Hover nothing - values are exact counts from the stored predictions.");
        l.getStyleClass().add("banner");
        return l;
    }

    private LineChart<Number, Number> curve(String yLabel, List<String[]> hist, int trainCol, int valCol, boolean pct) {
        NumberAxis x = new NumberAxis(), y = new NumberAxis();
        x.setLabel("Epoch"); y.setLabel(yLabel); y.setForceZeroInRange(false);
        LineChart<Number, Number> c = new LineChart<>(x, y);
        c.setAnimated(false); c.setCreateSymbols(false); c.setPrefHeight(300);
        XYChart.Series<Number, Number> a = new XYChart.Series<>(), b = new XYChart.Series<>();
        a.setName("Training"); b.setName("Validation");
        for (String[] r : hist) if (r[8].equals("true")) {
            double f = pct ? 100 : 1;
            a.getData().add(new XYChart.Data<>(Results.num(r[1]), Results.num(r[trainCol]) * f));
            b.getData().add(new XYChart.Data<>(Results.num(r[1]), Results.num(r[valCol]) * f));
        }
        c.getData().setAll(List.of(a, b));
        Ui.styleLine(c.getData().get(0), Palette.TEAL, 2.6, false);
        Ui.styleLine(c.getData().get(1), 0xD62828, 2.6, false);
        return c;
    }

    private LineChart<Number, Number> reliability() {
        NumberAxis x = new NumberAxis(0, 1, 0.2), y = new NumberAxis(0, 1, 0.2);
        x.setLabel("Mean confidence"); y.setLabel("Observed accuracy");
        LineChart<Number, Number> c = new LineChart<>(x, y);
        c.setAnimated(false); c.setPrefHeight(280);
        XYChart.Series<Number, Number> ideal = new XYChart.Series<>(), raw = new XYChart.Series<>(), cal = new XYChart.Series<>();
        ideal.setName("Perfect"); raw.setName("Raw"); cal.setName("Temperature-scaled");
        ideal.getData().add(new XYChart.Data<>(0, 0)); ideal.getData().add(new XYChart.Data<>(1, 1));
        for (String[] r : Results.body("calibration_reliability.csv")) {
            if (!r[0].equals(st.ms.primary.name()) || Results.num(r[4]) < 30) continue;
            XYChart.Series<Number, Number> s = r[1].equals("raw") ? raw : cal;
            s.getData().add(new XYChart.Data<>(Results.num(r[5]), Results.num(r[6])));
        }
        c.getData().setAll(List.of(ideal, raw, cal));
        Ui.styleLine(c.getData().get(0), 0x94A3B8, 1.5, true);
        Ui.styleLine(c.getData().get(1), 0xD62828, 2.2, false);
        Ui.styleLine(c.getData().get(2), Palette.TEAL, 2.2, false);
        return c;
    }

    private void drawCm() {
        GraphicsContext g = cmCanvas.getGraphicsContext2D();
        g.clearRect(0, 0, cmCanvas.getWidth(), cmCanvas.getHeight());
        int m = st.ms.indexOf(cmModel.getValue());
        if (m < 0) return;
        int split = "test".equals(cmSplit.getValue()) ? 2 : 1;
        int[][] cm = new int[Cfg.NC][Cfg.NC];
        for (int i = 0; i < st.ds.n; i++) if (st.ds.split[i] == split && st.ms.proba[m][i] != null) cm[st.ds.cls[i]][ModelEval.argmax(st.ms.proba[m][i])]++;
        boolean dark = st.dark.get();
        double x0 = 110, y0 = 40, w = 108, h = 66;
        g.setFont(Font.font(11));
        for (int c = 0; c < Cfg.NC; c++) { g.setFill(dark ? Color.web("#E5E7EB") : Color.web("#111827")); g.setTextAlign(TextAlignment.CENTER); g.fillText("pred " + Cfg.CLASS_NAMES[c], x0 + c * w + w / 2, y0 - 10); }
        for (int a = 0; a < Cfg.NC; a++) {
            long tot = 0;
            for (int p = 0; p < Cfg.NC; p++) tot += cm[a][p];
            g.setFill(dark ? Color.web("#E5E7EB") : Color.web("#111827")); g.setTextAlign(TextAlignment.RIGHT);
            g.fillText("actual " + Cfg.CLASS_NAMES[a], x0 - 8, y0 + a * h + h / 2 + 4);
            for (int p = 0; p < Cfg.NC; p++) {
                double share = tot == 0 ? 0 : (double) cm[a][p] / tot;
                Color base = Ui.color(a == p ? Palette.TEAL : Palette.CLASS[3]);
                g.setFill(Color.color(base.getRed(), base.getGreen(), base.getBlue(), 0.10 + 0.85 * share));
                g.fillRect(x0 + p * w, y0 + a * h, w - 3, h - 3);
                g.setFill(share > 0.45 ? Color.WHITE : (dark ? Color.web("#E5E7EB") : Color.web("#111827"))); g.setTextAlign(TextAlignment.CENTER);
                g.fillText(String.format(Locale.ROOT, "%,d", cm[a][p]), x0 + p * w + w / 2, y0 + a * h + h / 2 - 2);
                g.fillText(String.format(Locale.ROOT, "%.0f%%", share * 100), x0 + p * w + w / 2, y0 + a * h + h / 2 + 14);
            }
        }
    }

    private void detail() {
        DataStore ds = st.ds;
        GraphicsContext g = probCanvas.getGraphicsContext2D();
        g.clearRect(0, 0, probCanvas.getWidth(), probCanvas.getHeight());
        int l = Math.max(0, locBox.getSelectionModel().getSelectedIndex());
        int utc = Cfg.hourAt(Math.max(0, hourBox.getSelectionModel().getSelectedIndex()));
        LocalDateTime t = date.getValue().atTime(utc, 0);
        int hi = (int) ChronoUnit.HOURS.between(DataStore.START, t);
        if (hi < 0 || hi >= ds.nHours || ds.rowAt[hi][l] < 0) { detail.setText("No observation for that point and hour."); return; }
        int r = ds.rowAt[hi][l], m = st.ms.indexOf(st.ms.primary.name());
        if (ds.split[r] == 0 || st.ms.proba[m][r] == null) { detail.setText("Pick a 2025 date: the 2024 rows were used for training, so predictions there would not be honest."); return; }
        double[] raw = new double[Cfg.NC];
        for (int c = 0; c < Cfg.NC; c++) raw[c] = st.ms.proba[m][r][c];
        double[] cal = st.ms.calibratedProba(m, r);
        int pr = ModelEval.argmax(raw);
        detail.setText(String.format(Locale.ROOT, "%s | %s IST | split: %s | actual %s | predicted %s | confidence %.0f%% raw, %.0f%% calibrated | air %.1f \u00B0C, humidity %.0f%%, observed anomaly %+.2f \u00B0C | heat-risk level %s",
                ds.locShort[l], Cfg.local(ds.time(hi)), ds.split[r] == 1 ? "validation" : "test", Cfg.CLASS_NAMES[ds.cls[r]], Cfg.CLASS_NAMES[pr], raw[pr] * 100, cal[ModelEval.argmax(cal)] * 100,
                ds.x[r][Cfg.F_AIR_T], ds.x[r][Cfg.F_RH], ds.anomaly[r], HeatRisk.LEVELS[ds.risk[r]]));
        for (int c = 0; c < Cfg.NC; c++) {
            double y = 14 + c * 44;
            g.setFill(st.dark.get() ? Color.web("#E5E7EB") : Color.web("#111827")); g.setTextAlign(TextAlignment.RIGHT); g.setFont(Font.font(11));
            g.fillText(Cfg.CLASS_NAMES[c], 80, y + 14);
            g.setFill(Color.web("#CBD5E1")); g.fillRect(90, y, raw[c] * 400, 13);
            g.setFill(Ui.color(Palette.CLASS[c])); g.fillRect(90, y + 15, cal[c] * 400, 13);
            g.setFill(st.dark.get() ? Color.web("#94A3B8") : Color.web("#6B7280")); g.setTextAlign(TextAlignment.LEFT);
            g.fillText(String.format(Locale.ROOT, "raw %.0f%%   calibrated %.0f%%%s", raw[c] * 100, cal[c] * 100, c == ds.cls[r] ? "   \u2190 actual" : ""), 500 - 0, y + 22);
        }
    }
}
