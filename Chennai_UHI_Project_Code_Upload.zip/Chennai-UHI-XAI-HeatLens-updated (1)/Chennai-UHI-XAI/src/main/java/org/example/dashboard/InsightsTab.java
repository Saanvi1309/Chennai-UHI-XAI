package org.example.dashboard;

import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.*;
import org.example.analytics.*;

/** Plain-language alerts (forecast) and insights/recommendations (current filtered view). */
final class InsightsTab extends ScrollPane {
    private final AppState st;
    private final VBox alerts = new VBox(8), insights = new VBox(8);

    InsightsTab(AppState st) {
        this.st = st;
        Button copy = new Button("Copy everything as text");
        copy.getStyleClass().add("ghost-button");
        copy.setOnAction(e -> {
            StringBuilder sb = new StringBuilder("CHENNAI UHI - ALERTS AND INSIGHTS\n\nFilters: " + st.filter.describe(st.ds) + "\n\n== Forecast alerts ==\n");
            for (InsightEngine.Insight i : st.forecastInsights) sb.append("[").append(i.kind()).append("] ").append(i.title()).append(": ").append(i.text()).append("\n");
            sb.append("\n== Insights and recommendations ==\n");
            for (InsightEngine.Insight i : st.viewInsights) sb.append("[").append(i.kind()).append("] ").append(i.title()).append(": ").append(i.text()).append("\n");
            ClipboardContent cc = new ClipboardContent();
            cc.putString(sb.toString());
            Clipboard.getSystemClipboard().setContent(cc);
        });
        VBox a = Ui.card("Forecast alerts", "Based on the 24-hour forecast chosen in the Forecast tab.", alerts);
        VBox b = Ui.card("Insights & recommendations", "Generated from the rows selected by the filters on the left.", insights);
        HBox row = new HBox(12, a, b);
        row.setFillHeight(true);
        row.setMinWidth(0);
        HBox.setHgrow(a, Priority.ALWAYS); HBox.setHgrow(b, Priority.ALWAYS);
        a.setMaxWidth(Double.MAX_VALUE); b.setMaxWidth(Double.MAX_VALUE);
        a.setMinWidth(0); b.setMinWidth(0);
        a.setPrefWidth(10); b.setPrefWidth(10);
        setContent(Ui.page(copy, row));
        setFitToWidth(true);
        getStyleClass().add("page-scroll");
        st.onView(this::updateView);
        st.onForecast(this::updateForecast);
    }

    private void updateView() {
        insights.getChildren().clear();
        for (InsightEngine.Insight i : st.viewInsights) insights.getChildren().add(Ui.insightCard(i));
    }

    private void updateForecast() {
        alerts.getChildren().clear();
        for (InsightEngine.Insight i : st.forecastInsights) alerts.getChildren().add(Ui.insightCard(i));
    }
}
