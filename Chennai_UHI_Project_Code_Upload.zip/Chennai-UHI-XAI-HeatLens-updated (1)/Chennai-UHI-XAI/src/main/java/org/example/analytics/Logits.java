package org.example.analytics;

/** A classifier that can expose its raw pre-softmax outputs (needed for temperature-scaling calibration). */
public interface Logits {
    double[] logits(double[] scaledFeatures);
}
