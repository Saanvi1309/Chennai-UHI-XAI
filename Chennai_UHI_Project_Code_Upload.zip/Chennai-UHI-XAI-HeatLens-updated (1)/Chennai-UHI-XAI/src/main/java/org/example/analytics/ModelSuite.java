package org.example.analytics;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/** Loads (or trains and saves) every model used by the dashboard: DNN, gradient boosting, logistic, forecaster. */
public final class ModelSuite {
    public Scaler scaler;
    public DnnModel dnn;          // may be null if the DJL file is missing
    /** Pure-Java tuned DNN (same 28-128-64-32-4 architecture) written by TuneDnn; null if models/dnn_tuned.bin is absent. */
    public TunedDnn tuned;
    /** The DNN used by the XAI / prediction pages: chosen between the DJL and tuned DNN by VALIDATION macro-F1 only. */
    public UhiClassifier primary;
    public String primaryNote = "";
    /** Temperature-scaling factor per model (1.0 = uncalibrated / not applicable); fitted on validation rows only. */
    public double[] temps;
    /** [model][row][class] raw logits for validation + test rows (null where the model has no logits). */
    public float[][][] logits;
    public LogisticModel lr;
    public GradientBoostedModel gb;
    public ForecastModel forecast;
    public UhiClassifier[] models;
    public String[] modelNames;
    /** [model][row][class] probabilities for validation + test rows only (null for training rows). */
    public float[][][] proba;

    public static final int[] FORECAST_HORIZONS = {1, 3, 6, 12, 18, 24};

    public record Row(String name, int n, double accuracy, double macroF1, double adjacentAccuracy, double logLoss,
                      double[] f1, int[][] cm) {}

    public static ModelSuite loadOrTrain(DataStore ds, Consumer<String> log) throws IOException {
        ModelSuite s = new ModelSuite();
        Path dir = Cfg.models();
        Files.createDirectories(dir);
        Path scF = dir.resolve("scaler.csv");
        s.scaler = Files.exists(scF) ? Scaler.load(scF) : null;
        if (s.scaler == null) { s.scaler = Scaler.fit(ds); s.scaler.save(scF); }
        try { s.dnn = DnnModel.load(dir); } catch (IOException e) { say(log, "DNN weights not found: " + e.getMessage()); }

        s.tuned = read(dir.resolve("dnn_tuned.bin"), TunedDnn.class);
        s.lr = read(dir.resolve("lr_uhi.bin"), LogisticModel.class);
        s.gb = read(dir.resolve("gb_uhi.bin"), GradientBoostedModel.class);
        if (s.lr == null || s.gb == null) {
            say(log, "Training logistic regression and gradient boosting (first run only)...");
            double[][] Xtr = rows(ds, s.scaler, 0), Xv = rows(ds, s.scaler, 1);
            int[] ytr = labels(ds, 0), yv = labels(ds, 1);
            if (s.lr == null) { s.lr = LogisticModel.fit(Xtr, ytr, Cfg.NC, 300, 0.05, 1e-4); write(dir.resolve("lr_uhi.bin"), s.lr); }
            if (s.gb == null) {
                GradientBoostedModel.Params p = new GradientBoostedModel.Params();
                s.gb = GradientBoostedModel.fit(Xtr, ytr, Xv, yv, Cfg.NC, p, log == null ? null : log::accept);
                write(dir.resolve("gb_uhi.bin"), s.gb);
            }
        }
        s.forecast = read(dir.resolve("forecast_gb.bin"), ForecastModel.class);
        if (s.forecast == null || s.forecast.nn == null) {
            say(log, "Training the 1-24 h UHI forecaster and validation-testing a neural-network challenger (first run only)...");
            s.forecast = ForecastModel.train(ds, log == null ? null : log::accept);
            s.forecast.testEval = s.forecast.evaluate(ds, 2, FORECAST_HORIZONS);
            write(dir.resolve("forecast_gb.bin"), s.forecast);
        } else if (s.forecast.testEval == null) {
            s.forecast.testEval = s.forecast.evaluate(ds, 2, FORECAST_HORIZONS);
            write(dir.resolve("forecast_gb.bin"), s.forecast);
        }
        List<UhiClassifier> ms = new ArrayList<>();
        if (s.dnn != null) ms.add(s.dnn);
        if (s.tuned != null) ms.add(s.tuned);
        ms.add(s.gb); ms.add(s.lr);
        s.models = ms.toArray(new UhiClassifier[0]);
        s.modelNames = new String[s.models.length];
        for (int i = 0; i < s.models.length; i++) s.modelNames[i] = s.models[i].name();
        return s;
    }

    public UhiClassifier byName(String n) {
        for (UhiClassifier m : models) if (m.name().equals(n)) return m;
        return models[0];
    }

    /** Scores every validation/test row with each model (a few seconds). */
    public void computePredictions(DataStore ds) {
        proba = new float[models.length][ds.n][];
        logits = new float[models.length][][];
        for (int m = 0; m < models.length; m++) if (models[m] instanceof Logits) logits[m] = new float[ds.n][];
        for (int i = 0; i < ds.n; i++) {
            if (ds.split[i] == 0) continue;
            double[] x = scaler.scale(ds.x[i]);
            for (int m = 0; m < models.length; m++) {
                double[] p;
                if (logits[m] != null) {
                    double[] z = ((Logits) models[m]).logits(x);
                    float[] zf = new float[z.length];
                    for (int c = 0; c < z.length; c++) zf[c] = (float) z[c];
                    logits[m][i] = zf;
                    p = z.clone();
                    UhiClassifier.softmaxInPlace(p);
                } else p = models[m].predictProba(x);
                float[] f = new float[p.length];
                for (int c = 0; c < p.length; c++) f[c] = (float) p[c];
                proba[m][i] = f;
            }
        }
        fitCalibration(ds);
        choosePrimary(ds);
    }

    /** Temperature scaling: one scalar T per logit model, minimising validation log-loss (test rows are never used). */
    private void fitCalibration(DataStore ds) {
        temps = new double[models.length];
        java.util.Arrays.fill(temps, 1.0);
        for (int m = 0; m < models.length; m++) {
            if (logits[m] == null) continue;
            final int mm = m;
            double lo = 0.2, hi = 6.0;
            for (int it = 0; it < 60; it++) {                       // golden-section search on a convex 1-D problem
                double a = lo + (hi - lo) * 0.382, b = lo + (hi - lo) * 0.618;
                if (valNll(ds, mm, a) < valNll(ds, mm, b)) hi = b; else lo = a;
            }
            temps[m] = (lo + hi) / 2;
        }
    }

    private double valNll(DataStore ds, int m, double t) {
        double s = 0; int n = 0;
        for (int i = 0; i < ds.n; i++) {
            if (ds.split[i] != 1) continue;
            float[] z = logits[m][i];
            double mx = Double.NEGATIVE_INFINITY;
            for (float v : z) mx = Math.max(mx, v / t);
            double sum = 0;
            for (float v : z) sum += Math.exp(v / t - mx);
            s -= (z[ds.cls[i]] / t - mx) - Math.log(sum);
            n++;
        }
        return s / Math.max(1, n);
    }

    /** Calibrated probabilities (temperature scaling) for a model's logits; falls back to raw probabilities. */
    public double[] calibratedProba(int m, int row) {
        float[] z = logits[m] == null ? null : logits[m][row];
        if (z == null) { float[] p = proba[m][row]; double[] d = new double[p.length]; for (int c = 0; c < d.length; c++) d[c] = p[c]; return d; }
        double[] d = new double[z.length];
        for (int c = 0; c < d.length; c++) d[c] = z[c] / temps[m];
        UhiClassifier.softmaxInPlace(d);
        return d;
    }

    /** A UhiClassifier view of model m with temperature scaling applied. */
    public UhiClassifier calibrated(int m) {
        final UhiClassifier base = models[m];
        final double t = temps == null ? 1.0 : temps[m];
        if (!(base instanceof Logits) || t == 1.0) return base;
        return new UhiClassifier() {
            @Override public String name() { return base.name() + " (calibrated)"; }
            @Override public double[] predictProba(double[] x) {
                double[] z = ((Logits) base).logits(x);
                for (int c = 0; c < z.length; c++) z[c] /= t;
                UhiClassifier.softmaxInPlace(z);
                return z;
            }
        };
    }

    public int indexOf(String name) {
        for (int i = 0; i < models.length; i++) if (models[i].name().equals(name)) return i;
        return -1;
    }

    /** Picks the DNN used for XAI and the prediction page by validation macro-F1 (the test split plays no part). */
    private void choosePrimary(DataStore ds) {
        int a = indexOf("DNN"), b = indexOf("DNN (tuned)");
        if (a < 0 && b < 0) { primary = models[0]; primaryNote = "No DNN available; using " + models[0].name(); return; }
        if (b < 0) { primary = models[a]; primaryNote = "DNN (DJL) is the only DNN available"; return; }
        if (a < 0) { primary = models[b]; primaryNote = "Tuned DNN is the only DNN available"; return; }
        double fa = valMacroF1(ds, a), fb = valMacroF1(ds, b);
        boolean useTuned = fb > fa;
        primary = models[useTuned ? b : a];
        primaryNote = String.format(Locale.ROOT, "Validation macro-F1: DNN (DJL) %.4f vs DNN (tuned) %.4f -> %s selected (test split not used for this choice)",
                fa, fb, primary.name());
    }

    private double valMacroF1(DataStore ds, int m) {
        int[][] cm = new int[Cfg.NC][Cfg.NC];
        for (int i = 0; i < ds.n; i++) {
            if (ds.split[i] != 1) continue;
            float[] p = proba[m][i];
            int b = 0;
            for (int c = 1; c < p.length; c++) if (p[c] > p[b]) b = c;
            cm[ds.cls[i]][b]++;
        }
        return new Metrics(cm).macroF1();
    }

    /** Metrics for each model on the given rows, restricted to validation/test rows. */
    public Row[] compare(DataStore ds, int[] rows, boolean useVal, boolean useTest) {
        Row[] out = new Row[models.length];
        for (int m = 0; m < models.length; m++) {
            int[][] cm = new int[Cfg.NC][Cfg.NC];
            double ll = 0; int n = 0;
            for (int r : rows) {
                int sp = ds.split[r];
                if (sp == 0 || (sp == 1 && !useVal) || (sp == 2 && !useTest) || proba[m][r] == null) continue;
                float[] p = proba[m][r];
                int b = 0;
                for (int c = 1; c < p.length; c++) if (p[c] > p[b]) b = c;
                cm[ds.cls[r]][b]++;
                ll -= Math.log(Math.max(p[ds.cls[r]], 1e-9));
                n++;
            }
            Metrics mt = new Metrics(cm);
            double[] f1 = new double[Cfg.NC];
            for (int c = 0; c < Cfg.NC; c++) f1[c] = mt.f1(c);
            out[m] = new Row(modelNames[m], n, mt.accuracy(), mt.macroF1(), mt.adjacentAccuracy(), n == 0 ? Double.NaN : ll / n, f1, cm);
        }
        return out;
    }

    // ------------------------------------------------------------------ results files

    public void writeResults(DataStore ds, Path dir) throws IOException {
        Files.createDirectories(dir);
        int[] all = new int[ds.n];
        for (int i = 0; i < ds.n; i++) all[i] = i;
        StringBuilder sb = new StringBuilder("model,split,rows,accuracy,macro_f1,adjacent_accuracy,log_loss,f1_low,f1_moderate,f1_high,f1_extreme\n");
        StringBuilder cmSb = new StringBuilder("model,split,actual,pred_low,pred_moderate,pred_high,pred_extreme\n");
        for (int sp = 1; sp <= 2; sp++) {
            Row[] rs = compare(ds, all, sp == 1, sp == 2);
            for (Row r : rs) {
                sb.append(String.format(Locale.ROOT, "%s,%s,%d,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f%n", r.name, sp == 1 ? "validation" : "test",
                        r.n, r.accuracy, r.macroF1, r.adjacentAccuracy, r.logLoss, r.f1[0], r.f1[1], r.f1[2], r.f1[3]));
                for (int a = 0; a < Cfg.NC; a++)
                    cmSb.append(String.format(Locale.ROOT, "%s,%s,%s,%d,%d,%d,%d%n", r.name, sp == 1 ? "validation" : "test", Cfg.CLASS_NAMES[a],
                            r.cm[a][0], r.cm[a][1], r.cm[a][2], r.cm[a][3]));
            }
        }
        Files.writeString(dir.resolve("model_comparison.csv"), sb.toString());
        Files.writeString(dir.resolve("confusion_matrices.csv"), cmSb.toString());

        // Preserve the originally recorded GB test scores before the selected-model report is refreshed.
        Path baselineForecast = dir.resolve("forecast_evaluation_baseline_gb.csv");
        Path previousForecast = dir.resolve("forecast_evaluation.csv");
        if (!Files.exists(baselineForecast) && Files.exists(previousForecast)) Files.copy(previousForecast, baselineForecast);
        ForecastModel.Eval e = forecast.testEval;
        StringBuilder fs = new StringBuilder("horizon_h,test_rows,accuracy,macro_f1,adjacent_accuracy,persistence_acc,same_hour_yesterday_acc,climatology_acc,"
                + "air_temp_mae,air_temp_mae_climatology,air_temp_mae_persistence,humidity_mae,humidity_mae_climatology,humidity_mae_persistence\n");
        for (int i = 0; i < e.horizons.length; i++)
            fs.append(String.format(Locale.ROOT, "%d,%d,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f%n", e.horizons[i], e.n[i], e.acc[i], e.macroF1[i],
                    e.adjAcc[i], e.persistAcc[i], e.yesterdayAcc[i], e.climAcc[i], e.maeT[i], e.maeTClim[i], e.maeTPersist[i], e.maeRh[i], e.maeRhClim[i], e.maeRhPersist[i]));
        Files.writeString(dir.resolve("forecast_evaluation.csv"), fs.toString());

        // Report both forecasting candidates on the exact same held-out test rows.
        // This avoids presenting the validation-selected model as an automatic improvement.
        StringBuilder fc = new StringBuilder("model,horizon_h,test_rows,accuracy,macro_f1\n");
        for (int h : FORECAST_HORIZONS) {
            int[][] cmGb = new int[Cfg.NC][Cfg.NC];
            int[][] cmNn = new int[Cfg.NC][Cfg.NC];
            int nTest = 0;
            for (int t = 0; t + h < ds.nHours; t++) for (int l = 0; l < ds.nLoc; l++) {
                int rt = ds.rowAt[t + h][l];
                if (rt < 0 || ds.split[rt] != 2) continue;
                double[] fx = forecast.features(ds, t, l, h); int actual = ds.cls[rt];
                double[] pg = forecast.gb.predictProba(fx); int bg = 0;
                for (int c = 1; c < pg.length; c++) if (pg[c] > pg[bg]) bg = c;
                cmGb[actual][bg]++;
                if (forecast.nn != null) {
                    double[] pn = forecast.nn.predictProba(fx); int bn = 0;
                    for (int c = 1; c < pn.length; c++) if (pn[c] > pn[bn]) bn = c;
                    cmNn[actual][bn]++;
                }
                nTest++;
            }
            appendForecastCandidate(fc, "GradientBoosting", h, nTest, cmGb);
            if (forecast.nn != null) appendForecastCandidate(fc, "NeuralNetwork", h, nTest, cmNn);
        }
        Files.writeString(dir.resolve("forecast_model_comparison.csv"), fc.toString());

        Files.writeString(dir.resolve("gb_feature_importance.csv"), importance(Cfg.FEATURES, gb.featureGain()));
        Files.writeString(dir.resolve("forecast_feature_importance.csv"), importance(ForecastModel.FEATURE_NAMES, forecast.gb.featureGain()));
    }

    private static void appendForecastCandidate(StringBuilder out, String name, int horizon, int n, int[][] cm) {
        Metrics mt = new Metrics(cm);
        out.append(String.format(Locale.ROOT, "%s,%d,%d,%.4f,%.4f%n", name, horizon, n, mt.accuracy(), mt.macroF1()));
    }

    static String importance(String[] names, double[] gain) {
        double tot = Arrays.stream(gain).sum();
        Integer[] idx = new Integer[names.length];
        for (int i = 0; i < idx.length; i++) idx[i] = i;
        Arrays.sort(idx, (a, b) -> Double.compare(gain[b], gain[a]));
        StringBuilder sb = new StringBuilder("feature,share_of_total_gain\n");
        for (int i : idx) sb.append(String.format(Locale.ROOT, "%s,%.5f%n", names[i], tot == 0 ? 0 : gain[i] / tot));
        return sb.toString();
    }

    // ------------------------------------------------------------------ helpers

    static double[][] rows(DataStore ds, Scaler sc, int split) {
        List<double[]> l = new ArrayList<>();
        for (int i = 0; i < ds.n; i++) if (ds.split[i] == split) l.add(sc.scale(ds.x[i]));
        return l.toArray(new double[0][]);
    }

    static int[] labels(DataStore ds, int split) {
        int c = 0;
        for (int i = 0; i < ds.n; i++) if (ds.split[i] == split) c++;
        int[] y = new int[c];
        c = 0;
        for (int i = 0; i < ds.n; i++) if (ds.split[i] == split) y[c++] = ds.cls[i];
        return y;
    }

    @SuppressWarnings("unchecked")
    private static <T> T read(Path f, Class<T> type) {
        if (!Files.exists(f)) return null;
        try (ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(Files.newInputStream(f)))) {
            return (T) in.readObject();
        } catch (Exception e) {
            return null;     // stale or incompatible file: retrain
        }
    }

    private static void write(Path f, Object o) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(Files.newOutputStream(f)))) { out.writeObject(o); }
    }

    private static void say(Consumer<String> log, String s) { if (log != null) log.accept(s); }
}
