package org.example;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;

import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class UHIClassification {

    private static final String INPUT_FILE =
            "data/processed/Chennai_UHI_With_Target.csv";

    private static final String OUTPUT_FILE =
            "data/processed/Chennai_UHI_Final.csv";

    public static void main(String[] args) {

        try {

            System.out.println("======================================");
            System.out.println("UHI CLASSIFICATION");
            System.out.println("======================================");

            // ---------------------------------------------
            // 1. Read UHI anomaly values
            // ---------------------------------------------

            List<Double> anomalies = new ArrayList<>();

            CSVParser parser = CSVFormat.DEFAULT
                    .builder()
                    .setHeader()
                    .setSkipHeaderRecord(true)
                    .get()
                    .parse(new FileReader(INPUT_FILE));

            for (CSVRecord record : parser) {

                double anomaly =
                        Double.parseDouble(
                                record.get("uhi_anomaly")
                        );

                anomalies.add(anomaly);
            }

            parser.close();

            System.out.println(
                    "Total anomaly values: " + anomalies.size()
            );

            // ---------------------------------------------
            // 2. Sort anomaly values
            // ---------------------------------------------

            Collections.sort(anomalies);

            // ---------------------------------------------
            // 3. Calculate 25th percentile
            // ---------------------------------------------

            double q25 =
                    percentile(anomalies, 25);

            // ---------------------------------------------
            // 4. Calculate 75th percentile
            // ---------------------------------------------

            double q75 =
                    percentile(anomalies, 75);

            System.out.println();
            System.out.println("New UHI class thresholds:");
            System.out.println("--------------------------------");
            System.out.println(
                    "25th percentile: " + q25
            );
            System.out.println(
                    "75th percentile: " + q75
            );

            // ---------------------------------------------
            // 5. Read original file again
            // ---------------------------------------------

            parser = CSVFormat.DEFAULT
                    .builder()
                    .setHeader()
                    .setSkipHeaderRecord(true)
                    .get()
                    .parse(new FileReader(INPUT_FILE));

            List<String> headers =
                    new ArrayList<>(
                            parser.getHeaderMap().keySet()
                    );

            headers.add("UHI_Class");

            // ---------------------------------------------
            // 6. Create output file
            // ---------------------------------------------

            FileWriter writer =
                    new FileWriter(OUTPUT_FILE);

            CSVPrinter printer =
                    new CSVPrinter(
                            writer,
                            CSVFormat.DEFAULT
                                    .builder()
                                    .setHeader(
                                            headers.toArray(
                                                    new String[0]
                                            )
                                    )
                                    .build()
                    );

            // Class counters

            long lowCount = 0;
            long moderateCount = 0;
            long highCount = 0;
            long extremeCount = 0;

            // ---------------------------------------------
            // 7. Assign UHI classes
            // ---------------------------------------------

            for (CSVRecord record : parser) {

                double anomaly =
                        Double.parseDouble(
                                record.get("uhi_anomaly")
                        );

                String uhiClass;

                if (anomaly <= q25) {

                    uhiClass = "Low";
                    lowCount++;

                } else if (anomaly <= 0) {

                    uhiClass = "Moderate";
                    moderateCount++;

                } else if (anomaly <= q75) {

                    uhiClass = "High";
                    highCount++;

                } else {

                    uhiClass = "Extreme";
                    extremeCount++;
                }

                List<String> outputRow =
                        new ArrayList<>();

                for (String header :
                        parser.getHeaderMap().keySet()) {

                    outputRow.add(
                            record.get(header)
                    );
                }

                outputRow.add(uhiClass);

                printer.printRecord(outputRow);
            }

            parser.close();
            printer.close();
            writer.close();

            // ---------------------------------------------
            // 8. Display results
            // ---------------------------------------------

            System.out.println();
            System.out.println("======================================");
            System.out.println("UHI CLASSIFICATION SUCCESSFUL!");
            System.out.println("======================================");

            System.out.println(
                    "Low       : " + lowCount
            );

            System.out.println(
                    "Moderate  : " + moderateCount
            );

            System.out.println(
                    "High      : " + highCount
            );

            System.out.println(
                    "Extreme   : " + extremeCount
            );

            System.out.println();
            System.out.println(
                    "Output file:"
            );

            System.out.println(
                    OUTPUT_FILE
            );

        } catch (Exception e) {

            System.out.println();
            System.out.println(
                    "ERROR DURING UHI CLASSIFICATION"
            );

            e.printStackTrace();
        }
    }

    // -----------------------------------------------------
    // Percentile calculation
    // -----------------------------------------------------

    private static double percentile(
            List<Double> values,
            double percentile
    ) {

        if (values.isEmpty()) {
            return Double.NaN;
        }

        double index =
                percentile / 100.0
                        * (values.size() - 1);

        int lower =
                (int) Math.floor(index);

        int upper =
                (int) Math.ceil(index);

        if (lower == upper) {
            return values.get(lower);
        }

        double weight =
                index - lower;

        return values.get(lower)
                + weight
                * (values.get(upper)
                - values.get(lower));
    }
}