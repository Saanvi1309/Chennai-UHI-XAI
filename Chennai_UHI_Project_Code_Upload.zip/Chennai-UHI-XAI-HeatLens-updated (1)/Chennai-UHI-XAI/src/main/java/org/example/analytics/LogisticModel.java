package org.example.analytics;

import java.io.Serializable;
import java.util.Random;

/** Multinomial (softmax) logistic regression trained with full-batch Adam + L2. */
public final class LogisticModel implements UhiClassifier, Serializable {
    private static final long serialVersionUID = 1L;
    private final double[][] w;
    private final double[] b;

    private LogisticModel(int k, int f) { w = new double[k][f]; b = new double[k]; }

    @Override public String name() { return "Logistic Regression"; }

    public static LogisticModel fit(double[][] X, int[] y, int k, int epochs, double lr, double l2) {
        int n = X.length, f = X[0].length;
        LogisticModel m = new LogisticModel(k, f);
        Random rnd = new Random(7);
        for (int c = 0; c < k; c++) for (int j = 0; j < f; j++) m.w[c][j] = rnd.nextGaussian() * 0.01;
        double[][] mw = new double[k][f], vw = new double[k][f];
        double[] mb = new double[k], vb = new double[k];
        double b1 = 0.9, b2 = 0.999, eps = 1e-8;
        double[][] gw = new double[k][f];
        double[] gb = new double[k], z = new double[k];
        for (int ep = 1; ep <= epochs; ep++) {
            for (double[] g : gw) java.util.Arrays.fill(g, 0);
            java.util.Arrays.fill(gb, 0);
            for (int i = 0; i < n; i++) {
                double[] x = X[i];
                for (int c = 0; c < k; c++) {
                    double s = m.b[c];
                    double[] wc = m.w[c];
                    for (int j = 0; j < f; j++) s += wc[j] * x[j];
                    z[c] = s;
                }
                UhiClassifier.softmaxInPlace(z);
                for (int c = 0; c < k; c++) {
                    double d = z[c] - (y[i] == c ? 1 : 0);
                    gb[c] += d;
                    double[] g = gw[c];
                    for (int j = 0; j < f; j++) g[j] += d * x[j];
                }
            }
            double bc1 = 1 - Math.pow(b1, ep), bc2 = 1 - Math.pow(b2, ep);
            for (int c = 0; c < k; c++) {
                for (int j = 0; j < f; j++) {
                    double g = gw[c][j] / n + l2 * m.w[c][j];
                    mw[c][j] = b1 * mw[c][j] + (1 - b1) * g;
                    vw[c][j] = b2 * vw[c][j] + (1 - b2) * g * g;
                    m.w[c][j] -= lr * (mw[c][j] / bc1) / (Math.sqrt(vw[c][j] / bc2) + eps);
                }
                double g = gb[c] / n;
                mb[c] = b1 * mb[c] + (1 - b1) * g;
                vb[c] = b2 * vb[c] + (1 - b2) * g * g;
                m.b[c] -= lr * (mb[c] / bc1) / (Math.sqrt(vb[c] / bc2) + eps);
            }
        }
        return m;
    }

    @Override public double[] predictProba(double[] x) {
        double[] z = new double[w.length];
        for (int c = 0; c < z.length; c++) {
            double s = b[c];
            for (int j = 0; j < x.length; j++) s += w[c][j] * x[j];
            z[c] = s;
        }
        UhiClassifier.softmaxInPlace(z);
        return z;
    }

    /** Coefficients per class (standardised features) - used for the model tab. */
    public double[][] coefficients() { return w; }
}
