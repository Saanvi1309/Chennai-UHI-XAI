package org.example.analytics;

import java.io.Serializable;
import java.util.Random;

/** Lightweight pure-Java feed-forward neural network for multi-horizon UHI forecasting.
 * Inputs are standardized using training data only. Hidden layers use ReLU; output uses softmax.
 * It intentionally has no external runtime dependency, so JavaFX inference remains self-contained.
 */
public final class ForecastNnModel implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final int H1 = 48, H2 = 24;
    private final int inputSize, classes;
    private final double[] mean, scale;
    private final double[][] w1, w2, w3;
    private final double[] b1, b2, b3;

    private ForecastNnModel(int n, int k, double[] mean, double[] scale, Random r) {
        inputSize=n; classes=k; this.mean=mean; this.scale=scale;
        w1=new double[H1][n]; b1=new double[H1]; w2=new double[H2][H1]; b2=new double[H2]; w3=new double[k][H2]; b3=new double[k];
        init(w1,r); init(w2,r); init(w3,r);
    }
    private static void init(double[][] w, Random r) { for (int o=0;o<w.length;o++) for(int i=0;i<w[o].length;i++) w[o][i]=r.nextGaussian()*Math.sqrt(2.0/Math.max(1,w[o].length)); }

    public static ForecastNnModel fit(double[][] x, int[] y, double[][] vx, int[] vy, int classes, java.util.function.Consumer<String> log) {
        if (x.length==0 || vx.length==0) throw new IllegalArgumentException("Neural forecaster needs training and validation rows");
        int n=x[0].length; double[] mu=new double[n], sd=new double[n];
        for(double[] row:x) for(int j=0;j<n;j++) mu[j]+=finite(row[j]);
        for(int j=0;j<n;j++) mu[j]/=x.length;
        for(double[] row:x) for(int j=0;j<n;j++){ double d=finite(row[j])-mu[j]; sd[j]+=d*d; }
        for(int j=0;j<n;j++){ sd[j]=Math.sqrt(sd[j]/Math.max(1,x.length-1)); if(!Double.isFinite(sd[j])||sd[j]<1e-8)sd[j]=1; }
        ForecastNnModel m=new ForecastNnModel(n,classes,mu,sd,new Random(20261025));
        double best=Double.POSITIVE_INFINITY; double[][] bestW1=null,bestW2=null,bestW3=null; double[] bestB1=null,bestB2=null,bestB3=null; int stale=0;
        double lr=0.002, momentum=0.85;
        double[][] v1=new double[H1][n],v2=new double[H2][H1],v3=new double[classes][H2]; double[] vb1=new double[H1],vb2=new double[H2],vb3=new double[classes];
        int[] order=new int[x.length]; for(int i=0;i<order.length;i++)order[i]=i;
        // A deterministic cap keeps first-run training practical on ordinary laptops.
        int used=Math.min(x.length,16000); int[] sample=new int[used];
        if(used==x.length) System.arraycopy(order,0,sample,0,used); else for(int i=0;i<used;i++)sample[i]=(int)((long)i*x.length/used);
        for(int epoch=0;epoch<12;epoch++) {
            for(int i=used-1;i>0;i--){int j=mix(i,epoch,used); int z=sample[i];sample[i]=sample[j];sample[j]=z;}
            for(int ii=0;ii<used;ii++) m.update(x[sample[ii]],y[sample[ii]],lr,momentum,v1,vb1,v2,vb2,v3,vb3);
            double loss=m.loss(vx,vy);
            if(log!=null) log.accept(String.format(java.util.Locale.ROOT,"  Forecast NN epoch %d/12 validation log-loss %.4f",epoch+1,loss));
            if(loss<best-1e-4){best=loss;stale=0;bestW1=copy(m.w1);bestW2=copy(m.w2);bestW3=copy(m.w3);bestB1=m.b1.clone();bestB2=m.b2.clone();bestB3=m.b3.clone();}
            else if(++stale>=3) break;
            lr*=0.92;
        }
        if(bestW1!=null){copyInto(bestW1,m.w1);copyInto(bestW2,m.w2);copyInto(bestW3,m.w3);System.arraycopy(bestB1,0,m.b1,0,m.b1.length);System.arraycopy(bestB2,0,m.b2,0,m.b2.length);System.arraycopy(bestB3,0,m.b3,0,m.b3.length);}
        return m;
    }
    private static int mix(int i,int e,int n){ return (int)Math.floorMod((long)i*1103515245L+12345L+e*7919L,n); }
    private static double finite(double v){return Double.isFinite(v)?v:0;}
    private static double[][] copy(double[][] a){double[][] b=new double[a.length][];for(int i=0;i<a.length;i++)b[i]=a[i].clone();return b;}
    private static void copyInto(double[][] a,double[][] b){for(int i=0;i<a.length;i++)System.arraycopy(a[i],0,b[i],0,a[i].length);}
    private double[] norm(double[] x){double[] z=new double[inputSize];for(int i=0;i<inputSize;i++)z[i]=(finite(x[i])-mean[i])/scale[i];return z;}
    private double[] forward(double[] raw,double[] a1,double[] a2){double[] x=norm(raw);for(int j=0;j<H1;j++){double s=b1[j];for(int i=0;i<inputSize;i++)s+=w1[j][i]*x[i];a1[j]=Math.max(0,s);}for(int j=0;j<H2;j++){double s=b2[j];for(int i=0;i<H1;i++)s+=w2[j][i]*a1[i];a2[j]=Math.max(0,s);}double[] z=new double[classes];double mx=-Double.MAX_VALUE;for(int c=0;c<classes;c++){double s=b3[c];for(int i=0;i<H2;i++)s+=w3[c][i]*a2[i];z[c]=s;mx=Math.max(mx,s);}double sum=0;for(int c=0;c<classes;c++){z[c]=Math.exp(Math.max(-60,z[c]-mx));sum+=z[c];}for(int c=0;c<classes;c++)z[c]/=Math.max(sum,1e-300);return z;}
    public double[] predictProba(double[] x){return forward(x,new double[H1],new double[H2]);}
    private void update(double[] raw,int label,double lr,double momentum,double[][] v1,double[] vb1,double[][] v2,double[] vb2,double[][] v3,double[] vb3){
        double[] x=norm(raw),a1=new double[H1],a2=new double[H2],p=forward(raw,a1,a2); double[] d3=p.clone();d3[label]-=1;
        double[] d2=new double[H2];for(int j=0;j<H2;j++){double s=0;for(int c=0;c<classes;c++)s+=w3[c][j]*d3[c];d2[j]=a2[j]>0?s:0;}
        double[] d1=new double[H1];for(int j=0;j<H1;j++){double s=0;for(int k=0;k<H2;k++)s+=w2[k][j]*d2[k];d1[j]=a1[j]>0?s:0;}
        for(int c=0;c<classes;c++){for(int j=0;j<H2;j++)w3[c][j]-=lr*(d3[c]*a2[j]+1e-5*w3[c][j]);vb3[c]=momentum*vb3[c]+lr*d3[c];b3[c]-=vb3[c];}
        for(int j=0;j<H2;j++){for(int k=0;k<H1;k++)w2[j][k]-=lr*(d2[j]*a1[k]+1e-5*w2[j][k]);vb2[j]=momentum*vb2[j]+lr*d2[j];b2[j]-=vb2[j];}
        for(int j=0;j<H1;j++){for(int k=0;k<inputSize;k++)w1[j][k]-=lr*(d1[j]*x[k]+1e-5*w1[j][k]);vb1[j]=momentum*vb1[j]+lr*d1[j];b1[j]-=vb1[j];}
    }
    private double loss(double[][] x,int[] y){double s=0;for(int i=0;i<x.length;i++){double[] p=predictProba(x[i]);s-=Math.log(Math.max(1e-12,p[y[i]]));}return s/x.length;}
    public static double macroF1(ForecastNnModel m,double[][] x,int[] y,int classes){int[][] cm=new int[classes][classes];for(int i=0;i<x.length;i++){double[] p=m.predictProba(x[i]);int b=0;for(int c=1;c<p.length;c++)if(p[c]>p[b])b=c;cm[y[i]][b]++;}double sum=0;for(int c=0;c<classes;c++){double tp=cm[c][c],fp=0,fn=0;for(int j=0;j<classes;j++){if(j!=c){fp+=cm[j][c];fn+=cm[c][j];}}double den=2*tp+fp+fn;sum+=den==0?0:2*tp/den;}return sum/classes;}
}
