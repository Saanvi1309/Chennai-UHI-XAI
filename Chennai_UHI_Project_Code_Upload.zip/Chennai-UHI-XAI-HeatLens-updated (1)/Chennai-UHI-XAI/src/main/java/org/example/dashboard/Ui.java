package org.example.dashboard;

import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import org.example.analytics.Palette;

import java.util.List;
import java.util.Locale;

/** Small UI helper toolbox shared by the tabs. */
final class Ui {
    private Ui() {}

    static String css(int rgb) { return Palette.hex(rgb); }
    static Color color(int rgb) { return Color.rgb((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255); }
    static String pct(double v) { return Double.isNaN(v) ? "-" : String.format(Locale.ROOT, "%.1f%%", v * 100); }
    static String pct0(double v) { return String.format(Locale.ROOT, "%.0f%%", v * 100); }
    static String num(double v, int d) { return Double.isNaN(v) ? "-" : String.format(Locale.ROOT, "%." + d + "f", v); }

    static Label label(String text, String styleClass) {
        Label l = new Label(text);
        l.getStyleClass().add(styleClass);
        return l;
    }

    static VBox card(String title, Node content) {
        VBox b = new VBox(8);
        b.getStyleClass().add("card");
        if (title != null) b.getChildren().add(label(title, "card-title"));
        b.getChildren().add(content);
        b.setMinWidth(0);
        VBox.setVgrow(content, Priority.ALWAYS);
        return b;
    }

    static VBox card(String title, String subtitle, Node content) {
        VBox b = card(title, content);
        Label s = label(subtitle, "card-sub");
        s.setWrapText(true);
        b.getChildren().add(1, s);
        return b;
    }

    /** KPI tile whose value can be updated. */
    static final class Kpi extends VBox {
        private final Label value = new Label("-"), sub = new Label();
        Kpi(String title, int accent) {
            super(2);
            getStyleClass().add("kpi");
            setStyle("-kpi-accent: " + css(accent) + ";");
            Label t = label(title, "kpi-title");
            value.getStyleClass().add("kpi-value");
            sub.getStyleClass().add("kpi-sub");
            getChildren().addAll(t, value, sub);
            HBox.setHgrow(this, Priority.ALWAYS);
            setMaxWidth(Double.MAX_VALUE);
        }
        void set(String v, String s) { value.setText(v); sub.setText(s == null ? "" : s); }
        Kpi compact() { value.setStyle("-fx-font-size: 17px;"); return this; }
    }

    static HBox row(Node... n) {
        HBox h = new HBox(12, n);
        for (Node x : n) HBox.setHgrow(x, Priority.ALWAYS);
        return h;
    }

    static Node dot(int rgb) {
        Circle c = new Circle(5, color(rgb));
        return c;
    }

    static HBox legendItem(int rgb, String text) {
        HBox h = new HBox(5, dot(rgb), label(text, "legend"));
        h.setAlignment(Pos.CENTER_LEFT);
        return h;
    }

    static FlowPane legend(int[] colors, String[] names) {
        FlowPane f = new FlowPane(12, 4);

        if (colors == null || colors.length == 0 ||
                names == null) {
            return f;
        }

        for (int i = 0; i < names.length; i++) {
            int color = colors[i % colors.length];
            f.getChildren().add(
                    legendItem(color, names[i])
            );
        }

        return f;
    }

    static void colorBars(BarChart<String, Number> chart, int[] colors) {
        for (XYChart.Series<String, Number> s : chart.getData()) {
            for (int i = 0; i < s.getData().size(); i++) {
                final int c = colors[i % colors.length];
                XYChart.Data<String, Number> d = s.getData().get(i);
                if (d.getNode() != null) d.getNode().setStyle("-fx-bar-fill: " + css(c) + ";");
                d.nodeProperty().addListener((o, a, n) -> { if (n != null) n.setStyle("-fx-bar-fill: " + css(c) + ";"); });
            }
        }
    }

    static void colorSeriesBars(BarChart<String, Number> chart, int[] seriesColors) {
        for (int k = 0; k < chart.getData().size(); k++) {
            final int c = seriesColors[k % seriesColors.length];
            for (XYChart.Data<String, Number> d : chart.getData().get(k).getData()) {
                if (d.getNode() != null) d.getNode().setStyle("-fx-bar-fill: " + css(c) + ";");
                d.nodeProperty().addListener((o, a, n) -> { if (n != null) n.setStyle("-fx-bar-fill: " + css(c) + ";"); });
            }
        }
    }

    static <X, Y> void styleLine(XYChart.Series<X, Y> s, int rgb, double width, boolean dashed) {
        String st = "-fx-stroke: " + css(rgb) + "; -fx-stroke-width: " + width + "px;" + (dashed ? " -fx-stroke-dash-array: 6 5;" : "");
        if (s.getNode() != null) s.getNode().setStyle(st);
        s.nodeProperty().addListener((o, a, n) -> { if (n != null) n.setStyle(st); });
    }

    private static double textWidth(String s, boolean bold) {
        javafx.scene.text.Text t = new javafx.scene.text.Text(s == null ? "" : s);
        t.setFont(javafx.scene.text.Font.font("Segoe UI", bold ? javafx.scene.text.FontWeight.BOLD : javafx.scene.text.FontWeight.NORMAL, 13));
        return t.getLayoutBounds().getWidth();
    }

    /**
     * Table whose columns are never narrower than their full header text (and, after fill(), their cell text).
     * Columns use the given widths as a minimum and are stretched proportionally when the table is wider than needed;
     * when the table is narrower than the columns need, a horizontal scroll bar appears instead of clipping headers.
     */
    static TableView<String[]> table(String[] headers, double[] widths) {
        TableView<String[]> t = new TableView<>();
        t.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
        for (int i = 0; i < headers.length; i++) {
            final int idx = i;
            TableColumn<String[], String> c = new TableColumn<>(headers[i]);
            c.setCellValueFactory(cd -> new SimpleStringProperty(cd.getValue()[idx]));
            double base = Math.max(widths[i], textWidth(headers[i], true) * 1.08 + 34);
            c.setUserData(base);
            c.setMinWidth(Math.min(base, textWidth(headers[i], true) * 1.08 + 34));
            c.setPrefWidth(base);
            c.setSortable(false);
            t.getColumns().add(c);
        }
        t.setPlaceholder(new Label("No rows"));
        t.widthProperty().addListener((o, a, b) -> stretch(t));
        return t;
    }

    /** Distributes spare width over the columns in proportion to their needed widths. */
    private static void stretch(TableView<String[]> t) {
        double sum = 0;
        for (TableColumn<String[], ?> c : t.getColumns()) sum += c.getUserData() instanceof Double d ? d : c.getPrefWidth();
        double avail = t.getWidth() - 20;
        double f = avail > sum && sum > 0 ? avail / sum : 1.0;
        for (TableColumn<String[], ?> c : t.getColumns()) {
            double base = c.getUserData() instanceof Double d ? d : c.getPrefWidth();
            c.setPrefWidth(base * f);
        }
    }

    /** Widens columns to fit the longest visible cell text (capped), so values are not cut off with '...'. */
    private static void fitColumns(TableView<String[]> t, List<String[]> rows) {
        for (int i = 0; i < t.getColumns().size(); i++) {
            TableColumn<String[], ?> c = t.getColumns().get(i);
            double need = textWidth(c.getText(), true) * 1.08 + 34;
            int step = Math.max(1, rows.size() / 60);
            for (int r = 0; r < rows.size(); r += step) {
                String[] row = rows.get(r);
                if (i < row.length && row[i] != null) need = Math.max(need, Math.min(700, textWidth(row[i], false) * 1.06 + 22));
            }
            double cur = c.getUserData() instanceof Double d ? d : c.getPrefWidth();
            c.setUserData(Math.max(cur, need));
        }
        stretch(t);
    }

    static void fill(TableView<String[]> t, List<String[]> rows) {
        t.getItems().setAll(rows);
        t.setPrefHeight(34 + 26 * Math.min(rows.size(), 12));
        fitColumns(t, rows);
    }

    static ScrollPane scroll(Node n) {
        ScrollPane sp = new ScrollPane(n);
        sp.setFitToWidth(true);
        sp.getStyleClass().add("page-scroll");
        return sp;
    }

    static VBox page(Node... n) {
        VBox v = new VBox(12, n);
        v.setPadding(new Insets(14));
        return v;
    }

    static Label note(String text) {
        Label l = label(text, "note");
        l.setWrapText(true);
        return l;
    }

    static final String[] MONTHS = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    static final int[] LOC_COLORS = {0x1F77B4, 0xFF7F0E, 0x2CA02C, 0xD62728, 0x9467BD, 0x8C564B};

    /** 24 unique category names; every third shows the IST clock label, the others are invisible padding. */
    static java.util.List<String> hourCats() {
        java.util.List<String> l = new java.util.ArrayList<>();
        for (int i = 0; i < 24; i++) l.add(i % 3 == 0 ? org.example.analytics.Cfg.hourLabel(org.example.analytics.Cfg.hourAt(i)) : "\u200B".repeat(i + 1));
        return l;
    }

    static String[] hourLabelsRot() {
        String[] a = new String[24];
        for (int i = 0; i < 24; i++) a[i] = org.example.analytics.Cfg.hourLabel(org.example.analytics.Cfg.hourAt(i));
        return a;
    }

    static Node insightCard(org.example.analytics.InsightEngine.Insight in) {
        int c = switch (in.kind()) {
            case "alert" -> Palette.RISK[3]; case "warn" -> Palette.RISK[2]; case "rec" -> Palette.TEAL; default -> 0x94A3B8; };
        String tag = switch (in.kind()) { case "alert" -> "ALERT"; case "warn" -> "WATCH"; case "rec" -> "RECOMMENDATION"; default -> "INSIGHT"; };
        Label k = label(tag, "insight-text");
        k.setStyle("-fx-font-size: 9.5px; -fx-font-weight: bold; -fx-text-fill: " + css(c) + ";");
        Label t = label(in.title(), "insight-title");
        Label x = label(in.text(), "insight-text");
        x.setWrapText(true);
        VBox b = new VBox(2, k, t, x);
        b.getStyleClass().add("insight");
        b.setStyle("-ins: " + css(c) + ";");
        return b;
    }

    // ------------------------------------------------------------------ additions for the HeatLens pages

    static final int[] MODEL_COLORS = {0xD62828, 0xFF7F0E, 0x1F7A8C, 0x9467BD};

    /** A table filled from a results/*.csv file. cols = CSV column indices to show; filter may be null. */
    static TableView<String[]> csvTable(String file, int[] cols, String[] headers, double[] widths, java.util.function.Predicate<String[]> filter) {
        TableView<String[]> t = table(headers, widths);
        java.util.List<String[]> out = new java.util.ArrayList<>();
        for (String[] r : org.example.analytics.Results.body(file)) {
            if (filter != null && !filter.test(r)) continue;
            String[] o = new String[cols.length];
            for (int i = 0; i < cols.length; i++) o[i] = cols[i] < r.length ? r[cols[i]] : "";
            out.add(o);
        }
        fill(t, out);
        return t;
    }

    /** Percentage text of a 0-1 CSV value. */
    static String p1(String s) { double v = org.example.analytics.Results.num(s); return Double.isNaN(v) ? s : pct(v); }
    static String d3(String s) { double v = org.example.analytics.Results.num(s); return Double.isNaN(v) ? s : num(v, 3); }

    /** Saves a PNG snapshot of a node into exports/ and returns the path. */
    static java.nio.file.Path savePng(Node n, String baseName) throws java.io.IOException {
        javafx.scene.image.WritableImage img = n.snapshot(new javafx.scene.SnapshotParameters(), null);
        int w = (int) img.getWidth(), h = (int) img.getHeight();
        java.awt.image.BufferedImage bi = new java.awt.image.BufferedImage(w, h, java.awt.image.BufferedImage.TYPE_INT_ARGB);
        javafx.scene.image.PixelReader pr = img.getPixelReader();
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) bi.setRGB(x, y, pr.getArgb(x, y));
        java.nio.file.Path dir = org.example.analytics.Cfg.exports();
        java.nio.file.Files.createDirectories(dir);
        java.nio.file.Path p = dir.resolve(baseName + "_" + org.example.analytics.ReportExporter.stamp() + ".png");
        javax.imageio.ImageIO.write(bi, "png", p.toFile());
        return p;
    }

    /** Card with a "Save PNG" button that exports the card content as an image. */
    static VBox pngCard(String title, String subtitle, Node content, String baseName) {
        Button b = new Button("Save PNG");
        b.getStyleClass().add("ghost-button");
        b.setOnAction(e -> {
            try {
                java.nio.file.Path p = savePng(content, baseName);
                new Alert(Alert.AlertType.INFORMATION, "Saved to:\n" + p).show();
            } catch (Exception ex) { new Alert(Alert.AlertType.ERROR, "Could not save image: " + ex).show(); }
        });
        VBox c = subtitle == null ? card(title, content) : card(title, subtitle, content);
        c.getChildren().add(b);
        return c;
    }

    /** Runs an export on a worker thread and reports the saved path. */
    static void runExport(AppState st, Node owner, java.util.concurrent.Callable<java.nio.file.Path> job) {
        javafx.concurrent.Task<java.nio.file.Path> task = new javafx.concurrent.Task<>() {
            @Override protected java.nio.file.Path call() throws Exception { return job.call(); }
        };
        task.setOnSucceeded(e -> {
            java.nio.file.Path p = task.getValue();
            ButtonType open = new ButtonType("Open file"), close = new ButtonType("Close", ButtonBar.ButtonData.CANCEL_CLOSE);
            Alert a = new Alert(Alert.AlertType.INFORMATION, "Saved to:\n" + p, open, close);
            a.setHeaderText("Export complete");
            a.showAndWait().ifPresent(b -> { if (b == open && st.host != null) st.host.showDocument(p.toUri().toString()); });
        });
        task.setOnFailed(e -> { task.getException().printStackTrace(); new Alert(Alert.AlertType.ERROR, "Export failed: " + task.getException()).show(); });
        Thread th = new Thread(task, "uhi-export");
        th.setDaemon(true);
        th.start();
    }

    static Label heading(String text) { return label(text, "card-title"); }

    /** Nested tab pane helper. */
    static TabPane tabs(String[] names, Node... pages) {
        TabPane tp = new TabPane();
        tp.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        for (int i = 0; i < names.length; i++) tp.getTabs().add(new Tab(names[i], pages[i]));
        tp.setMinWidth(0);
        return tp;
    }

    static void colorSeriesBars(javafx.scene.chart.StackedBarChart<String, Number> chart, int[] seriesColors) {
        for (int k = 0; k < chart.getData().size(); k++) {
            final int c = seriesColors[k % seriesColors.length];
            for (XYChart.Data<String, Number> d : chart.getData().get(k).getData()) {
                if (d.getNode() != null) d.getNode().setStyle("-fx-bar-fill: " + css(c) + ";");
                d.nodeProperty().addListener((o, a, n) -> { if (n != null) n.setStyle("-fx-bar-fill: " + css(c) + ";"); });
            }
        }
    }
}
