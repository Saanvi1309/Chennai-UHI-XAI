package org.example.analytics;

import java.io.IOException;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** PDF reports for the new modules: model performance / evaluation and the per-location XAI explanation report. */
public final class AnalysisReports {
    private AnalysisReports() {}

    private static String when() { return LocalDateTime.now().format(DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm")); }

    // ============================================================ model performance report

    public static Path modelPerformancePdf(DataStore ds, ModelSuite ms, Path out) throws IOException {
        PdfDoc doc = new PdfDoc();
        PdfDoc.Page p = doc.newPage();
        header(p, "Chennai UHI - Model performance report", "Generated " + when() + "   |   validation = Jan-Jun 2025 (model selection), test = Jul-Dec 2025 (final scores only)");
        double y = 86;
        p.text(40, y, 11, true, Palette.NAVY, "1. Classifier comparison (test period, untouched during model selection)");
        y += 8;
        List<String[]> ev = Results.body("eval_summary.csv");
        String[] h1 = {"Model", "Accuracy", "Macro-P", "Macro-R", "Macro-F1", "Weighted-F1", "+/-1 class", "ROC-AUC", "Log-loss", "ECE raw", "ECE cal."};
        double[] w1 = {92, 46, 44, 44, 46, 52, 46, 44, 44, 44, 44};
        table(p, 40, y, h1, w1, filter(ev, 1, "test", new int[]{0, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13}, new int[]{0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}));
        y += 15 * (1 + countRows(ev, "test")) + 14;
        p.text(40, y, 9, true, Palette.NAVY, "Numeric UHI anomaly (probability-weighted class mean), timing");
        y += 8;
        String[] h2 = {"Model", "MAE (C)", "RMSE (C)", "R2", "Bias (C)", "Train s", "Inference us/row"};
        double[] w2 = {110, 60, 60, 60, 60, 60, 100};
        table(p, 40, y, h2, w2, filter(ev, 1, "test", new int[]{0, 15, 16, 17, 18, 19, 20}, new int[]{0, 0, 0, 0, 0, 2, 2}));
        y += 15 * (1 + countRows(ev, "test")) + 16;

        p.text(40, y, 11, true, Palette.NAVY, "2. Per-class precision / recall / F1 (primary DNN: " + ms.primary.name() + ", test)");
        y += 8;
        List<String[]> pc = Results.body("eval_per_class.csv");
        List<String[]> pcr = new ArrayList<>();
        for (String[] r : pc) if (r[0].equals(ms.primary.name()) && r[1].equals("test")) pcr.add(new String[]{r[2], r[3], pct(r[4]), pct(r[5]), pct(r[6]), String.format(Locale.ROOT, "%.3f", Results.num(r[7]))});
        table(p, 40, y, new String[]{"Class", "Support", "Precision", "Recall", "F1", "ROC-AUC (OvR)"}, new double[]{90, 70, 80, 80, 80, 100}, pcr);
        y += 15 * (1 + pcr.size()) + 16;

        // training curves of the selected configuration
        List<String[]> hist = Results.body("dnn_training_history.csv");
        List<double[]> tl = new ArrayList<>(), vl = new ArrayList<>(), ta = new ArrayList<>(), va = new ArrayList<>();
        for (String[] r : hist) if (r[8].equals("true")) { tl.add(new double[]{Results.num(r[1]), Results.num(r[3])}); vl.add(new double[]{Results.num(r[1]), Results.num(r[5])});
            ta.add(new double[]{Results.num(r[1]), Results.num(r[4]) * 100}); va.add(new double[]{Results.num(r[1]), Results.num(r[6]) * 100}); }
        p.text(40, y, 11, true, Palette.NAVY, "3. Training history of the selected configuration (early stopping on validation loss)");
        y += 6;
        xyChart(p, 40, y, 250, 150, "Loss: training vs validation", new double[][][]{arr(tl), arr(vl)}, new String[]{"training", "validation"}, new int[]{Palette.TEAL, 0xD62828});
        xyChart(p, 305, y, 250, 150, "Accuracy %: training (eval mode) vs validation", new double[][][]{arr(ta), arr(va)}, new String[]{"training", "validation"}, new int[]{Palette.TEAL, 0xD62828});
        y += 160;
        p.text(40, y, 9, true, Palette.NAVY, "Hyper-parameter search (selection by validation macro-F1)");
        y += 8;
        List<String[]> tn = Results.body("dnn_tuning_results.csv");
        List<String[]> tnr = new ArrayList<>();
        for (String[] r : tn) tnr.add(new String[]{r[0], r[1], r[2], r[3] + "/" + r[4] + "/" + r[5], r[6], r[9], r[11], r[13], r[15].equals("true") ? "selected" : ""});
        table(p, 40, y, new String[]{"Config", "LR", "Batch", "Dropout", "Schedule", "Epochs", "Val loss", "Val F1", ""}, new double[]{90, 40, 36, 90, 56, 40, 56, 56, 50}, tnr);
        footer(p, 1);

        // ---------------- page 2 : forecasting
        p = doc.newPage();
        header(p, "Forecasting validation", "All values from the held-out test period; nothing interpolated");
        y = 86;
        p.text(40, y, 11, true, Palette.NAVY, "Timestamp alignment");
        y += 8;
        List<String[]> ta2 = Results.body("time_alignment_check.csv");
        List<String[]> tar = new ArrayList<>();
        for (String[] r : ta2) tar.add(new String[]{r[0], r[3], r[4], r[5], r[6], r[7] + "-" + r[8], r[9]});
        table(p, 40, y, new String[]{"Point", "Rows", "Expected", "Missing h", "Duplicates", "Step (h)", "Hourly"}, new double[]{60, 70, 70, 70, 70, 70, 60}, tar);
        y += 15 * (1 + tar.size()) + 8;
        List<String[]> th = Results.body("time_alignment_horizons.csv");
        StringBuilder cov = new StringBuilder("Coverage of observed targets: ");
        for (String[] r : th) cov.append("+").append(r[0]).append("h ").append(r[3]).append("%").append("  ");
        y = p.paragraph(40, y + 4, 515, 8, false, Palette.GREY, cov + " (100% = every forecast origin has a real observation h hours later, so no interpolation was needed).", 10) + 6;
        p.text(40, y, 11, true, Palette.NAVY, "Forecast performance by horizon (test)");
        y += 8;
        List<String[]> fh = Results.body("forecast_horizon_table.csv");
        List<String[]> fr = new ArrayList<>();
        for (String[] r : fh) fr.add(new String[]{"+" + r[0] + " h", r[1], pct(r[2]), pct(r[3]), r[5], r[6], r[7], r[8], r[11], pct(r[17])});
        table(p, 40, y, new String[]{"Horizon", "Rows", "Accuracy", "Macro-F1", "T MAE", "T RMSE", "T R2", "Anom. MAE", "Mean conf.", "Yesterday"}, new double[]{50, 52, 52, 52, 48, 50, 44, 56, 56, 55}, fr);
        y += 15 * (1 + fr.size()) + 14;
        double[][] accS = new double[2][fh.size()], baseS = new double[1][fh.size()];
        List<double[]> a1 = new ArrayList<>(), a2 = new ArrayList<>();
        for (String[] r : fh) { a1.add(new double[]{Results.num(r[0]), Results.num(r[2]) * 100}); a2.add(new double[]{Results.num(r[0]), Results.num(r[17]) * 100}); }
        xyChart(p, 40, y, 250, 150, "Accuracy % by horizon", new double[][][]{arr(a1), arr(a2)}, new String[]{"forecast", "same hour yesterday"}, new int[]{Palette.TEAL, 0xFF7F0E});
        List<double[]> m1 = new ArrayList<>(), m2 = new ArrayList<>(), m3 = new ArrayList<>();
        for (String[] r : fh) { m1.add(new double[]{Results.num(r[0]), Results.num(r[5])}); m2.add(new double[]{Results.num(r[0]), Results.num(r[13])}); m3.add(new double[]{Results.num(r[0]), Results.num(r[15])}); }
        xyChart(p, 305, y, 250, 150, "Air-temperature MAE (C) by horizon", new double[][][]{arr(m1), arr(m2), arr(m3)}, new String[]{"forecast", "persistence", "climatology"}, new int[]{Palette.TEAL, 0xFF7F0E, 0x9467BD});
        y += 166;
        p.text(40, y, 11, true, Palette.NAVY, "Error analysis by grid point (+6 h, +24 h)");
        y += 8;
        List<String[]> fl = Results.body("forecast_by_location.csv");
        List<String[]> flr = new ArrayList<>();
        for (String[] r : fl) if (r[0].equals("6") || r[0].equals("24")) flr.add(new String[]{"+" + r[0] + " h", r[1], r[2], pct(r[3]), r[4], r[5]});
        table(p, 40, y, new String[]{"Horizon", "Point", "Rows", "Accuracy", "T MAE (C)", "T RMSE (C)"}, new double[]{70, 60, 70, 80, 80, 80}, flr);
        footer(p, 2);

        // ---------------- page 3 : explainability + urban
        p = doc.newPage();
        header(p, "Explainable AI and urban heat findings", "Shapley attributions on the actual DNN weights (" + ms.primary.name() + ")");
        y = 86;
        List<String[]> gi = Results.body("xai_global_importance.csv");
        int top = Math.min(14, gi.size());
        String[] lab = new String[top]; double[] val = new double[top]; int[] col = new int[top];
        for (int i = 0; i < top; i++) { lab[i] = Cfg.prettyFeature(gi.get(i)[1]); val[i] = Results.num(gi.get(i)[3]) * 100; col[i] = groupColor(gi.get(i)[2]); }
        hbars(p, 40, y, 515, top * 15 + 40, "Global feature importance: mean |Shapley value| (percentage points of class probability)", lab, val, col);
        y += top * 15 + 52;
        p.text(40, y, 9, true, Palette.NAVY, "Group totals and deletion-test faithfulness");
        y += 8;
        List<String[]> gr = new ArrayList<>();
        for (String[] r : Results.body("xai_group_importance.csv")) gr.add(new String[]{r[0], String.format(Locale.ROOT, "%.3f", Results.num(r[1])), pct(r[2])});
        table(p, 40, y, new String[]{"Feature group", "Sum mean |phi|", "Share"}, new double[]{200, 90, 70}, gr);
        List<String[]> fa = new ArrayList<>();
        for (String[] r : Results.body("xai_faithfulness.csv")) fa.add(new String[]{r[0], String.format(Locale.ROOT, "%.3f", Results.num(r[1])), String.format(Locale.ROOT, "%.3f", Results.num(r[2]))});
        table(p, 40 + 380, y, new String[]{"Remove k", "Top-k by phi", "Random k"}, new double[]{45, 45, 45}, fa);
        y += 15 * (1 + Math.max(gr.size(), fa.size())) + 14;
        p.text(40, y, 11, true, Palette.NAVY, "Hotspots and heat-risk ranking (2024-2025, six measured grid points)");
        y += 8;
        List<String[]> hs = new ArrayList<>();
        for (String[] r : Results.body("hotspot_persistence.csv")) hs.add(new String[]{r[0] + " " + r[1], r[2], pct(r[3]), r[4] + "/24", r[6] + " / " + r[7], r[8]});
        table(p, 40, y, new String[]{"Point", "Mean anomaly (C)", "Extreme share", "Months top-2", "Rank 2024 / 2025", "Verdict"}, new double[]{140, 70, 62, 62, 70, 110}, hs);
        y += 15 * (1 + hs.size()) + 14;
        p.text(40, y, 11, true, Palette.NAVY, "Planning priorities (rule-based screening, 0 = low, 1 = high)");
        y += 8;
        List<String[]> pl = new ArrayList<>();
        for (String[] r : Results.body("urban_planning_priorities.csv"))
            pl.add(new String[]{r[0], r[2], f3(r[9]), f3(r[10]), f3(r[11]), f3(r[12]), f3(r[13]), r[14]});
        table(p, 40, y, new String[]{"Point", "Heat rank", "Trees", "Green space", "Cool roofs", "Roadside", "Water", "Top measure"}, new double[]{40, 48, 50, 62, 56, 56, 50, 150}, pl);
        y += 15 * (1 + pl.size()) + 10;
        y = p.paragraph(40, y + 6, 515, 7.5, false, Palette.GREY,
                "Scores rank the six 0.25-degree grid cells (about 28 km) using observed heat exposure and the static land-cover indicators in the dataset. They are screening guidance, not site designs. "
                        + "Simulated temperature changes come from editing DNN input features; they are model-based simulations and not guaranteed real-world reductions - several presets give changes smaller than the model error.", 10);
        footer(p, 3);

        // ---------------- page 4 : written analysis
        p = doc.newPage();
        header(p, "Model performance analysis", "Answers generated from the computed metrics");
        y = 90;
        for (String para : Results.text(AnalysisRunner.MARKER).split("\n")) {
            if (para.isBlank()) { y += 4; continue; }
            boolean head = para.length() > 2 && Character.isDigit(para.charAt(0)) && para.charAt(1) == '.';
            y = p.paragraph(head ? 40 : 48, y, head ? 515 : 507, head ? 10 : 8.5, head, head ? Palette.NAVY : Palette.INK, para.trim(), head ? 14 : 11.5);
            if (y > 790) break;
        }
        footer(p, 4);
        doc.save(out);
        return out;
    }

    // ============================================================ XAI report for one location/hour

    public static Path xaiReportPdf(DataStore ds, ModelSuite ms, UhiClassifier model, Xai.Explanation e, Path out) throws IOException {
        PdfDoc doc = new PdfDoc();
        int r = e.row(), l = ds.loc[r];
        PdfDoc.Page p = doc.newPage();
        LocalDateTime utc = ds.time(ds.hourIdx[r]);
        header(p, "Explanation report - " + ds.locShort[l] + "  " + Cfg.local(utc).format(DateTimeFormatter.ofPattern("d MMM yyyy HH:mm")) + " IST",
                "Model: " + model.name() + "   |   generated " + when() + "   |   data timestamp " + utc + " UTC");
        double y = 86;
        String hint = Cfg.areaHint(ds.locLat[l], ds.locLon[l]);
        p.text(40, y, 9, false, Palette.GREY, ds.locName[l]);
        y += 16;
        int mi = ms.indexOf(model.name());
        double[] cal = mi >= 0 && ms.temps != null ? calibrate(model, e) : e.proba();
        String[][] tiles = {{"Actual UHI class", Cfg.CLASS_NAMES[ds.cls[r]]}, {"Predicted class", Cfg.CLASS_NAMES[e.predictedClass()]},
                {"Confidence (raw)", String.format(Locale.ROOT, "%.0f%%", e.proba()[e.predictedClass()] * 100)}, {"Confidence (calibrated)", String.format(Locale.ROOT, "%.0f%%", cal[ModelEval.argmax(cal)] * 100)},
                {"UHI anomaly (observed)", String.format(Locale.ROOT, "%+.2f C", ds.anomaly[r])}, {"Land surface temp.", String.format(Locale.ROOT, "%.1f C", ds.lst[r])}};
        for (int i = 0; i < 6; i++) tile(p, 40 + (i % 3) * 175, y + (i / 3) * 52, 165, 44, tiles[i][0], tiles[i][1]);
        y += 112;
        bars(p, 40, y, 250, 130, "Class probabilities (raw softmax)", Cfg.CLASS_NAMES, e.proba(), Palette.CLASS, true);
        bars(p, 305, y, 250, 130, "Class probabilities (temperature-scaled)", Cfg.CLASS_NAMES, cal, Palette.CLASS, true);
        y += 146;
        y = p.paragraph(40, y, 515, 9, false, Palette.INK, Xai.narrative(e, ds, 5), 12.5) + 4;
        p.text(40, y + 10, 11, true, Palette.NAVY, "Waterfall: how the features move P(" + Cfg.CLASS_NAMES[e.explainedClass()] + ") from the average to this prediction");
        y += 20;
        waterfall(p, 40, y, 515, e);
        y += 12 * 16 + 52;
        double[] gp = e.groupPhi();
        p.text(40, y, 9, true, Palette.NAVY, "Contribution by feature group (percentage points)");
        y += 8;
        List<String[]> gr = new ArrayList<>();
        for (int k = 0; k < Xai.GROUPS.length; k++) gr.add(new String[]{Xai.GROUPS[k], String.format(Locale.ROOT, "%+.1f", gp[k] * 100)});
        table(p, 40, y, new String[]{"Group", "Sum of phi (pp)"}, new double[]{220, 100}, gr);
        footer(p, 1);

        p = doc.newPage();
        header(p, "Feature contributions and method", ds.locShort[l] + " " + utc + " UTC  |  " + model.name());
        y = 86;
        String[] hd = {"Feature", "Value", "Scaled", "Shapley (pp)", "Direction"};
        double[] cw = {160, 90, 70, 80, 110};
        Integer[] rk = e.ranked();
        List<String[]> rows = new ArrayList<>();
        for (int f : rk) rows.add(new String[]{Cfg.prettyFeature(Cfg.FEATURES[f]), Xai.fmt(e.raw()[f]), String.format(Locale.ROOT, "%+.2f", e.scaled()[f]), String.format(Locale.ROOT, "%+.2f", e.phi()[f] * 100),
                Math.abs(e.phi()[f]) < 0.0005 ? "negligible" : e.phi()[f] > 0 ? "raises P(" + Cfg.CLASS_NAMES[e.explainedClass()] + ")" : "lowers P(" + Cfg.CLASS_NAMES[e.explainedClass()] + ")"});
        table(p, 40, y, hd, cw, rows);
        y += 15 * (1 + rows.size()) + 14;
        y = p.paragraph(40, y, 515, 8, false, Palette.GREY,
                "Method: Monte-Carlo Shapley values (permutation sampling, " + 100 + " permutations, 200 training-period background rows) computed directly on the trained DNN weights. "
                        + "The explained quantity is the model's probability of the class named above; the attributions add up exactly to that probability minus its background average. "
                        + "Features describing the grid point (coordinates, land use, distances, densities) are constant per location, so their credit mostly reflects location identity rather than a causal effect. "
                        + "Explanations describe the model's behaviour, not physical causes.", 10.5);
        footer(p, 2);
        doc.save(out);
        return out;
    }

    private static double[] calibrate(UhiClassifier model, Xai.Explanation e) {
        if (!(model instanceof Logits lg)) return e.proba();
        double[] z = lg.logits(e.scaled());
        double t = TEMP_HINT.getOrDefault(model.name(), 1.0);
        for (int i = 0; i < z.length; i++) z[i] /= t;
        UhiClassifier.softmaxInPlace(z);
        return z;
    }
    /** Filled by callers (AnalysisReports.setTemperatures) so reports can show calibrated probabilities. */
    private static final java.util.Map<String, Double> TEMP_HINT = new java.util.HashMap<>();
    public static void setTemperatures(ModelSuite ms) { if (ms.temps != null) for (int i = 0; i < ms.models.length; i++) TEMP_HINT.put(ms.modelNames[i], ms.temps[i]); }

    // ============================================================ drawing helpers

    private static String pct(String s) { double v = Results.num(s); return Double.isNaN(v) ? s : String.format(Locale.ROOT, "%.1f%%", v * 100); }
    private static String f3(String s) { double v = Results.num(s); return Double.isNaN(v) ? s : String.format(Locale.ROOT, "%.2f", v); }

    private static int groupColor(String g) { return g.startsWith("Weather") ? 0x1F77B4 : g.startsWith("Vegetation") ? 0x2CA02C : g.startsWith("Location") ? 0xFF7F0E : 0x9467BD; }

    private static int countRows(List<String[]> rows, String split) { int c = 0; for (String[] r : rows) if (r[1].equals(split)) c++; return c; }

    /** kind per column: 0 = as is, 1 = percentage of a 0-1 value, 2 = one decimal. */
    private static List<String[]> filter(List<String[]> rows, int col, String value, int[] cols, int[] kind) {
        List<String[]> out = new ArrayList<>();
        for (String[] r : rows) {
            if (!r[col].equals(value)) continue;
            String[] o = new String[cols.length];
            for (int i = 0; i < cols.length; i++) {
                String s = r[cols[i]];
                double v = Results.num(s);
                o[i] = kind[i] == 1 && !Double.isNaN(v) ? (cols[i] >= 9 && cols[i] <= 13 || cols[i] == 14 ? String.format(Locale.ROOT, "%.3f", v) : String.format(Locale.ROOT, "%.1f%%", v * 100))
                        : kind[i] == 2 && !Double.isNaN(v) ? String.format(Locale.ROOT, "%.1f", v) : (Double.isNaN(v) || kind[i] == 0 && cols[i] == 0 ? s : String.format(Locale.ROOT, "%.3f", v));
            }
            out.add(o);
        }
        return out;
    }

    private static double[][] arr(List<double[]> l) { return l.toArray(new double[0][]); }

    private static void header(PdfDoc.Page p, String title, String sub) {
        p.rect(0, 0, PdfDoc.W, 66, Palette.NAVY);
        p.rect(0, 66, PdfDoc.W, 3, Palette.TEAL);
        p.text(40, 32, 15, true, 0xFFFFFF, title);
        p.text(40, 51, 8, false, 0xCBD5E1, sub);
    }

    private static void footer(PdfDoc.Page p, int n) {
        p.line(40, 812, 555, 812, 0xE5E7EB, 0.6);
        p.text(40, 826, 7.5, false, Palette.GREY, "Chennai HeatLens   |   statistical model output, not an official warning");
        p.textRight(555, 826, 7.5, false, Palette.GREY, "Page " + n);
    }

    private static void tile(PdfDoc.Page p, double x, double y, double w, double h, String label, String value) {
        p.rect(x, y, w, h, Palette.LIGHT);
        p.rect(x, y, 3, h, Palette.TEAL);
        p.text(x + 12, y + 16, 8, false, Palette.GREY, label);
        p.text(x + 12, y + 34, 14, true, Palette.NAVY, value);
    }

    static void table(PdfDoc.Page p, double x, double y, String[] h, double[] w, List<String[]> rows) {
        double tw = 0;
        for (double d : w) tw += d;
        p.rect(x, y, tw, 15, Palette.NAVY);
        double cx = x;
        for (int i = 0; i < h.length; i++) { p.text(cx + 3, y + 10.5, 7, true, 0xFFFFFF, clip(h[i], w[i] - 4, true)); cx += w[i]; }
        for (int k = 0; k < rows.size(); k++) {
            double ry = y + 15 * (k + 1);
            if (k % 2 == 0) p.rect(x, ry, tw, 15, 0xF9FAFB);
            cx = x;
            for (int i = 0; i < h.length && i < rows.get(k).length; i++) { p.text(cx + 3, ry + 10.5, 7, false, Palette.INK, clip(rows.get(k)[i], w[i] - 4, false)); cx += w[i]; }
        }
    }

    private static String clip(String s, double maxW, boolean bold) {
        while (PdfDoc.width(s, 7, bold) > maxW && s.length() > 2) s = s.substring(0, s.length() - 2);
        return s;
    }

    private static void bars(PdfDoc.Page p, double x, double y, double w, double h, String title, String[] labels, double[] vals, int[] colors, boolean pct) {
        p.text(x, y + 10, 9, true, Palette.NAVY, title);
        double top = y + 26, bottom = y + h - 16, ph = bottom - top, max = 0;
        for (double v : vals) max = Math.max(max, v);
        if (max <= 0) max = 1;
        max *= 1.15;
        p.line(x, bottom, x + w, bottom, 0x9CA3AF, 0.7);
        double slot = w / vals.length, bw = slot * 0.6;
        for (int i = 0; i < vals.length; i++) {
            double bh = vals[i] / max * ph, bx = x + i * slot + (slot - bw) / 2;
            p.rect(bx, bottom - bh, bw, bh, colors[i % colors.length]);
            p.textCenter(bx + bw / 2, bottom - bh - 3, 7, false, Palette.INK, pct ? String.format(Locale.ROOT, "%.0f%%", vals[i] * 100) : String.format(Locale.ROOT, "%.1f", vals[i]));
            p.textCenter(bx + bw / 2, bottom + 11, 7, false, Palette.GREY, labels[i]);
        }
    }

    private static void hbars(PdfDoc.Page p, double x, double y, double w, double h, String title, String[] labels, double[] vals, int[] colors) {
        p.text(x, y + 10, 9, true, Palette.NAVY, title);
        double max = 0;
        for (double v : vals) max = Math.max(max, v);
        if (max <= 0) max = 1;
        double left = x + 140, avail = w - 190;
        for (int i = 0; i < vals.length; i++) {
            double by = y + 22 + i * 15;
            p.textRight(left - 6, by + 9, 7.5, false, Palette.INK, labels[i]);
            p.rect(left, by + 1, vals[i] / max * avail, 10, colors[i]);
            p.text(left + vals[i] / max * avail + 4, by + 9, 7, false, Palette.GREY, String.format(Locale.ROOT, "%.2f", vals[i]));
        }
        double ly = y + 22 + vals.length * 15 + 6;
        String[] gn = {"Weather", "Vegetation / spectral", "Location & land form", "Data-matching metadata"};
        int[] gc = {0x1F77B4, 0x2CA02C, 0xFF7F0E, 0x9467BD};
        double lx = x;
        for (int i = 0; i < 4; i++) { p.rect(lx, ly, 8, 8, gc[i]); p.text(lx + 12, ly + 8, 7, false, Palette.GREY, gn[i]); lx += 12 + PdfDoc.width(gn[i], 7, false) + 18; }
    }

    private static void xyChart(PdfDoc.Page p, double x, double y, double w, double h, String title, double[][][] series, String[] names, int[] colors) {
        p.text(x, y + 10, 9, true, Palette.NAVY, title);
        double left = x + 34, right = x + w - 6, top = y + 22, bottom = y + h - 26;
        double xmin = Double.MAX_VALUE, xmax = -Double.MAX_VALUE, ymin = Double.MAX_VALUE, ymax = -Double.MAX_VALUE;
        for (double[][] s : series) for (double[] pt : s) { xmin = Math.min(xmin, pt[0]); xmax = Math.max(xmax, pt[0]); ymin = Math.min(ymin, pt[1]); ymax = Math.max(ymax, pt[1]); }
        if (xmax - xmin < 1e-9) xmax = xmin + 1;
        if (ymax - ymin < 1e-9) ymax = ymin + 1;
        double pad = (ymax - ymin) * 0.1;
        ymin -= pad; ymax += pad;
        for (int g = 0; g <= 4; g++) {
            double gv = ymin + (ymax - ymin) * g / 4, gy = bottom - (bottom - top) * g / 4;
            p.line(left, gy, right, gy, 0xE5E7EB, 0.5);
            p.textRight(left - 4, gy + 2.5, 7, false, Palette.GREY, String.format(Locale.ROOT, "%.2f", gv));
        }
        for (int k = 0; k < series.length; k++) {
            for (int i = 1; i < series[k].length; i++) {
                double x1 = left + (right - left) * (series[k][i - 1][0] - xmin) / (xmax - xmin), x2 = left + (right - left) * (series[k][i][0] - xmin) / (xmax - xmin);
                double y1 = bottom - (bottom - top) * (series[k][i - 1][1] - ymin) / (ymax - ymin), y2 = bottom - (bottom - top) * (series[k][i][1] - ymin) / (ymax - ymin);
                p.line(x1, y1, x2, y2, colors[k], 1.6);
            }
        }
        p.textCenter(left, bottom + 10, 7, false, Palette.GREY, String.format(Locale.ROOT, "%.0f", xmin));
        p.textCenter(right, bottom + 10, 7, false, Palette.GREY, String.format(Locale.ROOT, "%.0f", xmax));
        double lx = left;
        for (int k = 0; k < names.length; k++) { p.rect(lx, bottom + 15, 8, 4, colors[k]); p.text(lx + 11, bottom + 20, 7, false, Palette.GREY, names[k]); lx += 18 + PdfDoc.width(names[k], 7, false) + 10; }
    }

    private static void waterfall(PdfDoc.Page p, double x, double y, double w, Xai.Explanation e) {
        Integer[] rk = e.ranked();
        int show = 10;
        double rest = 0;
        for (int i = show; i < rk.length; i++) rest += e.phi()[rk[i]];
        int n = show + 1;
        double left = x + 150, avail = w - 200, cum = e.baseline();
        double min = e.baseline(), max = e.baseline(), c = e.baseline();
        for (int i = 0; i < n; i++) { c += i < show ? e.phi()[rk[i]] : rest; min = Math.min(min, c); max = Math.max(max, c); }
        double span = Math.max(1e-6, max - min), lo = min - span * 0.08;
        span *= 1.16;
        p.text(x, y + 9, 7.5, false, Palette.GREY, String.format(Locale.ROOT, "average P = %.0f%%", e.baseline() * 100));
        double sx = left + (e.baseline() - lo) / span * avail;
        for (int i = 0; i < n; i++) {
            double v = i < show ? e.phi()[rk[i]] : rest;
            double by = y + 16 + i * 16;
            String label = i < show ? Cfg.prettyFeature(Cfg.FEATURES[rk[i]]) + " = " + Xai.fmt(e.raw()[rk[i]]) : "other " + (rk.length - show) + " features";
            p.textRight(left - 6, by + 9, 7.5, false, Palette.INK, clip(label, 142, false));
            double x1 = left + (cum - lo) / span * avail, x2 = left + (cum + v - lo) / span * avail;
            p.rect(Math.min(x1, x2), by + 1, Math.max(1.5, Math.abs(x2 - x1)), 11, v >= 0 ? 0xD62828 : 0x2E86C1);
            p.text(Math.max(x1, x2) + 4, by + 9, 7, false, Palette.GREY, String.format(Locale.ROOT, "%+.1f pp", v * 100));
            cum += v;
        }
        p.line(sx, y + 12, sx, y + 16 + n * 16, 0x9CA3AF, 0.6);
        double ex = left + (e.prediction() - lo) / span * avail;
        p.line(ex, y + 12, ex, y + 16 + n * 16, Palette.NAVY, 0.8);
        p.text(Math.min(ex + 3, x + w - 90), y + 16 + n * 16 + 10, 7.5, true, Palette.NAVY, String.format(Locale.ROOT, "prediction P = %.0f%%", e.prediction() * 100));
        p.text(x, y + 16 + n * 16 + 22, 7, false, Palette.GREY, "Red bars raise, blue bars lower the probability of the explained class. pp = percentage points.");
    }

    // ============================================================ CLI: write sample reports

    public static void main(String[] args) throws Exception {
        DataStore ds = new DataStore(Cfg.data());
        ModelSuite ms = ModelSuite.loadOrTrain(ds, System.out::println);
        ms.computePredictions(ds);
        AnalysisRunner.ensure(ds, ms, System.out::println);
        setTemperatures(ms);
        java.nio.file.Files.createDirectories(Cfg.exports());
        System.out.println(modelPerformancePdf(ds, ms, Cfg.exports().resolve("sample_model_performance_report.pdf")));
        int row = -1;
        for (int i = ds.n - 1; i >= 0; i--) if (ds.split[i] == 2 && ds.loc[i] == 3 && ds.cls[i] == 3 && ds.hour[i] == 8) { row = i; break; }
        Xai.Explanation e = Xai.explain(ms.primary, ds, ms.scaler, row, -1, Xai.background(ds, ms.scaler, 200), 100, 7);
        System.out.println(xaiReportPdf(ds, ms, ms.primary, e, Cfg.exports().resolve("sample_xai_report_P4.pdf")));
    }
}
