package org.example;

import ai.djl.Model;
import ai.djl.nn.Block;
import ai.djl.nn.SequentialBlock;
import ai.djl.nn.core.Linear;
import ai.djl.nn.norm.Dropout;
import ai.djl.nn.Activation;

public class UHIModel {

    public static void main(String[] args) throws Exception {

        System.out.println("======================================");
        System.out.println("UHI DEEP LEARNING MODEL");
        System.out.println("======================================");

        // Create the neural network
        Block network = new SequentialBlock()
                .add(Linear.builder()
                        .setUnits(128)
                        .build())
                .add(Activation::relu)
                .add(Dropout.builder()
                        .optRate(0.30f)
                        .build())

                .add(Linear.builder()
                        .setUnits(64)
                        .build())
                .add(Activation::relu)
                .add(Dropout.builder()
                        .optRate(0.20f)
                        .build())

                .add(Linear.builder()
                        .setUnits(32)
                        .build())
                .add(Activation::relu)

                .add(Linear.builder()
                        .setUnits(4)
                        .build());

        // Create DJL model
        try (Model model = Model.newInstance("UHI-DNN")) {

            model.setBlock(network);

            System.out.println();
            System.out.println("Model created successfully!");
            System.out.println();
            System.out.println("Input features : 28");
            System.out.println("Hidden layer 1 : 128 neurons");
            System.out.println("Hidden layer 2 : 64 neurons");
            System.out.println("Hidden layer 3 : 32 neurons");
            System.out.println("Output classes  : 4");
            System.out.println("Dropout 1       : 30%");
            System.out.println("Dropout 2       : 20%");
            System.out.println();
            System.out.println("Classes:");
            System.out.println("0 = Low");
            System.out.println("1 = Moderate");
            System.out.println("2 = High");
            System.out.println("3 = Extreme");
            System.out.println();
            System.out.println("======================================");
            System.out.println("MODEL ARCHITECTURE CHECK PASSED!");
            System.out.println("======================================");
        }
    }
}