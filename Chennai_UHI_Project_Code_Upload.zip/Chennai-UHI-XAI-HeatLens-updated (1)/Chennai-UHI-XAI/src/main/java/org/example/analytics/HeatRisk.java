package org.example.analytics;

/**
 * Heat-stress layer. Combines air temperature and humidity (NWS/Rothfusz heat index)
 * with the local UHI amplification (UHI anomaly, degC) into a 5-level warning scale.
 */
public final class HeatRisk {
    private HeatRisk() {}

    public static final String[] LEVELS = {"Normal", "Caution", "Extreme Caution", "Danger", "Extreme Danger"};
    /** Adjusted heat-index cut-offs in degC (NWS bands: 80F, 90F->32.2C, 103F->39.4C, 125F->51.7C). */
    public static final double[] CUT = {26.7, 32.2, 39.4, 51.1};

    public static final String[] ADVICE = {
            "Normal conditions. Routine outdoor activity is fine; keep drinking water handy.",
            "Fatigue is possible with prolonged exposure. Hydrate regularly and take shade breaks.",
            "Heat cramps and exhaustion are possible. Limit strenuous outdoor work and take hourly breaks.",
            "Heat exhaustion likely, heat stroke possible. Avoid outdoor work 11:00-16:00, protect children, "
                    + "the elderly and outdoor workers, and open cooling shelters.",
            "Heat stroke highly likely. Suspend non-essential outdoor activity, activate cooling centres and public alerts."
    };

    /** NWS heat index in degC from air temperature (degC) and relative humidity (%). */
    public static double heatIndexC(double tC, double rh) {
        double t = tC * 9.0 / 5.0 + 32.0;
        double hi = 0.5 * (t + 61.0 + (t - 68.0) * 1.2 + rh * 0.094);
        if ((hi + t) / 2.0 >= 80.0) {
            hi = -42.379 + 2.04901523 * t + 10.14333127 * rh - 0.22475541 * t * rh
                    - 0.00683783 * t * t - 0.05481717 * rh * rh + 0.00122874 * t * t * rh
                    + 0.00085282 * t * rh * rh - 0.00000199 * t * t * rh * rh;
            if (rh < 13 && t >= 80 && t <= 112) {
                hi -= ((13 - rh) / 4.0) * Math.sqrt((17 - Math.abs(t - 95.0)) / 17.0);
            } else if (rh > 85 && t >= 80 && t <= 87) {
                hi += ((rh - 85) / 10.0) * ((87 - t) / 5.0);
            }
        }
        return (hi - 32.0) * 5.0 / 9.0;
    }

    /** Heat index plus the UHI anomaly (local amplification, degC). */
    public static double adjusted(double tC, double rh, double uhiAnomalyC) {
        return heatIndexC(tC, rh) + uhiAnomalyC;
    }

    public static int level(double adjustedHiC) {
        int l = 0;
        for (double c : CUT) if (adjustedHiC >= c) l++;
        return l;
    }
}
