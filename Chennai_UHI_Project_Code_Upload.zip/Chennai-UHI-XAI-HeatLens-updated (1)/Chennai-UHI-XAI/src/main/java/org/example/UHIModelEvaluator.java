package org.example;

import ai.djl.Model;
import ai.djl.inference.Predictor;
import ai.djl.ndarray.NDArray;
import ai.djl.ndarray.NDList;
import ai.djl.translate.Batchifier;
import ai.djl.translate.Translator;
import ai.djl.translate.TranslatorContext;

import ai.djl.nn.Block;
import ai.djl.nn.SequentialBlock;
import ai.djl.nn.core.Linear;
import ai.djl.nn.norm.Dropout;
import ai.djl.nn.Activation;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.io.input.BOMInputStream;

import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class UHIModelEvaluator {

    private static final int NUM_FEATURES = 28;
    private static final int NUM_CLASSES = 4;

    private static final String TEST_FILE =
            "data/processed/test_scaled.csv";

    private static final String MODEL_DIR =
            "models";

    private static final String[] FEATURES = {
            "latitude",
            "longitude",
            "air_temperature",
            "dew_point_temperature",
            "cloud_cover",
            "u10",
            "v10",
            "wind_speed",
            "wind_direction",
            "relative_humidity",
            "pressure",
            "rainfall",
            "red_band",
            "nir_band",
            "ndvi",
            "ndbi",
            "ndwi",
            "land_use_type",
            "elevation",
            "distance_to_coast",
            "distance_to_green_space",
            "distance_to_road",
            "distance_to_water",
            "building_density",
            "road_density",
            "spatial_match_distance_km",
            "dynamic_nearest_distance_km",
            "landsat_temporal_gap_days"
    };

    public static void main(String[] args) throws Exception {

        System.out.println("======================================");
        System.out.println("UHI MODEL EVALUATION");
        System.out.println("======================================");

        System.out.println();
        System.out.println("Test file: " + TEST_FILE);
        System.out.println("Model: " + MODEL_DIR);

        List<float[]> features = new ArrayList<>();
        List<Integer> actualClasses = new ArrayList<>();

        System.out.println();
        System.out.println("Loading test data...");

        BOMInputStream inputStream =
                BOMInputStream.builder()
                        .setPath(Path.of(TEST_FILE))
                        .get();

        Reader reader =
                new InputStreamReader(
                        inputStream,
                        StandardCharsets.UTF_8
                );

        try (
                CSVParser parser =
                        CSVFormat.DEFAULT
                                .builder()
                                .setHeader()
                                .setSkipHeaderRecord(true)
                                .get()
                                .parse(reader)
        ) {

            for (CSVRecord record : parser) {

                float[] row = new float[NUM_FEATURES];

                for (int i = 0; i < NUM_FEATURES; i++) {

                    row[i] =
                            Float.parseFloat(
                                    record.get(FEATURES[i])
                            );
                }

                String className =
                        record.get("UHI_Class");

                int target;

                switch (className) {
                    case "Low":
                        target = 0;
                        break;

                    case "Moderate":
                        target = 1;
                        break;

                    case "High":
                        target = 2;
                        break;

                    case "Extreme":
                        target = 3;
                        break;

                    default:
                        throw new IllegalArgumentException(
                                "Unknown UHI class: " + className
                        );
                }

                features.add(row);
                actualClasses.add(target);
            }
        }

        System.out.println(
                "Test rows: " + features.size()
        );

        System.out.println();
        System.out.println("Loading trained model...");

        try (Model model = Model.newInstance("uhi-dnn")) {

            Block network =
                    new SequentialBlock()
                            .add(
                                    Linear.builder()
                                            .setUnits(128)
                                            .build()
                            )
                            .add(Activation::relu)
                            .add(
                                    Dropout.builder()
                                            .optRate(0.30f)
                                            .build()
                            )
                            .add(
                                    Linear.builder()
                                            .setUnits(64)
                                            .build()
                            )
                            .add(Activation::relu)
                            .add(
                                    Dropout.builder()
                                            .optRate(0.20f)
                                            .build()
                            )
                            .add(
                                    Linear.builder()
                                            .setUnits(32)
                                            .build()
                            )
                            .add(Activation::relu)
                            .add(
                                    Linear.builder()
                                            .setUnits(4)
                                            .build()
                            );

            model.setBlock(network);

            model.load(Path.of(MODEL_DIR));

            try (
                    Predictor<float[], float[]> predictor =
                            model.newPredictor(
                                    new UHITranslator()
                            )
            ) {

                int[][] confusionMatrix =
                        new int[NUM_CLASSES][NUM_CLASSES];

                int correct = 0;

                for (int i = 0; i < features.size(); i++) {

                    float[] probabilities =
                            predictor.predict(
                                    features.get(i)
                            );

                    int predicted =
                            argMax(probabilities);

                    int actual =
                            actualClasses.get(i);

                    confusionMatrix[actual][predicted]++;

                    if (predicted == actual) {
                        correct++;
                    }
                }

                double accuracy =
                        (double) correct / features.size();

                System.out.println();
                System.out.println(
                        "Accuracy: " + accuracy
                );

                System.out.println();
                System.out.println("Confusion Matrix");
                System.out.println(
                        "Actual \\ Predicted"
                );

                System.out.println(
                        "             Low  Moderate  High  Extreme"
                );

                String[] names = {
                        "Low",
                        "Moderate",
                        "High",
                        "Extreme"
                };

                for (int i = 0; i < NUM_CLASSES; i++) {

                    System.out.printf(
                            "%-10s %5d %9d %6d %9d%n",
                            names[i],
                            confusionMatrix[i][0],
                            confusionMatrix[i][1],
                            confusionMatrix[i][2],
                            confusionMatrix[i][3]
                    );
                }

                System.out.println();
                System.out.println(
                        "======================================"
                );
                System.out.println(
                        "EVALUATION COMPLETED!"
                );
                System.out.println(
                        "======================================"
                );
            }
        }
    }

    private static int argMax(float[] values) {

        int index = 0;

        for (int i = 1; i < values.length; i++) {

            if (values[i] > values[index]) {
                index = i;
            }
        }

        return index;
    }

    private static class UHITranslator
            implements Translator<float[], float[]> {

        @Override
        public NDList processInput(
                TranslatorContext ctx,
                float[] input
        ) {

            NDArray array =
                    ctx.getNDManager()
                            .create(input);

            return new NDList(array);
        }

        @Override
        public float[] processOutput(
                TranslatorContext ctx,
                NDList list
        ) {

            return list.singletonOrThrow()
                    .toFloatArray();
        }

        @Override
        public Batchifier getBatchifier() {
            return null;
        }
    }
}