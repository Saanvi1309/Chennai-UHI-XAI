package org.example.analytics;

/** Confusion-matrix based classification metrics. */
public final class Metrics {
    public final int k;
    public final int[][] cm;
    public final long n;
    public final long correct;
    public double logLoss = Double.NaN;

    public Metrics(int[][] cm) {
        this.k = cm.length;
        this.cm = cm;
        long t = 0, c = 0;
        for (int i = 0; i < k; i++) for (int j = 0; j < k; j++) { t += cm[i][j]; if (i == j) c += cm[i][j]; }
        this.n = t;
        this.correct = c;
    }

    public static Metrics of(int[] actual, int[] predicted, int k) {
        int[][] cm = new int[k][k];
        for (int i = 0; i < actual.length; i++) cm[actual[i]][predicted[i]]++;
        return new Metrics(cm);
    }

    public double accuracy() { return n == 0 ? Double.NaN : (double) correct / n; }

    public double precision(int c) {
        long tp = cm[c][c], col = 0;
        for (int r = 0; r < k; r++) col += cm[r][c];
        return col == 0 ? 0 : (double) tp / col;
    }

    public double recall(int c) {
        long tp = cm[c][c], row = 0;
        for (int j = 0; j < k; j++) row += cm[c][j];
        return row == 0 ? 0 : (double) tp / row;
    }

    public double f1(int c) {
        double p = precision(c), r = recall(c);
        return p + r == 0 ? 0 : 2 * p * r / (p + r);
    }

    public double macroF1() {
        double s = 0;
        for (int c = 0; c < k; c++) s += f1(c);
        return s / k;
    }

    /** Share of predictions that are right or only one ordinal class away. */
    public double adjacentAccuracy() {
        long ok = 0;
        for (int i = 0; i < k; i++) for (int j = 0; j < k; j++) if (Math.abs(i - j) <= 1) ok += cm[i][j];
        return n == 0 ? Double.NaN : (double) ok / n;
    }
}
