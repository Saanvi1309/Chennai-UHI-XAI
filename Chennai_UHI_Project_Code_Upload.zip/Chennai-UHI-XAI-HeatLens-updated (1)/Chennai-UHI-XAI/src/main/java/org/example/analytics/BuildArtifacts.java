package org.example.analytics;

import java.nio.file.Files;

/**
 * One-shot command line tool: loads the data, trains/loads every model, and writes
 * models/*.bin + results/*.csv. Run it once (the dashboard also does this automatically if files are missing).
 * Delete models/gb_uhi.bin, lr_uhi.bin, forecast_gb.bin to force retraining.
 */
public final class BuildArtifacts {
    public static void main(String[] args) throws Exception {
        long t0 = System.currentTimeMillis();
        System.out.println("Project root: " + Cfg.root());
        DataStore ds = new DataStore(Cfg.data());
        System.out.println("Loaded " + ds.n + " rows (" + ds.nLoc + " grid points, " + ds.nHours + " hours)");
        ModelSuite s = ModelSuite.loadOrTrain(ds, System.out::println);
        s.computePredictions(ds);
        Files.createDirectories(Cfg.results());
        s.writeResults(ds, Cfg.results());
        int[] all = new int[ds.n];
        for (int i = 0; i < ds.n; i++) all[i] = i;
        System.out.println("\nTest-set comparison:");
        for (ModelSuite.Row r : s.compare(ds, all, false, true))
            System.out.printf("  %-22s acc %.3f  macro-F1 %.3f  +/-1 class %.3f  log-loss %.3f%n", r.name(), r.accuracy(), r.macroF1(), r.adjacentAccuracy(), r.logLoss());
        System.out.println("\nForecast (test) accuracy by horizon:");
        ForecastModel.Eval e = s.forecast.testEval;
        for (int i = 0; i < e.horizons.length; i++)
            System.out.printf("  +%2dh  model %.3f | same-hour-yesterday %.3f | climatology %.3f%n", e.horizons[i], e.acc[i], e.yesterdayAcc[i], e.climAcc[i]);
        System.out.println("\nDone in " + (System.currentTimeMillis() - t0) / 1000 + " s. Files in models/ and results/.");
    }
}
