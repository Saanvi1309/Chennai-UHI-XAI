package org.example.dashboard;

import javafx.application.Platform;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import org.example.analytics.*;

import java.util.Locale;

/**
 * Geographic satellite map (Esri World Imagery tiles, web-mercator) of the six grid points, drawn at their true
 * latitude / longitude and coloured by mean UHI anomaly or heat risk. Scroll to zoom, drag to pan, buttons for
 * zoom / reset / place-name labels. Tiles are cached on disk, so the map works offline after the first view.
 */
final class MapCanvas extends Canvas {
    private static final double TILE = 256;
    private static final double MIN_Z = 5, MAX_Z = 16;

    private final AppState st;
    private final Tooltip tip = new Tooltip();
    private final boolean byRisk;
    private final double prefW, prefH;
    private double[] px, py;

    // view state: centre in normalised web-mercator world coordinates (0..1), fractional zoom level
    private double cx = 0.5, cy = 0.5, zoom = 9;
    private boolean fitted, userMoved, labels = true, drawPending;
    private double dragX, dragY, pressX, pressY;
    private boolean dragged;
    private final double[] btnX = new double[4];
    private final double[] btnW = {28, 28, 56, 74};
    private double btnY = 8, btnH = 26;

    MapCanvas(AppState st, double w, double h, boolean byRisk) {
        super(w, h);
        this.st = st;
        this.byRisk = byRisk;
        this.prefW = w;
        this.prefH = h;
        Tooltip.install(this, tip);
        tip.setShowDelay(javafx.util.Duration.millis(80));
        setOnMouseMoved(e -> {
            tip.setText("");
            if (px == null || st.stats == null) return;
            for (int l = 0; l < px.length; l++) if (Math.hypot(e.getX() - px[l], e.getY() - py[l]) < 24) tip.setText(describe(l));
        });
        setOnMousePressed(e -> { dragX = pressX = e.getX(); dragY = pressY = e.getY(); dragged = false; });
        setOnMouseDragged(e -> {
            if (Math.hypot(e.getX() - pressX, e.getY() - pressY) > 4) dragged = true;
            if (!dragged) return;
            double s = scale();
            cx -= (e.getX() - dragX) / s;
            cy -= (e.getY() - dragY) / s;
            clampCentre();
            dragX = e.getX(); dragY = e.getY();
            userMoved = true;
            tip.setText("");
            draw();
        });
        setOnMouseReleased(e -> {
            if (dragged) return;
            for (int i = 0; i < 4; i++) {
                if (e.getX() >= btnX[i] && e.getX() <= btnX[i] + btnW[i] && e.getY() >= btnY && e.getY() <= btnY + btnH) { press(i); return; }
            }
        });
        setOnScroll(e -> {
            if (e.getDeltaY() == 0) return;
            zoomAt(e.getX(), e.getY(), zoom + (e.getDeltaY() > 0 ? 0.5 : -0.5));
            e.consume();
        });
        st.dark.addListener((o, a, b) -> draw());
        widthProperty().addListener((o, a, b) -> draw());
        heightProperty().addListener((o, a, b) -> draw());
    }

    // ---- let the canvas follow the size of its card ----
    @Override public boolean isResizable() { return true; }
    @Override public double minWidth(double h) { return 280; }
    @Override public double minHeight(double w) { return 240; }
    @Override public double prefWidth(double h) { return prefW; }
    @Override public double prefHeight(double w) { return prefH; }
    @Override public double maxWidth(double h) { return Double.MAX_VALUE; }
    @Override public double maxHeight(double w) { return 560; }
    @Override public void resize(double w, double h) {
        if (w > 1 && h > 1 && (w != getWidth() || h != getHeight())) { setWidth(w); setHeight(h); }
    }

    // ---- projection ----
    private static double wx(double lon) { return (lon + 180.0) / 360.0; }
    private static double wy(double lat) {
        double r = Math.toRadians(Math.max(-85, Math.min(85, lat)));
        return (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2;
    }
    private double scale() { return TILE * Math.pow(2, zoom); }
    private double sx(double worldX) { return getWidth() / 2 + (worldX - cx) * scale(); }
    private double sy(double worldY) { return getHeight() / 2 + (worldY - cy) * scale(); }

    private void clampCentre() {
        cx = Math.max(0, Math.min(1, cx));
        cy = Math.max(0.02, Math.min(0.98, cy));
    }

    private void zoomAt(double mx, double my, double newZ) {
        newZ = Math.max(MIN_Z, Math.min(MAX_Z, newZ));
        double s = scale();
        double wxc = cx + (mx - getWidth() / 2) / s, wyc = cy + (my - getHeight() / 2) / s;
        zoom = newZ;
        double s2 = scale();
        cx = wxc - (mx - getWidth() / 2) / s2;
        cy = wyc - (my - getHeight() / 2) / s2;
        clampCentre();
        userMoved = true;
        draw();
    }

    private void press(int i) {
        switch (i) {
            case 0 -> zoomAt(getWidth() / 2, getHeight() / 2, zoom + 0.5);
            case 1 -> zoomAt(getWidth() / 2, getHeight() / 2, zoom - 0.5);
            case 2 -> { userMoved = false; fitted = false; draw(); }
            default -> { labels = !labels; draw(); }
        }
    }

    /** Frames all grid points with some padding. */
    private void fit() {
        DataStore ds = st.ds;
        double minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
        for (int l = 0; l < ds.nLoc; l++) {
            minX = Math.min(minX, wx(ds.locLon[l])); maxX = Math.max(maxX, wx(ds.locLon[l]));
            minY = Math.min(minY, wy(ds.locLat[l])); maxY = Math.max(maxY, wy(ds.locLat[l]));
        }
        cx = (minX + maxX) / 2;
        cy = (minY + maxY) / 2;
        double padX = 95, padY = 85;
        double availW = Math.max(60, getWidth() - 2 * padX), availH = Math.max(60, getHeight() - 2 * padY);
        double zx = Math.log(availW / (TILE * Math.max(1e-9, maxX - minX))) / Math.log(2);
        double zy = Math.log(availH / (TILE * Math.max(1e-9, maxY - minY))) / Math.log(2);
        zoom = Math.max(MIN_Z, Math.min(MAX_Z - 3, Math.min(zx, zy)));
        fitted = true;
    }

    private String describe(int l) {
        ViewStats v = st.stats;
        DataStore ds = st.ds;
        return String.format(Locale.ROOT, "%s (%s)%nLat %.2f, Lon %.2f%nHours: %d%nMean UHI anomaly: %+.2f \u00B0C%nExtreme UHI share: %.0f%%%nDanger or worse: %.0f%%%nMean adjusted heat index: %.1f \u00B0C",
                ds.locShort[l], Cfg.areaHint(ds.locLat[l], ds.locLon[l]), ds.locLat[l], ds.locLon[l], v.locN[l], v.locMeanAnom[l], v.locExtremeShare[l] * 100, v.locDangerShare[l] * 100, v.locMeanAdjHi[l]);
    }

    private void redrawSoon() {
        if (drawPending) return;
        drawPending = true;
        Platform.runLater(() -> { drawPending = false; draw(); });
    }

    // ---- drawing ----
    private void drawTiles(GraphicsContext g, String layer, double alpha) {
        double W = getWidth(), H = getHeight(), s = scale();
        int zt = (int) Math.max(0, Math.min(17, Math.round(zoom)));
        int n = 1 << zt;
        double x0 = cx - W / 2 / s, x1 = cx + W / 2 / s, y0 = cy - H / 2 / s, y1 = cy + H / 2 / s;
        int tx0 = (int) Math.floor(x0 * n), tx1 = (int) Math.floor(x1 * n);
        int ty0 = Math.max(0, (int) Math.floor(y0 * n)), ty1 = Math.min(n - 1, (int) Math.floor(y1 * n));
        double ts = s / n;
        g.setGlobalAlpha(alpha);
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) {
                int wrapX = ((tx % n) + n) % n;
                double dx = W / 2 + ((double) tx / n - cx) * s, dy = H / 2 + ((double) ty / n - cy) * s;
                Image img = SatelliteTiles.get(layer, zt, wrapX, ty, this::redrawSoon);
                if (img != null) {
                    g.drawImage(img, dx, dy, ts + 0.6, ts + 0.6);
                } else if (SatelliteTiles.SATELLITE.equals(layer)) {
                    // show a blurred parent tile while the real one loads
                    for (int up = 1; up <= 3 && zt - up >= 0; up++) {
                        int f = 1 << up;
                        Image par = SatelliteTiles.peek(layer, zt - up, wrapX / f, ty / f);
                        if (par != null) {
                            double sw = par.getWidth() / f, sh = par.getHeight() / f;
                            g.drawImage(par, (wrapX % f) * sw, (ty % f) * sh, sw, sh, dx, dy, ts + 0.6, ts + 0.6);
                            break;
                        }
                    }
                }
            }
        }
        g.setGlobalAlpha(1);
    }

    private void halo(GraphicsContext g, String text, double x, double y, Color fill) {
        g.setLineWidth(3);
        g.setStroke(Color.rgb(0, 0, 0, 0.8));
        g.strokeText(text, x, y);
        g.setFill(fill);
        g.fillText(text, x, y);
    }

    private void button(GraphicsContext g, int i, String text) {
        g.setFill(Color.rgb(17, 24, 39, 0.82));
        g.fillRoundRect(btnX[i], btnY, btnW[i], btnH, 8, 8);
        g.setStroke(Color.rgb(255, 255, 255, 0.35));
        g.setLineWidth(1);
        g.strokeRoundRect(btnX[i], btnY, btnW[i], btnH, 8, 8);
        g.setFill(Color.WHITE);
        g.setFont(Font.font("System", FontWeight.BOLD, 12));
        g.setTextAlign(TextAlignment.CENTER);
        g.fillText(text, btnX[i] + btnW[i] / 2, btnY + 17);
    }

    void draw() {
        GraphicsContext g = getGraphicsContext2D();
        double W = getWidth(), H = getHeight();
        if (W < 20 || H < 20) return;
        DataStore ds = st.ds;
        ViewStats v = st.stats;
        if (!fitted || !userMoved) fit();

        g.clearRect(0, 0, W, H);
        g.setFill(Color.web("#1B2433"));
        g.fillRect(0, 0, W, H);
        g.save();
        g.beginPath();
        g.rect(0, 0, W, H);
        g.clip();
        drawTiles(g, SatelliteTiles.SATELLITE, 1.0);
        if (labels) drawTiles(g, SatelliteTiles.LABELS, 0.95);

        if (SatelliteTiles.looksOffline()) {
            g.setFill(Color.web("#E5E7EB"));
            g.setFont(Font.font(11));
            g.setTextAlign(TextAlignment.CENTER);
            g.fillText("Satellite imagery could not be loaded (no internet?). Markers are still placed at their true coordinates.", W / 2, H / 2 + 4);
        }

        double mx = 0;
        if (v != null) for (int l = 0; l < ds.nLoc; l++) if (v.locN[l] > 0) mx = Math.max(mx, Math.abs(v.locMeanAnom[l]));
        px = new double[ds.nLoc];
        py = new double[ds.nLoc];
        for (int l = 0; l < ds.nLoc; l++) {
            px[l] = sx(wx(ds.locLon[l]));
            py[l] = sy(wy(ds.locLat[l]));
            boolean on = v != null && v.locN[l] > 0;
            int col = 0x9CA3AF;
            double r = 14;
            if (on) {
                if (byRisk) {
                    col = Palette.RISK[HeatRisk.level(v.locMeanAdjHi[l])];
                    r = 12 + 22 * Math.min(1, v.locDangerShare[l] * 2);
                } else {
                    col = Palette.diverging(v.locMeanAnom[l], Math.max(0.3, mx));
                    if (Math.abs(v.locMeanAnom[l]) < 0.04) col = 0xE5E7EB;
                    r = 12 + 26 * Math.min(1, v.locExtremeShare[l] * 1.6);
                }
            }
            Color c = Ui.color(col);
            g.setFill(Color.color(c.getRed(), c.getGreen(), c.getBlue(), 0.82));
            g.fillOval(px[l] - r, py[l] - r, 2 * r, 2 * r);
            g.setStroke(Color.WHITE);
            g.setLineWidth(2);
            g.strokeOval(px[l] - r, py[l] - r, 2 * r, 2 * r);
            g.setTextAlign(TextAlignment.CENTER);
            g.setFont(Font.font("System", FontWeight.BOLD, 11));
            g.setFill(Color.web("#111827"));
            g.fillText(ds.locShort[l], px[l], py[l] + 4);
            g.setFont(Font.font("System", FontWeight.BOLD, 10));
            String val = on ? (byRisk ? String.format(Locale.ROOT, "%.0f\u00B0C", v.locMeanAdjHi[l]) : String.format(Locale.ROOT, "%+.2f\u00B0C", v.locMeanAnom[l])) : "no data";
            halo(g, val, px[l], py[l] + r + 13, Color.WHITE);
            halo(g, Cfg.areaHint(ds.locLat[l], ds.locLon[l]), px[l], py[l] - r - 5, Color.web("#FDE68A"));
        }

        // legend strip + attribution
        String legend = byRisk ? "Colour = heat-risk level of mean adjusted heat index; size = share of Danger+ hours"
                : "Colour: red = warmer than median point, blue = cooler; size = share of Extreme hours";
        g.setFont(Font.font(10));
        g.setTextAlign(TextAlignment.LEFT);
        g.setFill(Color.rgb(17, 24, 39, 0.78));
        g.fillRect(0, H - 34, W, 34);
        g.setFill(Color.web("#E5E7EB"));
        g.fillText(legend, 8, H - 20);
        g.setFill(Color.web("#9CA3AF"));
        g.setFont(Font.font(9));
        g.fillText("Imagery \u00A9 Esri, Maxar, Earthstar Geographics, GIS User Community  |  scroll = zoom, drag = pan", 8, H - 7);

        // controls (top-right)
        double x = W - 8;
        for (int i = 3; i >= 0; i--) { x -= btnW[i]; btnX[i] = x; x -= 6; }
        button(g, 0, "+");
        button(g, 1, "\u2212");
        button(g, 2, "Reset");
        button(g, 3, labels ? "Labels \u2713" : "Labels");
        g.restore();
    }
}
