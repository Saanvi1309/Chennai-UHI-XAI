package org.example.analytics;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Pure-Java inference for the DJL network trained by UHITrainer (28-128-64-32-4, ReLU).
 * It reads the weights straight from models/uhi-dnn-NNNN.params, so the dashboard does not need
 * the PyTorch native runtime. Dropout layers are identity at inference time.
 */
public final class DnnModel implements UhiClassifier, Logits {
    private final float[][][] w = new float[4][][];
    private final float[][] b = new float[4][];
    public final Path source;

    private DnnModel(Path source) { this.source = source; }

    @Override public String name() { return "DNN"; }

    /** Loads the highest-numbered uhi-dnn-NNNN.params file in the given folder. */
    public static DnnModel load(Path modelsDir) throws IOException {
        Pattern p = Pattern.compile("uhi-dnn-(\\d{4})\\.params");
        Path best = null; int bestEpoch = -1;
        try (Stream<Path> s = Files.list(modelsDir)) {
            for (Path f : (Iterable<Path>) s::iterator) {
                Matcher m = p.matcher(f.getFileName().toString());
                if (m.matches() && Integer.parseInt(m.group(1)) > bestEpoch) {
                    bestEpoch = Integer.parseInt(m.group(1)); best = f;
                }
            }
        }
        if (best == null) throw new IOException("No uhi-dnn-NNNN.params found in " + modelsDir);
        DnnModel m = new DnnModel(best);
        m.parse(Files.readAllBytes(best));
        return m;
    }

    private void parse(byte[] raw) throws IOException {
        ByteBuffer bb = ByteBuffer.wrap(raw).order(ByteOrder.BIG_ENDIAN);
        byte[] magic = "NDAR".getBytes(StandardCharsets.US_ASCII);
        List<float[]> data = new ArrayList<>();
        List<long[]> shapes = new ArrayList<>();
        int pos = 0;
        while (true) {
            int at = indexOf(raw, magic, pos);
            if (at < 0) break;
            bb.position(at + 4);
            bb.getInt();                 // record version
            bb.get();                    // flag
            utf(bb); utf(bb); String dtype = utf(bb);   // name, format, dtype
            if (!"FLOAT32".equals(dtype)) throw new IOException("Unsupported dtype " + dtype);
            int ndim = bb.getInt();
            long[] dims = new long[ndim];
            long cnt = 1;
            for (int i = 0; i < ndim; i++) { dims[i] = bb.getLong(); cnt *= dims[i]; }
            int layoutLen = bb.getInt();
            bb.position(bb.position() + 2 * layoutLen);
            bb.get();                    // marker byte
            int byteLen = bb.getInt();
            if (byteLen != cnt * 4) throw new IOException("Unexpected tensor size in " + source);
            ByteBuffer le = ByteBuffer.wrap(raw, bb.position(), byteLen).order(ByteOrder.LITTLE_ENDIAN);
            float[] arr = new float[(int) cnt];
            for (int i = 0; i < cnt; i++) arr[i] = le.getFloat();
            data.add(arr); shapes.add(dims);
            pos = bb.position() + byteLen;
        }
        if (data.size() != 8) throw new IOException("Expected 8 tensors (4 Linear layers), found " + data.size());
        for (int l = 0; l < 4; l++) {
            long[] ws = shapes.get(2 * l);
            int out = (int) ws[0], in = (int) ws[1];
            float[] flat = data.get(2 * l);
            w[l] = new float[out][in];
            for (int o = 0; o < out; o++) System.arraycopy(flat, o * in, w[l][o], 0, in);
            b[l] = data.get(2 * l + 1);
        }
    }

    private static String utf(ByteBuffer bb) {
        int len = bb.getShort() & 0xFFFF;
        byte[] s = new byte[len];
        bb.get(s);
        return new String(s, StandardCharsets.UTF_8);
    }

    private static int indexOf(byte[] a, byte[] pat, int from) {
        outer:
        for (int i = from; i <= a.length - pat.length; i++) {
            for (int j = 0; j < pat.length; j++) if (a[i + j] != pat[j]) continue outer;
            return i;
        }
        return -1;
    }

    /** Raw (pre-softmax) outputs of the final layer. */
    @Override public double[] logits(double[] x) {
        float[] cur = new float[x.length];
        for (int i = 0; i < x.length; i++) cur[i] = (float) x[i];
        for (int l = 0; l < 4; l++) {
            float[] next = new float[w[l].length];
            for (int o = 0; o < next.length; o++) {
                float s = b[l][o];
                float[] row = w[l][o];
                for (int i = 0; i < row.length; i++) s += row[i] * cur[i];
                next[o] = (l < 3 && s < 0) ? 0f : s;
            }
            cur = next;
        }
        double[] z = new double[cur.length];
        for (int i = 0; i < z.length; i++) z[i] = cur[i];
        return z;
    }

    @Override public double[] predictProba(double[] x) {
        double[] z = logits(x);
        UhiClassifier.softmaxInPlace(z);
        return z;
    }
}
