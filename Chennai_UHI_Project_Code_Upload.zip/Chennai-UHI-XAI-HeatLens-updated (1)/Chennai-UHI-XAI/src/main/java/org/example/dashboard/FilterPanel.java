package org.example.dashboard;

import javafx.animation.PauseTransition;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.util.Duration;
import javafx.util.StringConverter;
import org.example.analytics.*;

import java.time.LocalDate;

/** Left sidebar with every global filter. Changes are debounced and pushed into AppState.refresh(). */
final class FilterPanel extends ScrollPane {
    private final AppState st;
    private final DatePicker from = new DatePicker(), to = new DatePicker();
    private final ComboBox<Integer> hFrom = new ComboBox<>(), hTo = new ComboBox<>();
    private final CheckBox[] loc = new CheckBox[6], cls = new CheckBox[Cfg.NC], risk = new CheckBox[5];
    private final ToggleButton[] mon = new ToggleButton[12];
    private final Label count = new Label();
    private final PauseTransition debounce = new PauseTransition(Duration.millis(140));
    private boolean muted;

    FilterPanel(AppState st) {
        this.st = st;
        DataStore ds = st.ds;
        LocalDate min = ds.time(0).toLocalDate(), max = ds.time(ds.nHours - 1).toLocalDate();
        from.setValue(min); to.setValue(max);
        for (DatePicker d : new DatePicker[]{from, to}) {
            d.setEditable(false);
            d.setDayCellFactory(p -> new DateCell() { @Override public void updateItem(LocalDate x, boolean e) { super.updateItem(x, e); setDisable(e || x.isBefore(min) || x.isAfter(max)); } });
            d.setMaxWidth(Double.MAX_VALUE);
            d.valueProperty().addListener((o, a, b) -> push());
        }
        StringConverter<Integer> conv = new StringConverter<>() {
            @Override public String toString(Integer i) { return i == null ? "" : Cfg.hourLabel(Cfg.hourAt(i)) + " IST"; }
            @Override public Integer fromString(String s) { return 0; }
        };
        for (ComboBox<Integer> c : java.util.List.of(hFrom, hTo)) {
            for (int i = 0; i < 24; i++) c.getItems().add(i);
            c.setConverter(conv); c.setMaxWidth(Double.MAX_VALUE);
            c.valueProperty().addListener((o, a, b) -> push());
        }
        hFrom.setValue(0); hTo.setValue(23);

        VBox box = new VBox(6);
        box.setPadding(new Insets(14));
        box.setPrefWidth(240);
        box.setMinWidth(0);
        box.setMaxWidth(Double.MAX_VALUE);
        Button reset = new Button("Reset");
        reset.getStyleClass().add("ghost-button");
        reset.setOnAction(e -> reset());
        HBox title = new HBox(new Label("Filters") {{ getStyleClass().add("side-title"); }}, spacer(), reset);
        box.getChildren().add(title);

        box.getChildren().add(Ui.label("QUICK RANGES", "side-h"));
        FlowPane presets = new FlowPane(6, 6);
        presets.getChildren().addAll(
                chip("All data", this::reset),
                chip("Test period", () -> setDates(LocalDate.of(2025, 7, 1), max)),
                chip("Hot season (Apr-Jun)", () -> { allMonths(false); for (int m = 3; m <= 5; m++) mon[m].setSelected(true); }),
                chip("Cool season (Nov-Jan)", () -> { allMonths(false); mon[10].setSelected(true); mon[11].setSelected(true); mon[0].setSelected(true); }),
                chip("Midday (11:30-15:30)", () -> { hFrom.setValue(indexOfUtc(6)); hTo.setValue(indexOfUtc(9)); }));
        box.getChildren().add(presets);

        box.getChildren().add(Ui.label("DATE RANGE", "side-h"));
        box.getChildren().addAll(from, to);
        box.getChildren().add(Ui.label("TIME OF DAY (IST, start of hour)", "side-h"));
        box.getChildren().addAll(hFrom, hTo);

        box.getChildren().add(Ui.label("GRID POINTS", "side-h"));
        for (int l = 0; l < ds.nLoc; l++) {
            String hint = Cfg.areaHint(ds.locLat[l], ds.locLon[l]);
            loc[l] = new CheckBox(ds.locShort[l] + (hint.isEmpty() ? "" : "  " + hint));
            loc[l].setTooltip(new Tooltip(ds.locName[l]));
            loc[l].setSelected(true);
            loc[l].selectedProperty().addListener((o, a, b) -> push());
            box.getChildren().add(loc[l]);
        }
        box.getChildren().add(Ui.label("UHI CLASS", "side-h"));
        for (int c = 0; c < Cfg.NC; c++) {
            cls[c] = new CheckBox(Cfg.CLASS_NAMES[c]);
            cls[c].setGraphic(Ui.dot(Palette.CLASS[c]));
            cls[c].setSelected(true);
            cls[c].selectedProperty().addListener((o, a, b) -> push());
            box.getChildren().add(cls[c]);
        }
        box.getChildren().add(Ui.label("HEAT-RISK LEVEL", "side-h"));
        for (int k = 0; k < 5; k++) {
            risk[k] = new CheckBox(HeatRisk.LEVELS[k]);
            risk[k].setGraphic(Ui.dot(Palette.RISK[k]));
            risk[k].setSelected(true);
            risk[k].selectedProperty().addListener((o, a, b) -> push());
            box.getChildren().add(risk[k]);
        }
        box.getChildren().add(Ui.label("MONTHS", "side-h"));
        FlowPane months = new FlowPane(4, 4);
        String[] mn = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        for (int m = 0; m < 12; m++) {
            mon[m] = new ToggleButton(mn[m]);
            mon[m].getStyleClass().add("month-toggle");
            mon[m].setSelected(true);
            mon[m].selectedProperty().addListener((o, a, b) -> push());
            months.getChildren().add(mon[m]);
        }
        box.getChildren().add(months);
        count.getStyleClass().add("note");
        count.setPadding(new Insets(10, 0, 0, 0));
        box.getChildren().add(count);

        setContent(box);
        setFitToWidth(true);
        setMinWidth(0);
        setHbarPolicy(ScrollBarPolicy.NEVER);
        getStyleClass().addAll("sidebar", "sidebar-scroll");
        debounce.setOnFinished(e -> apply());
        st.onView(() -> count.setText(String.format("%,d of %,d hourly rows in view", st.rows.length, st.ds.n)));
    }

    private static Region spacer() { Region r = new Region(); HBox.setHgrow(r, Priority.ALWAYS); return r; }

    private Button chip(String text, Runnable r) {
        Button b = new Button(text);
        b.getStyleClass().add("chip");
        b.setOnAction(e -> { muted = true; r.run(); muted = false; apply(); });
        return b;
    }

    private int indexOfUtc(int utc) { for (int i = 0; i < 24; i++) if (Cfg.hourAt(i) == utc) return i; return 0; }
    private void allMonths(boolean on) { for (ToggleButton t : mon) t.setSelected(on); }
    private void setDates(LocalDate a, LocalDate b) { from.setValue(a); to.setValue(b); }

    void reset() {
        muted = true;
        DataStore ds = st.ds;
        setDates(ds.time(0).toLocalDate(), ds.time(ds.nHours - 1).toLocalDate());
        hFrom.setValue(0); hTo.setValue(23);
        for (CheckBox c : loc) c.setSelected(true);
        for (CheckBox c : cls) c.setSelected(true);
        for (CheckBox c : risk) c.setSelected(true);
        allMonths(true);
        muted = false;
        apply();
    }

    private void push() { if (!muted) debounce.playFromStart(); }

    void apply() {
        Filter f = st.filter;
        if (from.getValue() != null) f.from = from.getValue();
        if (to.getValue() != null) f.to = to.getValue();
        f.setHourWindow(hFrom.getValue(), hTo.getValue());
        for (int i = 0; i < loc.length; i++) f.loc[i] = loc[i].isSelected();
        for (int i = 0; i < cls.length; i++) f.cls[i] = cls[i].isSelected();
        for (int i = 0; i < risk.length; i++) f.risk[i] = risk[i].isSelected();
        for (int i = 0; i < 12; i++) f.month[i] = mon[i].isSelected();
        st.refresh();
    }
}
