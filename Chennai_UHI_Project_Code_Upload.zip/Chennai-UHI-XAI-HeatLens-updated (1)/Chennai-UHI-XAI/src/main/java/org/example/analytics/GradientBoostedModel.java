package org.example.analytics;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.function.Consumer;
import java.util.stream.IntStream;

/**
 * Histogram-based multi-class gradient boosting (softmax objective, Newton leaf values),
 * written in plain Java so the project needs no extra library.
 */
public final class GradientBoostedModel implements UhiClassifier, Serializable {
    private static final long serialVersionUID = 1L;

    public static final class Params implements Serializable {
        private static final long serialVersionUID = 1L;
        public int rounds = 250, depth = 5, minChild = 30, bins = 64, patience = 20;
        public double lr = 0.08, lambda = 2.0, subsample = 0.7;
        public long seed = 42;
        public String label = "Gradient Boosting";
    }

    static final class Tree implements Serializable {
        private static final long serialVersionUID = 1L;
        int[] feat; double[] thr; int[] left, right; double[] val;
        double predict(double[] x) {
            int n = 0;
            while (feat[n] >= 0) n = x[feat[n]] <= thr[n] ? left[n] : right[n];
            return val[n];
        }
    }

    private final int k, nf;
    private final List<Tree[]> rounds = new ArrayList<>();
    private final double[] gain;
    private final String label;
    public int bestRound;

    private GradientBoostedModel(int k, int nf, String label) {
        this.k = k; this.nf = nf; this.label = label; this.gain = new double[nf];
    }

    @Override public String name() { return label; }
    public int rounds() { return rounds.size(); }
    public double[] featureGain() { return gain; }

    public double[] rawScores(double[] x) {
        double[] s = new double[k];
        for (Tree[] r : rounds) for (int c = 0; c < k; c++) s[c] += r[c].predict(x);
        return s;
    }

    @Override public double[] predictProba(double[] x) {
        double[] s = rawScores(x);
        UhiClassifier.softmaxInPlace(s);
        return s;
    }

    /** Trains with early stopping on the validation log-loss. */
    public static GradientBoostedModel fit(double[][] X, int[] y, double[][] Xv, int[] yv, int k,
                                           Params p, Consumer<String> log) {
        int n = X.length, nf = X[0].length;
        GradientBoostedModel m = new GradientBoostedModel(k, nf, p.label);

        // ---- quantile binning ----
        double[][] edges = new double[nf][];
        byte[][] B = new byte[nf][n];
        IntStream.range(0, nf).parallel().forEach(f -> {
            double[] col = new double[n];
            for (int i = 0; i < n; i++) col[i] = X[i][f];
            double[] sorted = col.clone();
            Arrays.sort(sorted);
            double[] e = new double[p.bins - 1];
            int ne = 0;
            for (int q = 1; q < p.bins; q++) {
                double v = sorted[(int) ((long) q * (n - 1) / p.bins)];
                if (ne == 0 || v > e[ne - 1]) e[ne++] = v;
            }
            edges[f] = Arrays.copyOf(e, ne);
            for (int i = 0; i < n; i++) {
                int lo = 0, hi = ne;
                while (lo < hi) { int mid = (lo + hi) >>> 1; if (col[i] <= edges[f][mid]) hi = mid; else lo = mid + 1; }
                B[f][i] = (byte) lo;
            }
        });

        double[][] score = new double[n][k];
        double[][] vscore = Xv == null ? null : new double[Xv.length][k];
        double[] g = new double[n], h = new double[n];
        Random rnd = new Random(p.seed);
        double bestLoss = Double.MAX_VALUE;
        int sinceBest = 0;

        for (int r = 0; r < p.rounds; r++) {
            int[] rows = new int[n];
            int rc = 0;
            for (int i = 0; i < n; i++) if (rnd.nextDouble() < p.subsample) rows[rc++] = i;
            double[][] prob = new double[n][];
            for (int i = 0; i < n; i++) { prob[i] = score[i].clone(); UhiClassifier.softmaxInPlace(prob[i]); }
            Tree[] round = new Tree[k];
            for (int c = 0; c < k; c++) {
                for (int i = 0; i < n; i++) {
                    double pc = prob[i][c];
                    g[i] = pc - (y[i] == c ? 1 : 0);
                    h[i] = Math.max(2.0 * pc * (1 - pc), 1e-6);
                }
                round[c] = buildTree(B, edges, g, h, Arrays.copyOf(rows, rc), p, m.gain);
            }
            m.rounds.add(round);
            for (int i = 0; i < n; i++) for (int c = 0; c < k; c++) score[i][c] += round[c].predict(X[i]);

            if (Xv != null) {
                double loss = 0;
                for (int i = 0; i < Xv.length; i++) {
                    for (int c = 0; c < k; c++) vscore[i][c] += round[c].predict(Xv[i]);
                    double[] pr = vscore[i].clone();
                    UhiClassifier.softmaxInPlace(pr);
                    loss -= Math.log(Math.max(pr[yv[i]], 1e-12));
                }
                loss /= Xv.length;
                if (loss < bestLoss - 1e-5) { bestLoss = loss; m.bestRound = r + 1; sinceBest = 0; } else sinceBest++;
                if (log != null && r % 25 == 0)
                    log.accept(String.format(java.util.Locale.ROOT, "  %s round %d  val log-loss %.4f", p.label, r + 1, loss));
                if (sinceBest >= p.patience) break;
            } else m.bestRound = r + 1;
        }
        while (m.rounds.size() > m.bestRound) m.rounds.remove(m.rounds.size() - 1);
        if (log != null) log.accept(String.format(java.util.Locale.ROOT, "  %s finished with %d rounds", p.label, m.rounds.size()));
        return m;
    }

    // ---------------- tree building ----------------

    private static Tree buildTree(byte[][] B, double[][] edges, double[] g, double[] h, int[] rows,
                                  Params p, double[] gainAcc) {
        List<int[]> ints = new ArrayList<>();       // feat,left,right
        List<double[]> dbls = new ArrayList<>();    // thr,val
        build(B, edges, g, h, rows, 0, rows.length, 0, p, ints, dbls, gainAcc);
        Tree t = new Tree();
        int sz = ints.size();
        t.feat = new int[sz]; t.left = new int[sz]; t.right = new int[sz]; t.thr = new double[sz]; t.val = new double[sz];
        for (int i = 0; i < sz; i++) {
            t.feat[i] = ints.get(i)[0]; t.left[i] = ints.get(i)[1]; t.right[i] = ints.get(i)[2];
            t.thr[i] = dbls.get(i)[0]; t.val[i] = dbls.get(i)[1];
        }
        return t;
    }

    private static int build(byte[][] B, double[][] edges, double[] g, double[] h, int[] idx, int lo, int hi,
                             int depth, Params p, List<int[]> ints, List<double[]> dbls, double[] gainAcc) {
        int id = ints.size();
        ints.add(new int[]{-1, -1, -1});
        dbls.add(new double[]{0, 0});
        double G = 0, H = 0;
        for (int i = lo; i < hi; i++) { G += g[idx[i]]; H += h[idx[i]]; }
        double leaf = -G / (H + p.lambda) * p.lr;
        dbls.get(id)[1] = leaf;
        int cnt = hi - lo;
        if (depth >= p.depth || cnt < 2 * p.minChild) return id;

        int nf = B.length, nb = p.bins;
        double[] bestGain = new double[nf];
        int[] bestBin = new int[nf];
        final double Gf = G, Hf = H;
        IntStream.range(0, nf).parallel().forEach(f -> {
            double[] hg = new double[nb], hh = new double[nb];
            int[] hc = new int[nb];
            byte[] col = B[f];
            for (int i = lo; i < hi; i++) {
                int r = idx[i], b = col[r] & 0xFF;
                hg[b] += g[r]; hh[b] += h[r]; hc[b]++;
            }
            double gl = 0, hl = 0; int cl = 0;
            double base = Gf * Gf / (Hf + p.lambda);
            double bg = 1e-7; int bb = -1;
            int last = edges[f].length;           // bins 0..last
            for (int b = 0; b < last; b++) {
                gl += hg[b]; hl += hh[b]; cl += hc[b];
                int cr = cnt - cl;
                if (cl < p.minChild || cr < p.minChild) continue;
                double gr = Gf - gl, hr = Hf - hl;
                double gain = gl * gl / (hl + p.lambda) + gr * gr / (hr + p.lambda) - base;
                if (gain > bg) { bg = gain; bb = b; }
            }
            bestGain[f] = bb < 0 ? 0 : bg; bestBin[f] = bb;
        });
        int bf = -1; double bgain = 0;
        for (int f = 0; f < nf; f++) if (bestBin[f] >= 0 && bestGain[f] > bgain) { bgain = bestGain[f]; bf = f; }
        if (bf < 0) return id;

        gainAcc[bf] += bgain;
        int split = bestBin[bf];
        byte[] col = B[bf];
        int i = lo, j = hi - 1;
        while (i <= j) {
            if ((col[idx[i]] & 0xFF) <= split) i++;
            else { int t = idx[i]; idx[i] = idx[j]; idx[j] = t; j--; }
        }
        int mid = i;
        int l = build(B, edges, g, h, idx, lo, mid, depth + 1, p, ints, dbls, gainAcc);
        int r = build(B, edges, g, h, idx, mid, hi, depth + 1, p, ints, dbls, gainAcc);
        ints.get(id)[0] = bf; ints.get(id)[1] = l; ints.get(id)[2] = r;
        dbls.get(id)[0] = edges[bf][split];
        return id;
    }
}
