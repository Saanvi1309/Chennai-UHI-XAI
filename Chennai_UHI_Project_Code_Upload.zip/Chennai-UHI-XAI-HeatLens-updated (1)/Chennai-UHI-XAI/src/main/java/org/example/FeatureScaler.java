package org.example;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.io.input.BOMInputStream;

import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class FeatureScaler {

    // The 28 input features
    private static final String[] FEATURES = {
            "latitude",
            "longitude",
            "air_temperature",
            "dew_point_temperature",
            "cloud_cover",
            "u10",
            "v10",
            "wind_speed",
            "wind_direction",
            "relative_humidity",
            "pressure",
            "rainfall",
            "red_band",
            "nir_band",
            "ndvi",
            "ndbi",
            "ndwi",
            "land_use_type",
            "elevation",
            "distance_to_coast",
            "distance_to_green_space",
            "distance_to_road",
            "distance_to_water",
            "building_density",
            "road_density",
            "spatial_match_distance_km",
            "dynamic_nearest_distance_km",
            "landsat_temporal_gap_days"
    };

    private static final String TARGET = "UHI_Class";

    public static void main(String[] args) throws Exception {

        String trainFile = "data/processed/train.csv";
        String validationFile = "data/processed/validation.csv";
        String testFile = "data/processed/test.csv";

        String scaledTrainFile = "data/processed/train_scaled.csv";
        String scaledValidationFile = "data/processed/validation_scaled.csv";
        String scaledTestFile = "data/processed/test_scaled.csv";

        System.out.println("======================================");
        System.out.println("FEATURE STANDARDIZATION");
        System.out.println("======================================");

        double[] mean = new double[FEATURES.length];
        double[] std = new double[FEATURES.length];

        calculateTrainingStatistics(trainFile, mean, std);

        System.out.println();
        System.out.println("Training statistics calculated.");
        System.out.println();

        System.out.println("Feature statistics:");
        System.out.println("--------------------------------------");

        for (int i = 0; i < FEATURES.length; i++) {
            System.out.printf(
                    "%-35s Mean = %12.6f   Std = %12.6f%n",
                    FEATURES[i],
                    mean[i],
                    std[i]
            );
        }

        scaleFile(
                trainFile,
                scaledTrainFile,
                mean,
                std
        );

        scaleFile(
                validationFile,
                scaledValidationFile,
                mean,
                std
        );

        scaleFile(
                testFile,
                scaledTestFile,
                mean,
                std
        );

        System.out.println();
        System.out.println("======================================");
        System.out.println("SCALING COMPLETED SUCCESSFULLY!");
        System.out.println("======================================");
        System.out.println("Created:");
        System.out.println(scaledTrainFile);
        System.out.println(scaledValidationFile);
        System.out.println(scaledTestFile);
    }


    private static void calculateTrainingStatistics(
            String filePath,
            double[] mean,
            double[] std
    ) throws IOException {

        long count = 0;

        // ======================================
        // PASS 1: Calculate means
        // ======================================

        double[] sum = new double[FEATURES.length];

        try (
                CSVParser parser = CSVParser.parse(
                        Path.of(filePath),
                        StandardCharsets.UTF_8,
                        CSVFormat.DEFAULT.builder()
                                .setHeader()
                                .setSkipHeaderRecord(true)
                                .build()
                )
        ) {

            for (CSVRecord record : parser) {

                for (int i = 0; i < FEATURES.length; i++) {

                    double value = parseFeatureValue(
                            record.get(FEATURES[i])
                    );

                    sum[i] += value;
                }

                count++;
            }
        }

        System.out.println("Training rows used for statistics: " + count);

        for (int i = 0; i < FEATURES.length; i++) {
            mean[i] = sum[i] / count;
        }


        // ======================================
        // PASS 2: Calculate standard deviations
        // ======================================

        double[] squaredDifferenceSum =
                new double[FEATURES.length];

        try (
                CSVParser parser = CSVParser.parse(
                        Path.of(filePath),
                        StandardCharsets.UTF_8,
                        CSVFormat.DEFAULT.builder()
                                .setHeader()
                                .setSkipHeaderRecord(true)
                                .build()
                )
        ) {

            for (CSVRecord record : parser) {

                for (int i = 0; i < FEATURES.length; i++) {

                    double value = parseFeatureValue(
                            record.get(FEATURES[i])
                    );

                    double difference =
                            value - mean[i];

                    squaredDifferenceSum[i] +=
                            difference * difference;
                }
            }
        }


        // Calculate standard deviation
        for (int i = 0; i < FEATURES.length; i++) {

            double variance =
                    squaredDifferenceSum[i] / count;

            std[i] = Math.sqrt(variance);

            // Constant features are kept,
            // but their standard deviation is set to 1
            // to prevent division by zero.
            if (std[i] < 1e-12) {
                std[i] = 1.0;
            }
        }
    }


    private static void scaleFile(
            String inputFile,
            String outputFile,
            double[] mean,
            double[] std
    ) throws IOException {

        Path outputPath = Path.of(outputFile);

        try (
                CSVParser parser = CSVParser.parse(
                        Path.of(inputFile),
                        StandardCharsets.UTF_8,
                        CSVFormat.DEFAULT.builder()
                                .setHeader()
                                .setSkipHeaderRecord(true)
                                .build()
                );

                BufferedWriter writer = Files.newBufferedWriter(
                        outputPath,
                        StandardCharsets.UTF_8
                );

                CSVPrinter printer = new CSVPrinter(
                        writer,
                        CSVFormat.DEFAULT
                )
        ) {

            // Write header
            List<String> header = new ArrayList<>();

            for (String feature : FEATURES) {
                header.add(feature);
            }

            header.add(TARGET);

            printer.printRecord(header);

            long rowCount = 0;

            for (CSVRecord record : parser) {

                List<String> outputRow = new ArrayList<>();

                for (int i = 0; i < FEATURES.length; i++) {

                    double value = parseFeatureValue(
                            record.get(FEATURES[i])
                    );

                    // Standardization:
                    // z = (value - mean) / standard deviation

                    double scaledValue =
                            (value - mean[i]) / std[i];

                    outputRow.add(
                            Double.toString(scaledValue)
                    );
                }

                // Keep target unchanged
                outputRow.add(record.get(TARGET));

                printer.printRecord(outputRow);

                rowCount++;
            }

            System.out.println(
                    "Scaled " + rowCount +
                            " rows -> " + outputFile
            );
        }
    }


    private static double parseFeatureValue(String value) {

        String cleaned = value
                .trim()
                .replace(",", "");

        return Double.parseDouble(cleaned);
    }
}