package org.example.analytics;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Locale;

/**
 * Descriptive urban-heat analytics computed only from the observations in the dataset (no interpolation):
 * seasonal / monthly patterns, day vs night, persistent hotspots, rankings, correlations and heat-risk ranking.
 * The dataset has six grid points, so every spatial statement is about those six cells and nothing in between.
 */
public final class UrbanAnalytics {
    private UrbanAnalytics() {}

    public static final String[] SEASONS = {"Winter (Jan-Feb)", "Summer / pre-monsoon (Mar-May)", "South-west monsoon (Jun-Sep)", "North-east monsoon (Oct-Dec)"};
    public static int season(int month0) { return month0 <= 1 ? 0 : month0 <= 4 ? 1 : month0 <= 8 ? 2 : 3; }
    /** Data hours are UTC. UTC 01-12 = 06:30-17:30 IST (day); the rest is night. */
    public static boolean isDay(int utcHour) { return utcHour >= 1 && utcHour <= 12; }

    /** Per-location aggregate over a set of rows. */
    public static final class LocAgg {
        public int n; public double lst, air, anomaly, adjHi, extremeShare, highPlusShare, dangerShare;
    }

    public static LocAgg[] aggregate(DataStore ds, int[] rows) {
        LocAgg[] a = new LocAgg[ds.nLoc];
        for (int l = 0; l < ds.nLoc; l++) a[l] = new LocAgg();
        for (int r : rows) {
            LocAgg g = a[ds.loc[r]];
            g.n++; g.lst += ds.lst[r]; g.air += ds.x[r][Cfg.F_AIR_T]; g.anomaly += ds.anomaly[r]; g.adjHi += ds.adjHi[r];
            if (ds.cls[r] == 3) g.extremeShare++;
            if (ds.cls[r] >= 2) g.highPlusShare++;
            if (ds.risk[r] >= 3) g.dangerShare++;
        }
        for (LocAgg g : a) if (g.n > 0) {
            g.lst /= g.n; g.air /= g.n; g.anomaly /= g.n; g.adjHi /= g.n;
            g.extremeShare /= g.n; g.highPlusShare /= g.n; g.dangerShare /= g.n;
        }
        return a;
    }

    public static int[] allRows(DataStore ds) { int[] r = new int[ds.n]; for (int i = 0; i < r.length; i++) r[i] = i; return r; }
    public static int[] splitRows(DataStore ds, int split) {
        int c = 0; for (int i = 0; i < ds.n; i++) if (ds.split[i] == split) c++;
        int[] r = new int[c]; c = 0; for (int i = 0; i < ds.n; i++) if (ds.split[i] == split) r[c++] = i; return r;
    }

    // ------------------------------------------------------------------ hotspot persistence

    public record Hotspot(int loc, double meanAnomaly, double extremeShare, int monthsTop2, int monthsTotal, double persistence,
                          int rank2024, int rank2025, String verdict) {}

    public static Hotspot[] hotspots(DataStore ds) {
        int L = ds.nLoc, months = 24;
        double[][] sum = new double[months][L]; int[][] cnt = new int[months][L];
        double[] s24 = new double[L], s25 = new double[L]; int[] c24 = new int[L], c25 = new int[L];
        double[] all = new double[L]; int[] allN = new int[L]; int[] ext = new int[L];
        for (int i = 0; i < ds.n; i++) {
            int ym = (ds.year[i] - 2024) * 12 + ds.month[i];
            sum[ym][ds.loc[i]] += ds.anomaly[i]; cnt[ym][ds.loc[i]]++;
            if (ds.year[i] == 2024) { s24[ds.loc[i]] += ds.anomaly[i]; c24[ds.loc[i]]++; } else { s25[ds.loc[i]] += ds.anomaly[i]; c25[ds.loc[i]]++; }
            all[ds.loc[i]] += ds.anomaly[i]; allN[ds.loc[i]]++; if (ds.cls[i] == 3) ext[ds.loc[i]]++;
        }
        int[] top2 = new int[L];
        for (int m = 0; m < months; m++) {
            Integer[] o = order(avg(sum[m], cnt[m]), true);
            top2[o[0]]++; top2[o[1]]++;
        }
        Integer[] r24 = order(avg(s24, c24), true), r25 = order(avg(s25, c25), true);
        int[] rk24 = new int[L], rk25 = new int[L];
        for (int i = 0; i < L; i++) { rk24[r24[i]] = i + 1; rk25[r25[i]] = i + 1; }
        Hotspot[] h = new Hotspot[L];
        for (int l = 0; l < L; l++) {
            double p = (double) top2[l] / months;
            // persistent = among the two warmest of the six points in at least half of the 24 months AND in the top two in both years
            String v = p >= 0.5 && rk24[l] <= 2 && rk25[l] <= 2 ? "Persistent hotspot"
                    : p >= 0.40 ? "Recurrent warm spot" : p > 0 ? "Occasional / seasonal" : "Not a hotspot";
            h[l] = new Hotspot(l, all[l] / Math.max(1, allN[l]), (double) ext[l] / Math.max(1, allN[l]), top2[l], months, p, rk24[l], rk25[l], v);
        }
        return h;
    }

    private static double[] avg(double[] s, int[] c) { double[] a = new double[s.length]; for (int i = 0; i < a.length; i++) a[i] = c[i] == 0 ? -1e9 : s[i] / c[i]; return a; }
    private static Integer[] order(double[] v, boolean desc) {
        Integer[] o = new Integer[v.length];
        for (int i = 0; i < o.length; i++) o[i] = i;
        Arrays.sort(o, (a, b) -> desc ? Double.compare(v[b], v[a]) : Double.compare(v[a], v[b]));
        return o;
    }

    // ------------------------------------------------------------------ correlation

    public static final String[] CORR_VARS = {"land_surface_temperature", "uhi_anomaly", "air_temperature", "relative_humidity", "wind_speed", "cloud_cover",
            "pressure", "ndvi", "building_density", "road_density", "distance_to_green_space", "distance_to_water", "distance_to_road", "elevation", "distance_to_coast"};
    private static final int[] CORR_FEAT = {-1, -2, Cfg.F_AIR_T, Cfg.F_RH, Cfg.F_WIND, Cfg.F_CLOUD, Cfg.F_PRESS, Cfg.F_NDVI, Cfg.F_BLD, Cfg.F_ROAD,
            Cfg.F_DGREEN, Cfg.F_DWATER, Cfg.F_DROAD, 18, 19};

    private static double val(DataStore ds, int i, int v) { return CORR_FEAT[v] == -1 ? ds.lst[i] : CORR_FEAT[v] == -2 ? ds.anomaly[i] : ds.x[i][CORR_FEAT[v]]; }

    /** Pearson correlation matrix; if withinLocation, every variable is first centred on its grid-point mean. */
    public static double[][] correlation(DataStore ds, int[] rows, boolean withinLocation) {
        int V = CORR_VARS.length;
        double[][] locMean = new double[ds.nLoc][V]; int[] ln = new int[ds.nLoc];
        if (withinLocation) {
            for (int r : rows) { ln[ds.loc[r]]++; for (int v = 0; v < V; v++) locMean[ds.loc[r]][v] += val(ds, r, v); }
            for (int l = 0; l < ds.nLoc; l++) if (ln[l] > 0) for (int v = 0; v < V; v++) locMean[l][v] /= ln[l];
        }
        double[] mean = new double[V]; double[][] c = new double[V][V];
        for (int r : rows) for (int v = 0; v < V; v++) mean[v] += val(ds, r, v) - (withinLocation ? locMean[ds.loc[r]][v] : 0);
        for (int v = 0; v < V; v++) mean[v] /= rows.length;
        double[] x = new double[V];
        for (int r : rows) {
            for (int v = 0; v < V; v++) x[v] = val(ds, r, v) - (withinLocation ? locMean[ds.loc[r]][v] : 0) - mean[v];
            for (int a = 0; a < V; a++) for (int b = a; b < V; b++) c[a][b] += x[a] * x[b];
        }
        double[][] out = new double[V][V];
        for (int a = 0; a < V; a++) for (int b = 0; b < V; b++) {
            double d = Math.sqrt(c[Math.min(a, b)][Math.min(a, b)] * c[Math.max(a, b)][Math.max(a, b)]);
            out[a][b] = d < 1e-12 ? Double.NaN : c[Math.min(a, b)][Math.max(a, b)] / d;
        }
        return out;
    }

    public static double[] ranks(double[] v) {
        Integer[] o = order(v, false);
        double[] r = new double[v.length];
        int i = 0;
        while (i < o.length) {
            int j = i;
            while (j + 1 < o.length && v[o[j + 1]] == v[o[i]]) j++;
            for (int q = i; q <= j; q++) r[o[q]] = (i + j) / 2.0 + 1;
            i = j + 1;
        }
        return r;
    }

    public static double pearson(double[] a, double[] b) {
        int n = a.length; double ma = 0, mb = 0;
        for (int i = 0; i < n; i++) { ma += a[i]; mb += b[i]; }
        ma /= n; mb /= n;
        double sab = 0, saa = 0, sbb = 0;
        for (int i = 0; i < n; i++) { sab += (a[i] - ma) * (b[i] - mb); saa += (a[i] - ma) * (a[i] - ma); sbb += (b[i] - mb) * (b[i] - mb); }
        return saa < 1e-12 || sbb < 1e-12 ? Double.NaN : sab / Math.sqrt(saa * sbb);
    }

    public static double spearman(double[] a, double[] b) { return pearson(ranks(a), ranks(b)); }

    /** Static value of a feature at grid point l (mean over its rows for time-varying ones). */
    public static double[] locMeans(DataStore ds, int feature) {
        double[] s = new double[ds.nLoc]; int[] n = new int[ds.nLoc];
        for (int i = 0; i < ds.n; i++) { s[ds.loc[i]] += ds.x[i][feature]; n[ds.loc[i]]++; }
        for (int l = 0; l < ds.nLoc; l++) s[l] /= Math.max(1, n[l]);
        return s;
    }

    // ------------------------------------------------------------------ heat-risk ranking

    public record RiskRank(int loc, double meanAnomaly, double extremeShare, double dangerShare, double meanAdjHi, double score, int rank) {}

    /** Composite heat-risk ranking over the given rows: mean of the grid-point ranks on four exposure measures (1 = highest exposure). */
    public static RiskRank[] riskRanking(DataStore ds, int[] rows) {
        LocAgg[] a = aggregate(ds, rows);
        int L = ds.nLoc;
        double[][] m = new double[4][L];
        for (int l = 0; l < L; l++) { m[0][l] = a[l].anomaly; m[1][l] = a[l].extremeShare; m[2][l] = a[l].dangerShare; m[3][l] = a[l].adjHi; }
        double[] score = new double[L];
        for (int k = 0; k < 4; k++) {
            double[] rk = ranks(m[k]);          // 1 = lowest, L = highest
            for (int l = 0; l < L; l++) score[l] += (rk[l] - 1) / (L - 1.0) / 4.0;      // 0..1, 1 = highest exposure
        }
        Integer[] o = order(score, true);
        int[] rank = new int[L];
        for (int i = 0; i < L; i++) rank[o[i]] = i + 1;
        RiskRank[] out = new RiskRank[L];
        for (int l = 0; l < L; l++) out[l] = new RiskRank(l, a[l].anomaly, a[l].extremeShare, a[l].dangerShare, a[l].adjHi, score[l], rank[l]);
        return out;
    }

    // ------------------------------------------------------------------ files

    public static void write(DataStore ds, Path dir) throws IOException {
        Files.createDirectories(dir);
        int L = ds.nLoc;
        // seasons
        StringBuilder se = new StringBuilder("location,season,rows,mean_lst_c,mean_air_temp_c,mean_uhi_anomaly_c,high_or_extreme_share,extreme_share,mean_adjusted_heat_index_c\n");
        for (int l = 0; l < L; l++) for (int s = 0; s < 4; s++) {
            int c = 0; for (int i = 0; i < ds.n; i++) if (ds.loc[i] == l && season(ds.month[i]) == s) c++;
            int[] rows = new int[c]; c = 0;
            for (int i = 0; i < ds.n; i++) if (ds.loc[i] == l && season(ds.month[i]) == s) rows[c++] = i;
            LocAgg g = aggregate(ds, rows)[l];
            se.append(String.format(Locale.ROOT, "%s,%s,%d,%.3f,%.3f,%.3f,%.4f,%.4f,%.3f%n", ds.locShort[l], SEASONS[s], g.n, g.lst, g.air, g.anomaly, g.highPlusShare, g.extremeShare, g.adjHi));
        }
        Files.writeString(dir.resolve("season_location_stats.csv"), se.toString());

        // monthly class distribution
        StringBuilder mo = new StringBuilder("year,month,rows,share_low,share_moderate,share_high,share_extreme,mean_lst_c,mean_air_temp_c,mean_uhi_anomaly_c,mean_adjusted_heat_index_c\n");
        for (int ym = 0; ym < 24; ym++) {
            int[] cc = new int[4]; int n = 0; double lst = 0, air = 0, an = 0, adj = 0;
            for (int i = 0; i < ds.n; i++) if ((ds.year[i] - 2024) * 12 + ds.month[i] == ym) { n++; cc[ds.cls[i]]++; lst += ds.lst[i]; air += ds.x[i][Cfg.F_AIR_T]; an += ds.anomaly[i]; adj += ds.adjHi[i]; }
            if (n == 0) continue;
            mo.append(String.format(Locale.ROOT, "%d,%d,%d,%.4f,%.4f,%.4f,%.4f,%.3f,%.3f,%.3f,%.3f%n", 2024 + ym / 12, ym % 12 + 1, n, (double) cc[0] / n, (double) cc[1] / n, (double) cc[2] / n, (double) cc[3] / n, lst / n, air / n, an / n, adj / n));
        }
        Files.writeString(dir.resolve("monthly_uhi_distribution.csv"), mo.toString());

        // day / night
        StringBuilder dn = new StringBuilder("location,period,rows,mean_lst_c,mean_air_temp_c,mean_uhi_anomaly_c,high_or_extreme_share,extreme_share\n");
        for (int l = 0; l < L; l++) for (int p = 0; p < 2; p++) {
            int c = 0; for (int i = 0; i < ds.n; i++) if (ds.loc[i] == l && isDay(ds.hour[i]) == (p == 0)) c++;
            int[] rows = new int[c]; c = 0;
            for (int i = 0; i < ds.n; i++) if (ds.loc[i] == l && isDay(ds.hour[i]) == (p == 0)) rows[c++] = i;
            LocAgg g = aggregate(ds, rows)[l];
            dn.append(String.format(Locale.ROOT, "%s,%s,%d,%.3f,%.3f,%.3f,%.4f,%.4f%n", ds.locShort[l], p == 0 ? "Day (06:30-17:30 IST)" : "Night (17:30-06:30 IST)", g.n, g.lst, g.air, g.anomaly, g.highPlusShare, g.extremeShare));
        }
        Files.writeString(dir.resolve("day_night_analysis.csv"), dn.toString());

        // hotspots
        StringBuilder hs = new StringBuilder("location,area_hint,mean_uhi_anomaly_c,extreme_share,months_in_top2_of_24,persistence,rank_2024,rank_2025,verdict\n");
        for (Hotspot h : hotspots(ds))
            hs.append(String.format(Locale.ROOT, "%s,\"%s\",%.3f,%.4f,%d,%.3f,%d,%d,%s%n", ds.locShort[h.loc()], Cfg.areaHint(ds.locLat[h.loc()], ds.locLon[h.loc()]), h.meanAnomaly(), h.extremeShare(), h.monthsTop2(), h.persistence(), h.rank2024(), h.rank2025(), h.verdict()));
        Files.writeString(dir.resolve("hotspot_persistence.csv"), hs.toString());

        // location ranking
        LocAgg[] all = aggregate(ds, allRows(ds));
        double[] lstV = new double[L], airV = new double[L], anV = new double[L];
        for (int l = 0; l < L; l++) { lstV[l] = all[l].lst; airV[l] = all[l].air; anV[l] = all[l].anomaly; }
        double[] rl = ranks(lstV), ra = ranks(airV), rn = ranks(anV);
        StringBuilder lr = new StringBuilder("location,mean_lst_c,rank_lst_1_hottest,mean_air_temp_c,rank_air_1_hottest,mean_uhi_anomaly_c,rank_anomaly_1_hottest\n");
        for (int l = 0; l < L; l++) lr.append(String.format(Locale.ROOT, "%s,%.3f,%d,%.3f,%d,%.3f,%d%n", ds.locShort[l], lstV[l], (int) (L + 1 - rl[l]), airV[l], (int) (L + 1 - ra[l]), anV[l], (int) (L + 1 - rn[l])));
        Files.writeString(dir.resolve("location_temperature_ranking.csv"), lr.toString());

        // correlation matrices
        for (int w = 0; w < 2; w++) {
            double[][] c = correlation(ds, allRows(ds), w == 1);
            StringBuilder cs = new StringBuilder("variable");
            for (String v : CORR_VARS) cs.append(',').append(v);
            cs.append('\n');
            for (int a = 0; a < c.length; a++) {
                cs.append(CORR_VARS[a]);
                for (int b = 0; b < c.length; b++) cs.append(Double.isNaN(c[a][b]) ? ",NaN" : String.format(Locale.ROOT, ",%.4f", c[a][b]));
                cs.append('\n');
            }
            Files.writeString(dir.resolve(w == 0 ? "correlation_matrix_pooled.csv" : "correlation_matrix_within_location.csv"), cs.toString());
        }
        // location-level (n = 6) rank correlation of static features with mean anomaly
        StringBuilder lc = new StringBuilder("feature,spearman_with_mean_anomaly,n_locations,note\n");
        int[] stat = {Cfg.F_BLD, Cfg.F_ROAD, Cfg.F_DGREEN, Cfg.F_DWATER, Cfg.F_DROAD, 18, 19, Cfg.F_NDVI};
        for (int f : stat) lc.append(String.format(Locale.ROOT, "%s,%.3f,%d,only six grid points: indicative; no significance claimed%n", Cfg.FEATURES[f], spearman(locMeans(ds, f), anV), L));
        Files.writeString(dir.resolve("location_level_correlation.csv"), lc.toString());

        // heat-risk ranking: whole record and test period
        StringBuilder rr = new StringBuilder("period,rank,location,area_hint,composite_exposure_score,mean_uhi_anomaly_c,extreme_share,danger_or_worse_share,mean_adjusted_heat_index_c\n");
        for (int p = 0; p < 2; p++) {
            RiskRank[] r = riskRanking(ds, p == 0 ? allRows(ds) : splitRows(ds, 2));
            Integer[] o = new Integer[L];
            for (int i = 0; i < L; i++) o[i] = i;
            Arrays.sort(o, (x, y) -> Integer.compare(r[x].rank(), r[y].rank()));
            for (int l : o)
                rr.append(String.format(Locale.ROOT, "%s,%d,%s,\"%s\",%.3f,%.3f,%.4f,%.4f,%.3f%n", p == 0 ? "2024-2025" : "test (Jul-Dec 2025)", r[l].rank(), ds.locShort[l], Cfg.areaHint(ds.locLat[l], ds.locLon[l]), r[l].score(), r[l].meanAnomaly(), r[l].extremeShare(), r[l].dangerShare(), r[l].meanAdjHi()));
        }
        Files.writeString(dir.resolve("heat_risk_ranking.csv"), rr.toString());
    }
}
