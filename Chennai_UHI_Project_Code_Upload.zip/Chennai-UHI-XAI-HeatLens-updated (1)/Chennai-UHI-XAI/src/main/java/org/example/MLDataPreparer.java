package org.example;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.io.input.BOMInputStream;

import java.io.InputStreamReader;
import java.io.Reader;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MLDataPreparer {

    private static final String INPUT_FILE =
            "data/processed/Chennai_UHI_Final.csv";

    private static final String OUTPUT_FILE =
            "data/processed/Chennai_UHI_ML_Ready.csv";

    // --------------------------------------------------
    // 28 features that will eventually be used by the DNN
    // --------------------------------------------------

    private static final String[] FEATURES = {

            "latitude",
            "longitude",

            "air_temperature",
            "dew_point_temperature",
            "cloud_cover",

            "u10",
            "v10",
            "wind_speed",
            "wind_direction",

            "relative_humidity",
            "pressure",
            "rainfall",

            "red_band",
            "nir_band",
            "ndvi",
            "ndbi",
            "ndwi",

            "land_use_type",
            "elevation",

            "distance_to_coast",
            "distance_to_green_space",
            "distance_to_road",
            "distance_to_water",

            "building_density",
            "road_density",

            "spatial_match_distance_km",
            "dynamic_nearest_distance_km",
            "landsat_temporal_gap_days"
    };

    public static void main(String[] args) {

        try {

            System.out.println("======================================");
            System.out.println("ML DATA PREPARATION");
            System.out.println("======================================");

            System.out.println(
                    "Input: " + INPUT_FILE
            );

            // --------------------------------------------------
            // 1. Read final UHI classification file
            // --------------------------------------------------

            BOMInputStream inputStream =
                    BOMInputStream.builder()
                            .setPath(java.nio.file.Paths.get(INPUT_FILE))
                            .get();

            Reader reader =
                    new InputStreamReader(
                            inputStream,
                            StandardCharsets.UTF_8
                    );

            CSVParser parser =
                    CSVFormat.DEFAULT
                            .builder()
                            .setHeader()
                            .setSkipHeaderRecord(true)
                            .get()
                            .parse(reader);

            // --------------------------------------------------
            // 2. Create output header
            // --------------------------------------------------

            List<String> outputHeaders =
                    new ArrayList<>();

            for (String feature : FEATURES) {
                outputHeaders.add(feature);
            }

            outputHeaders.add("UHI_Class");

            // --------------------------------------------------
            // 3. Create output CSV
            // --------------------------------------------------

            FileWriter writer =
                    new FileWriter(OUTPUT_FILE);

            CSVPrinter printer =
                    new CSVPrinter(
                            writer,
                            CSVFormat.DEFAULT
                                    .builder()
                                    .setHeader(
                                            outputHeaders.toArray(
                                                    new String[0]
                                            )
                                    )
                                    .build()
                    );

            long rowCount = 0;

            // --------------------------------------------------
            // 4. Process every record
            // --------------------------------------------------

            for (CSVRecord record : parser) {

                List<String> outputRow =
                        new ArrayList<>();

                // ----------------------------------------------
                // Add the 28 features
                // ----------------------------------------------

                for (String feature : FEATURES) {

                    String value =
                            record.get(feature);

                    // Population is no longer included,
                    // because it was found to have zero variance
                    // in the training data.
                    //
                    // Therefore no special Population parsing
                    // is required here.

                    outputRow.add(value);
                }

                // ----------------------------------------------
                // Add target class
                // ----------------------------------------------

                outputRow.add(
                        record.get("UHI_Class")
                );

                printer.printRecord(outputRow);

                rowCount++;
            }

            parser.close();
            printer.close();
            writer.close();

            // --------------------------------------------------
            // 5. Display results
            // --------------------------------------------------

            System.out.println();
            System.out.println("======================================");
            System.out.println("ML DATA PREPARATION SUCCESSFUL!");
            System.out.println("======================================");

            System.out.println(
                    "Rows: " + rowCount
            );

            System.out.println(
                    "Features: " + FEATURES.length
            );

            System.out.println(
                    "Target: UHI_Class"
            );

            System.out.println(
                    "Total columns: "
                            + (FEATURES.length + 1)
            );

            System.out.println();
            System.out.println(
                    "Output file:"
            );

            System.out.println(
                    OUTPUT_FILE
            );

        } catch (Exception e) {

            System.out.println();
            System.out.println(
                    "ERROR DURING ML DATA PREPARATION"
            );

            e.printStackTrace();
        }
    }
}