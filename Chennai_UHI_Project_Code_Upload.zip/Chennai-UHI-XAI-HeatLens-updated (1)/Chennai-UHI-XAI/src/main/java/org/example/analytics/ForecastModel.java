package org.example.analytics;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Consumer;

/**
 * Forecasts the UHI class 1-24 hours ahead for every grid point.
 * Class: one gradient-boosting model that takes the horizon as an input, fed with lagged UHI anomalies,
 * "same hour yesterday" values, current weather and the calendar of the target hour.
 * Heat-risk inputs (air temperature, humidity) are forecast with a diurnal climatology + decaying persistence.
 */
public final class ForecastModel implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final int MAX_H = 24;

    public static final String[] FEATURE_NAMES = {
            "horizon_h", "target_hour", "target_month", "origin_hour", "latitude", "longitude",
            "anomaly_now", "anomaly_lag1", "anomaly_lag3", "anomaly_lag6", "anomaly_lag12", "anomaly_lag24",
            "anomaly_mean_24h", "anomaly_same_hour_1d_ago", "anomaly_same_hour_2d_ago", "anomaly_same_hour_3d_ago",
            "air_temperature", "relative_humidity", "cloud_cover", "wind_speed", "pressure", "rainfall",
            "air_temp_change_6h", "humidity_change_6h", "air_temp_vs_grid", "humidity_vs_grid",
            "cloud_vs_grid", "pressure_vs_grid", "ndvi", "air_temp_vs_climate", "humidity_vs_climate",
            "dew_point_spread"
    };

    public GradientBoostedModel gb;
    /** Neural-network challenger; selected only when it beats GB on validation macro-F1. */
    public ForecastNnModel nn;
    public boolean useNn;
    public double[][][] climT, climRH;
    public int[][][] climClass;
    public double[] rhoT = new double[MAX_H + 1], rhoRH = new double[MAX_H + 1];
    public double[] classMeanAnomaly;
    public Eval testEval;

    // ---------------------------------------------------------------- features

    public double[] features(DataStore ds, int t, int l, int h) {
        LocalDateTime tau = DataStore.START.plusHours((long) t + h);
        LocalDateTime now = DataStore.START.plusHours(t);
        int r = ds.rowAtClamped(t, l);
        double[] x = ds.x[r];
        int r6 = ds.rowAtClamped(t - 6, l);
        double meanT = 0, meanRH = 0, meanC = 0, meanP = 0;
        for (int j = 0; j < ds.nLoc; j++) {
            double[] xj = ds.x[ds.rowAtClamped(t, j)];
            meanT += xj[Cfg.F_AIR_T]; meanRH += xj[Cfg.F_RH]; meanC += xj[Cfg.F_CLOUD]; meanP += xj[Cfg.F_PRESS];
        }
        meanT /= ds.nLoc; meanRH /= ds.nLoc; meanC /= ds.nLoc; meanP /= ds.nLoc;
        double m24 = 0;
        for (int k = 0; k < 24; k++) m24 += ds.anomalyAt(t - k, l);
        m24 /= 24;
        int tm = tau.getMonthValue() - 1;
        double[] f = new double[FEATURE_NAMES.length];
        int i = 0;
        f[i++] = h;
        f[i++] = tau.getHour();
        f[i++] = tm;
        f[i++] = now.getHour();
        f[i++] = ds.locLat[l];
        f[i++] = ds.locLon[l];
        f[i++] = ds.anomalyAt(t, l);
        f[i++] = ds.anomalyAt(t - 1, l);
        f[i++] = ds.anomalyAt(t - 3, l);
        f[i++] = ds.anomalyAt(t - 6, l);
        f[i++] = ds.anomalyAt(t - 12, l);
        f[i++] = ds.anomalyAt(t - 24, l);
        f[i++] = m24;
        f[i++] = ds.anomalyAt(t + h - 24, l);
        f[i++] = ds.anomalyAt(t + h - 48, l);
        f[i++] = ds.anomalyAt(t + h - 72, l);
        f[i++] = x[Cfg.F_AIR_T];
        f[i++] = x[Cfg.F_RH];
        f[i++] = x[Cfg.F_CLOUD];
        f[i++] = x[Cfg.F_WIND];
        f[i++] = x[Cfg.F_PRESS];
        f[i++] = x[Cfg.F_RAIN];
        f[i++] = x[Cfg.F_AIR_T] - ds.x[r6][Cfg.F_AIR_T];
        f[i++] = x[Cfg.F_RH] - ds.x[r6][Cfg.F_RH];
        f[i++] = x[Cfg.F_AIR_T] - meanT;
        f[i++] = x[Cfg.F_RH] - meanRH;
        f[i++] = x[Cfg.F_CLOUD] - meanC;
        f[i++] = x[Cfg.F_PRESS] - meanP;
        f[i++] = x[Cfg.F_NDVI];
        f[i++] = x[Cfg.F_AIR_T] - climT[l][now.getMonthValue() - 1][now.getHour()];
        f[i++] = x[Cfg.F_RH] - climRH[l][now.getMonthValue() - 1][now.getHour()];
        f[i++] = x[Cfg.F_AIR_T] - x[Cfg.F_DEW];
        return f;
    }

    // ---------------------------------------------------------------- training

    public static ForecastModel train(DataStore ds, Consumer<String> log) {
        ForecastModel m = new ForecastModel();
        m.classMeanAnomaly = ds.classMeanAnomaly.clone();
        m.fitClimatology(ds);
        m.fitPersistence(ds);

        Random rnd = new Random(11);
        List<double[]> tr = new ArrayList<>(), va = new ArrayList<>();
        List<Integer> ytr = new ArrayList<>(), yva = new ArrayList<>();
        for (int t = 0; t < ds.nHours; t++) {
            for (int l = 0; l < ds.nLoc; l++) {
                for (int s = 0; s < 3; s++) {
                    int h = 1 + rnd.nextInt(MAX_H);
                    if (t + h >= ds.nHours) continue;
                    int rt = ds.rowAt[t + h][l];
                    if (rt < 0) continue;
                    int sp = ds.split[rt];
                    if (sp == 0) { tr.add(m.features(ds, t, l, h)); ytr.add(ds.cls[rt]); }
                    else if (sp == 1 && s == 0) { va.add(m.features(ds, t, l, h)); yva.add(ds.cls[rt]); }
                }
            }
        }
        if (log != null) log.accept("  forecast samples: train " + tr.size() + ", validation " + va.size());
        GradientBoostedModel.Params p = new GradientBoostedModel.Params();
        p.label = "Forecast GB";
        p.rounds = 260; p.depth = 5; p.subsample = 0.5; p.lr = 0.08; p.patience = 15; p.minChild = 60;
        double[][] xtr = tr.toArray(new double[0][]), xva = va.toArray(new double[0][]);
        int[] itr = ytr.stream().mapToInt(i -> i).toArray(), iva = yva.stream().mapToInt(i -> i).toArray();
        m.gb = GradientBoostedModel.fit(xtr, itr, xva, iva, Cfg.NC, p, log);
        say(log, "  Training pure-Java neural-network forecaster (validation-selected; GB retained as fallback)...");
        m.nn = ForecastNnModel.fit(xtr, itr, xva, iva, Cfg.NC, log);
        double gbF1 = macroF1(m.gb, xva, iva);
        double nnF1 = ForecastNnModel.macroF1(m.nn, xva, iva, Cfg.NC);
        m.useNn = nnF1 > gbF1 + 1e-4;
        say(log, String.format(java.util.Locale.ROOT,
                "  Validation macro-F1 — Gradient Boosting %.4f; Neural Network %.4f; selected %s",
                gbF1, nnF1, m.useNn ? "Neural Network" : "Gradient Boosting"));
        return m;
    }

    private void fitClimatology(DataStore ds) {
        int L = ds.nLoc;
        climT = new double[L][12][24]; climRH = new double[L][12][24];
        climClass = new int[L][12][24];
        int[][][] cnt = new int[L][12][24];
        int[][][][] cc = new int[L][12][24][Cfg.NC];
        for (int i = 0; i < ds.n; i++) {
            if (ds.split[i] != 0) continue;
            int l = ds.loc[i], mo = ds.month[i], h = ds.hour[i];
            climT[l][mo][h] += ds.x[i][Cfg.F_AIR_T];
            climRH[l][mo][h] += ds.x[i][Cfg.F_RH];
            cnt[l][mo][h]++;
            cc[l][mo][h][ds.cls[i]]++;
        }
        for (int l = 0; l < L; l++) for (int mo = 0; mo < 12; mo++) for (int h = 0; h < 24; h++) {
            int c = Math.max(1, cnt[l][mo][h]);
            climT[l][mo][h] /= c; climRH[l][mo][h] /= c;
            int b = 0;
            for (int k = 1; k < Cfg.NC; k++) if (cc[l][mo][h][k] > cc[l][mo][h][b]) b = k;
            climClass[l][mo][h] = b;
        }
    }

    private void fitPersistence(DataStore ds) {
        for (int h = 1; h <= MAX_H; h++) {
            double sxy = 0, sxx = 0, ryy = 0, rxx = 0;
            for (int t = 0; t + h < ds.nHours; t++) for (int l = 0; l < ds.nLoc; l++) {
                int r0 = ds.rowAt[t][l], r1 = ds.rowAt[t + h][l];
                if (r0 < 0 || r1 < 0 || ds.split[r1] != 0 || ds.split[r0] != 0) continue;
                double aT0 = ds.x[r0][Cfg.F_AIR_T] - climT[l][ds.month[r0]][ds.hour[r0]];
                double aT1 = ds.x[r1][Cfg.F_AIR_T] - climT[l][ds.month[r1]][ds.hour[r1]];
                double aR0 = ds.x[r0][Cfg.F_RH] - climRH[l][ds.month[r0]][ds.hour[r0]];
                double aR1 = ds.x[r1][Cfg.F_RH] - climRH[l][ds.month[r1]][ds.hour[r1]];
                sxy += aT0 * aT1; sxx += aT0 * aT0; ryy += aR0 * aR1; rxx += aR0 * aR0;
            }
            rhoT[h] = sxx > 0 ? Math.max(0, sxy / sxx) : 0;
            rhoRH[h] = rxx > 0 ? Math.max(0, ryy / rxx) : 0;
        }
    }

    // ---------------------------------------------------------------- prediction

    public double predictTemp(DataStore ds, int t, int l, int h) {
        LocalDateTime tau = DataStore.START.plusHours((long) t + h);
        int r = ds.rowAtClamped(t, l);
        double dev = ds.x[r][Cfg.F_AIR_T] - climT[l][ds.month[r]][ds.hour[r]];
        return climT[l][tau.getMonthValue() - 1][tau.getHour()] + rhoT[h] * dev;
    }

    public double predictRh(DataStore ds, int t, int l, int h) {
        LocalDateTime tau = DataStore.START.plusHours((long) t + h);
        int r = ds.rowAtClamped(t, l);
        double dev = ds.x[r][Cfg.F_RH] - climRH[l][ds.month[r]][ds.hour[r]];
        return Math.max(5, Math.min(100, climRH[l][tau.getMonthValue() - 1][tau.getHour()] + rhoRH[h] * dev));
    }

    public double[] predictProba(DataStore ds, int t, int l, int h) {
        double[] x = features(ds, t, l, h);
        return useNn && nn != null ? nn.predictProba(x) : gb.predictProba(x);
    }

    private static void say(Consumer<String> log, String message) { if (log != null) log.accept(message); }

    private static double macroF1(GradientBoostedModel model, double[][] x, int[] y) {
        int[][] cm = new int[Cfg.NC][Cfg.NC];
        for (int i = 0; i < x.length; i++) {
            double[] p = model.predictProba(x[i]); int b = 0;
            for (int c = 1; c < p.length; c++) if (p[c] > p[b]) b = c;
            cm[y[i]][b]++;
        }
        double sum = 0;
        for (int c = 0; c < Cfg.NC; c++) {
            double tp = cm[c][c], fp = 0, fn = 0;
            for (int j = 0; j < Cfg.NC; j++) if (j != c) { fp += cm[j][c]; fn += cm[c][j]; }
            double den = 2 * tp + fp + fn; sum += den == 0 ? 0 : 2 * tp / den;
        }
        return sum / Cfg.NC;
    }

    /** Full 24-hour forecast for all grid points, issued at hour index t. */
    public Forecast forecast(DataStore ds, int t) {
        Forecast f = new Forecast(ds.nLoc, t);
        for (int l = 0; l < ds.nLoc; l++) {
            for (int h = 1; h <= MAX_H; h++) {
                double[] p = predictProba(ds, t, l, h);
                int b = 0;
                double ea = 0;
                for (int c = 0; c < Cfg.NC; c++) { if (p[c] > p[b]) b = c; ea += p[c] * classMeanAnomaly[c]; }
                double T = predictTemp(ds, t, l, h), RH = predictRh(ds, t, l, h);
                f.proba[l][h - 1] = p; f.cls[l][h - 1] = b; f.expAnomaly[l][h - 1] = ea;
                f.tempC[l][h - 1] = T; f.rh[l][h - 1] = RH;
                f.adjHi[l][h - 1] = HeatRisk.adjusted(T, RH, ea);
                f.level[l][h - 1] = HeatRisk.level(f.adjHi[l][h - 1]);
                int rt = (t + h < ds.nHours) ? ds.rowAt[t + h][l] : -1;
                f.actual[l][h - 1] = rt < 0 ? -1 : ds.cls[rt];
            }
        }
        return f;
    }

    public static final class Forecast {
        public final int origin, nLoc;
        public final double[][][] proba;
        public final int[][] cls, level, actual;
        public final double[][] expAnomaly, tempC, rh, adjHi;
        Forecast(int nLoc, int origin) {
            this.nLoc = nLoc; this.origin = origin;
            proba = new double[nLoc][MAX_H][]; cls = new int[nLoc][MAX_H]; level = new int[nLoc][MAX_H];
            actual = new int[nLoc][MAX_H]; expAnomaly = new double[nLoc][MAX_H];
            tempC = new double[nLoc][MAX_H]; rh = new double[nLoc][MAX_H]; adjHi = new double[nLoc][MAX_H];
        }
    }

    // ---------------------------------------------------------------- evaluation

    public static final class Eval implements Serializable {
        private static final long serialVersionUID = 1L;
        public int[] horizons;
        public double[] acc, macroF1, adjAcc, persistAcc, yesterdayAcc, climAcc;
        public double[] maeT, maeTClim, maeTPersist, maeRh, maeRhClim, maeRhPersist;
        public int[] n;
    }

    public Eval evaluate(DataStore ds, int splitId, int[] horizons) {
        Eval e = new Eval();
        int H = horizons.length;
        e.horizons = horizons;
        e.acc = new double[H]; e.macroF1 = new double[H]; e.adjAcc = new double[H];
        e.persistAcc = new double[H]; e.yesterdayAcc = new double[H]; e.climAcc = new double[H];
        e.maeT = new double[H]; e.maeTClim = new double[H]; e.maeTPersist = new double[H];
        e.maeRh = new double[H]; e.maeRhClim = new double[H]; e.maeRhPersist = new double[H];
        e.n = new int[H];
        for (int hi = 0; hi < H; hi++) {
            int h = horizons[hi];
            int[][] cm = new int[Cfg.NC][Cfg.NC];
            long pers = 0, yest = 0, clim = 0, cnt = 0;
            double sT = 0, sTc = 0, sTp = 0, sR = 0, sRc = 0, sRp = 0;
            for (int t = 0; t + h < ds.nHours; t++) for (int l = 0; l < ds.nLoc; l++) {
                int rt = ds.rowAt[t + h][l];
                if (rt < 0 || ds.split[rt] != splitId) continue;
                int r0 = ds.rowAt[t][l];
                int y = ds.cls[rt];
                double[] p = predictProba(ds, t, l, h);
                int b = 0;
                for (int c = 1; c < Cfg.NC; c++) if (p[c] > p[b]) b = c;
                cm[y][b]++;
                cnt++;
                if (ds.cls[r0] == y) pers++;
                int ry = ds.rowAtClamped(t + h - 24, l);
                if (ds.cls[ry] == y) yest++;
                if (climClass[l][ds.month[rt]][ds.hour[rt]] == y) clim++;
                double T = ds.x[rt][Cfg.F_AIR_T], R = ds.x[rt][Cfg.F_RH];
                sT += Math.abs(predictTemp(ds, t, l, h) - T);
                sTc += Math.abs(climT[l][ds.month[rt]][ds.hour[rt]] - T);
                sTp += Math.abs(ds.x[r0][Cfg.F_AIR_T] - T);
                sR += Math.abs(predictRh(ds, t, l, h) - R);
                sRc += Math.abs(climRH[l][ds.month[rt]][ds.hour[rt]] - R);
                sRp += Math.abs(ds.x[r0][Cfg.F_RH] - R);
            }
            Metrics mt = new Metrics(cm);
            e.n[hi] = (int) cnt;
            e.acc[hi] = mt.accuracy(); e.macroF1[hi] = mt.macroF1(); e.adjAcc[hi] = mt.adjacentAccuracy();
            e.persistAcc[hi] = (double) pers / cnt; e.yesterdayAcc[hi] = (double) yest / cnt;
            e.climAcc[hi] = (double) clim / cnt;
            e.maeT[hi] = sT / cnt; e.maeTClim[hi] = sTc / cnt; e.maeTPersist[hi] = sTp / cnt;
            e.maeRh[hi] = sR / cnt; e.maeRhClim[hi] = sRc / cnt; e.maeRhPersist[hi] = sRp / cnt;
        }
        return e;
    }
}
