package org.example.analytics;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** The dashboard's global filter (date range, locations, classes, hours, months, heat-risk levels). */
public final class Filter {
    public LocalDate from = LocalDate.of(2024, 1, 1), to = LocalDate.of(2025, 12, 31);
    public boolean[] loc = new boolean[6], cls = new boolean[Cfg.NC], risk = new boolean[5], month = new boolean[12];
    /** UTC hour bins to keep; fromIdx/toIdx are positions in the chronological IST order (Cfg.hourAt). */
    public boolean[] hour = new boolean[24];
    public int fromIdx = 0, toIdx = 23;

    public Filter() {
        Arrays.fill(hour, true); Arrays.fill(loc, true); Arrays.fill(cls, true); Arrays.fill(risk, true); Arrays.fill(month, true);
    }

    public boolean hourOk(int h) { return hour[h]; }

    /** Select a window of hour bins in chronological IST order; from > to wraps through midnight IST. */
    public void setHourWindow(int from, int to) {
        fromIdx = from; toIdx = to;
        Arrays.fill(hour, false);
        int i = from;
        while (true) { hour[Cfg.hourAt(i % 24)] = true; if (i % 24 == to) break; i++; }
    }

    public int[] apply(DataStore ds) {
        int[] tmp = new int[ds.n];
        int c = 0;
        for (int i = 0; i < ds.n; i++) {
            if (!loc[ds.loc[i]] || !cls[ds.cls[i]] || !risk[ds.risk[i]] || !month[ds.month[i]] || !hourOk(ds.hour[i])) continue;
            LocalDate d = ds.time(ds.hourIdx[i]).toLocalDate();
            if (d.isBefore(from) || d.isAfter(to)) continue;
            tmp[c++] = i;
        }
        return Arrays.copyOf(tmp, c);
    }

    public String describe(DataStore ds) {
        List<String> p = new ArrayList<>();
        p.add("Dates " + from + " to " + to);
        p.add(fromIdx == 0 && toIdx == 23 ? "Hours all day" : "Hours " + Cfg.hourLabel(Cfg.hourAt(fromIdx)) + "-" + Cfg.hourLabel(Cfg.hourAt(toIdx) + 1) + " " + Cfg.TZ_NAME);
        p.add("Locations " + names(loc, ds.locShort));
        p.add("UHI classes " + names(cls, Cfg.CLASS_NAMES));
        p.add("Heat-risk " + names(risk, HeatRisk.LEVELS));
        p.add("Months " + names(month, new String[]{"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"}));
        return String.join("  |  ", p);
    }

    private static String names(boolean[] on, String[] n) {
        int c = 0;
        for (boolean b : on) if (b) c++;
        if (c == on.length) return "all";
        if (c == 0) return "none";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < on.length; i++) if (on[i]) { if (sb.length() > 0) sb.append(','); sb.append(n[i]); }
        return sb.toString();
    }
}
