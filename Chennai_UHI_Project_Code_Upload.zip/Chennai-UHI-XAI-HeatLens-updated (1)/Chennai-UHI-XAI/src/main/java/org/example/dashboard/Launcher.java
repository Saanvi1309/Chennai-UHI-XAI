package org.example.dashboard;

import javafx.application.Application;

/**
 * Run THIS class (not UHIDashboard) from IntelliJ - a plain main() avoids the
 * "JavaFX runtime components are missing" error. Or use:  mvn javafx:run
 */
public final class Launcher {
    public static void main(String[] args) { Application.launch(UHIDashboard.class, args); }
}
