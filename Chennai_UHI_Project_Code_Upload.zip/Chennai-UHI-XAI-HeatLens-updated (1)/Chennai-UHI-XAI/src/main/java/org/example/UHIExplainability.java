package org.example;
import ai.djl.Model;
import ai.djl.inference.Predictor;
import ai.djl.ndarray.NDArray;
import ai.djl.ndarray.NDList;
import ai.djl.ndarray.NDManager;
import ai.djl.nn.Block;
import ai.djl.nn.SequentialBlock;
import ai.djl.nn.core.Linear;
import ai.djl.nn.norm.Dropout;
import ai.djl.nn.Activation;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class UHIExplainability {

    // ============================================================
    // SETTINGS
    // ============================================================

    private static final int NUM_FEATURES = 28;
    private static final int NUM_CLASSES = 4;

    private static final int NUM_SAMPLES = 100;
    private static final int NUM_PERMUTATIONS = 20;

    private static final String TEST_FILE =
            "data/processed/test_scaled.csv";

    private static final String MODEL_DIRECTORY =
            "models";

    private static final String MODEL_NAME =
            "uhi-dnn";


    // ============================================================
    // FEATURE NAMES
    // ============================================================

    private static final String[] FEATURE_NAMES = {

            "latitude",
            "longitude",
            "air_temperature",
            "dew_point_temperature",
            "cloud_cover",
            "u10",
            "v10",
            "wind_speed",
            "wind_direction",
            "relative_humidity",
            "pressure",
            "rainfall",
            "red_band",
            "nir_band",
            "ndvi",
            "ndbi",
            "ndwi",
            "land_use_type",
            "elevation",
            "distance_to_coast",
            "distance_to_green_space",
            "distance_to_road",
            "distance_to_water",
            "building_density",
            "road_density",
            "spatial_match_distance_km",
            "dynamic_nearest_distance_km",
            "landsat_temporal_gap_days"
    };


    // ============================================================
    // CLASS NAMES
    // ============================================================

    private static final String[] CLASS_NAMES = {

            "Low",
            "Moderate",
            "High",
            "Extreme"
    };


    // ============================================================
    // MAIN
    // ============================================================

    public static void main(String[] args) throws Exception {

        System.out.println("======================================");
        System.out.println("UHI EXPLAINABILITY ANALYSIS");
        System.out.println("======================================");

        System.out.println();

        System.out.println(
                "Number of features : " + NUM_FEATURES
        );

        System.out.println(
                "Number of classes  : " + NUM_CLASSES
        );

        System.out.println(
                "Test samples       : " + NUM_SAMPLES
        );

        System.out.println(
                "Permutations       : " + NUM_PERMUTATIONS
        );


        // ========================================================
        // FEATURE LIST
        // ========================================================

        System.out.println();
        System.out.println("FEATURE LIST");
        System.out.println("--------------------------------------");

        for (int i = 0; i < FEATURE_NAMES.length; i++) {

            System.out.println(
                    (i + 1) + ". " + FEATURE_NAMES[i]
            );
        }


        // ========================================================
        // CLASS LIST
        // ========================================================

        System.out.println();
        System.out.println("CLASS LIST");
        System.out.println("--------------------------------------");

        for (int i = 0; i < CLASS_NAMES.length; i++) {

            System.out.println(
                    i + " = " + CLASS_NAMES[i]
            );
        }


        // ========================================================
        // CREATE THE EXACT SAME MODEL AS UHIModel.java
        // ========================================================

        System.out.println();
        System.out.println("Creating neural network...");

        Block network =
                new SequentialBlock()

                        .add(
                                Linear.builder()
                                        .setUnits(128)
                                        .build()
                        )

                        .add(
                                Activation::relu
                        )

                        .add(
                                Dropout.builder()
                                        .optRate(0.30f)
                                        .build()
                        )

                        .add(
                                Linear.builder()
                                        .setUnits(64)
                                        .build()
                        )

                        .add(
                                Activation::relu
                        )

                        .add(
                                Dropout.builder()
                                        .optRate(0.20f)
                                        .build()
                        )

                        .add(
                                Linear.builder()
                                        .setUnits(32)
                                        .build()
                        )

                        .add(
                                Activation::relu
                        )

                        .add(
                                Linear.builder()
                                        .setUnits(NUM_CLASSES)
                                        .build()
                        );


        // ========================================================
        // CREATE MODEL
        // ========================================================

        Model model =
                Model.newInstance(
                        "UHI-DNN"
                );

        model.setBlock(network);


        // ========================================================
        // LOAD TRAINED PARAMETERS
        // ========================================================

        Path modelDirectory =
                Path.of(
                        System.getProperty("user.dir"),
                        MODEL_DIRECTORY
                );

        System.out.println();
        System.out.println("Loading trained model...");

        model.load(
                modelDirectory,
                MODEL_NAME
        );

        System.out.println();
        System.out.println(
                "Trained model loaded successfully!"
        );

        System.out.println(
                "Input features : " + NUM_FEATURES
        );

        System.out.println(
                "Output classes : " + NUM_CLASSES
        );

        System.out.println();
        System.out.println(
                "XAI MODEL LOADING CHECK PASSED!"
        );


        // ========================================================
        // LOAD TEST DATA
        // ========================================================

        System.out.println();
        System.out.println("Loading test data...");

        List<float[]> testFeatures =
                new ArrayList<>();


        try (
                BufferedReader reader =
                        Files.newBufferedReader(
                                Path.of(TEST_FILE)
                        )
        ) {

            // Skip header

            reader.readLine();

            String line;


            while (
                    (line = reader.readLine())
                            != null
            ) {

                if (line.trim().isEmpty()) {
                    continue;
                }


                String[] values =
                        line.split(",");


                float[] features =
                        new float[NUM_FEATURES];


                for (
                        int i = 0;
                        i < NUM_FEATURES;
                        i++
                ) {

                    features[i] =
                            Float.parseFloat(
                                    values[i]
                            );
                }


                testFeatures.add(
                        features
                );
            }
        }


        System.out.println(
                "Test records loaded: "
                        + testFeatures.size()
        );


        // ========================================================
        // NUMBER OF SAMPLES
        // ========================================================

        int samplesToUse =
                Math.min(
                        NUM_SAMPLES,
                        testFeatures.size()
                );


        System.out.println(
                "Samples used for XAI: "
                        + samplesToUse
        );


        // ========================================================
        // GLOBAL IMPORTANCE
        // ========================================================

        double[] globalImportance =
                new double[NUM_FEATURES];


        Random random =
                new Random(42);


        // ========================================================
        // CREATE PREDICTOR
        // ========================================================

        try (

                NDManager manager =
                        NDManager.newBaseManager();

                Predictor<NDList, NDList> predictor =
                        model.newPredictor(

                                new ai.djl.translate.Translator<NDList, NDList>() {

                                    @Override
                                    public NDList processInput(
                                            ai.djl.translate.TranslatorContext ctx,
                                            NDList input
                                    ) {

                                        return input;
                                    }


                                    @Override
                                    public NDList processOutput(
                                            ai.djl.translate.TranslatorContext ctx,
                                            NDList output
                                    ) {

                                        return output;
                                    }
                                }
                        )
        ) {


            // ====================================================
            // PROCESS EACH TEST SAMPLE
            // ====================================================

            for (
                    int sampleIndex = 0;
                    sampleIndex < samplesToUse;
                    sampleIndex++
            ) {


                // ------------------------------------------------
                // Original sample
                // ------------------------------------------------

                float[] original =
                        testFeatures.get(
                                sampleIndex
                        );


                // ------------------------------------------------
                // Determine predicted class
                // ------------------------------------------------

                NDArray originalArray =
                        manager.create(
                                original
                        );


                originalArray =
                        originalArray.reshape(
                                1,
                                NUM_FEATURES
                        );


                NDList originalOutput =
                        predictor.predict(
                                new NDList(
                                        originalArray
                                )
                        );


                NDArray originalPrediction =
                        originalOutput
                                .singletonOrThrow();


                float[] probabilities =
                        originalPrediction
                                .softmax(1)
                                .toFloatArray();


                int predictedClass = 0;


                float highestProbability =
                        probabilities[0];


                for (
                        int c = 1;
                        c < NUM_CLASSES;
                        c++
                ) {

                    if (
                            probabilities[c]
                                    > highestProbability
                    ) {

                        highestProbability =
                                probabilities[c];

                        predictedClass =
                                c;
                    }
                }


                // ------------------------------------------------
                // Contributions for this sample
                // ------------------------------------------------

                double[] sampleContribution =
                        new double[NUM_FEATURES];


                // =================================================
                // MONTE CARLO PERMUTATIONS
                // =================================================

                for (
                        int permutationIndex = 0;
                        permutationIndex < NUM_PERMUTATIONS;
                        permutationIndex++
                ) {


                    // Create feature permutation

                    List<Integer> permutation =
                            new ArrayList<>();


                    for (
                            int f = 0;
                            f < NUM_FEATURES;
                            f++
                    ) {

                        permutation.add(f);
                    }


                    Collections.shuffle(
                            permutation,
                            random
                    );


                    // ------------------------------------------------
                    // Baseline
                    // ------------------------------------------------

                    float[] current =
                            new float[NUM_FEATURES];


                    Arrays.fill(
                            current,
                            0.0f
                    );


                    // ------------------------------------------------
                    // Baseline probability
                    // ------------------------------------------------

                    double previousProbability =
                            getClassProbability(
                                    predictor,
                                    manager,
                                    current,
                                    predictedClass
                            );


                    // ------------------------------------------------
                    // Add features one at a time
                    // ------------------------------------------------

                    for (
                            int position = 0;
                            position < NUM_FEATURES;
                            position++
                    ) {


                        int featureIndex =
                                permutation.get(
                                        position
                                );


                        current[featureIndex] =
                                original[
                                        featureIndex
                                        ];


                        double newProbability =
                                getClassProbability(
                                        predictor,
                                        manager,
                                        current,
                                        predictedClass
                                );


                        double marginalContribution =
                                newProbability
                                        - previousProbability;


                        sampleContribution[
                                featureIndex
                                ] +=
                                marginalContribution;


                        previousProbability =
                                newProbability;
                    }
                }


                // ------------------------------------------------
                // Average feature contributions
                // ------------------------------------------------

                for (
                        int f = 0;
                        f < NUM_FEATURES;
                        f++
                ) {

                    sampleContribution[f]
                            /=
                            NUM_PERMUTATIONS;


                    globalImportance[f]
                            +=
                            Math.abs(
                                    sampleContribution[f]
                            );
                }


                // ------------------------------------------------
                // Progress
                // ------------------------------------------------

                if (
                        (sampleIndex + 1) % 10
                                == 0
                ) {

                    System.out.println(
                            "Processed XAI sample "
                                    + (sampleIndex + 1)
                                    + " / "
                                    + samplesToUse
                    );
                }
            }
        }


        // ========================================================
        // AVERAGE GLOBAL IMPORTANCE
        // ========================================================

        for (
                int f = 0;
                f < NUM_FEATURES;
                f++
        ) {

            globalImportance[f]
                    /=
                    samplesToUse;
        }


        // ========================================================
        // RANK FEATURES
        // ========================================================

        List<Integer> ranking =
                new ArrayList<>();


        for (
                int f = 0;
                f < NUM_FEATURES;
                f++
        ) {

            ranking.add(f);
        }


        ranking.sort(
                (a, b) ->
                        Double.compare(
                                globalImportance[b],
                                globalImportance[a]
                        )
        );


        // ========================================================
        // PRINT GLOBAL IMPORTANCE
        // ========================================================

        System.out.println();
        System.out.println("======================================");
        System.out.println("GLOBAL FEATURE IMPORTANCE");
        System.out.println("======================================");

        System.out.println();

        System.out.println(
                "Rank | Feature | Mean Absolute Contribution"
        );

        System.out.println(
                "-----------------------------------------------"
        );


        for (
                int rank = 0;
                rank < NUM_FEATURES;
                rank++
        ) {

            int featureIndex =
                    ranking.get(rank);


            System.out.printf(
                    "%4d | %-34s | %.6f%n",
                    rank + 1,
                    FEATURE_NAMES[
                            featureIndex
                            ],
                    globalImportance[
                            featureIndex
                            ]
            );
        }


        // ========================================================
        // SAVE XAI RESULTS
        // ========================================================

        Path outputFile =
                Path.of(
                        System.getProperty("user.dir"),
                        "data",
                        "processed",
                        "UHI_XAI_Global_Importance.csv"
                );


        try (
                PrintWriter writer =
                        new PrintWriter(
                                outputFile.toFile()
                        )
        ) {

            writer.println(
                    "Rank,Feature,Mean_Absolute_Contribution"
            );


            for (
                    int rank = 0;
                    rank < NUM_FEATURES;
                    rank++
            ) {

                int featureIndex =
                        ranking.get(rank);


                writer.printf(
                        "%d,%s,%.6f%n",
                        rank + 1,
                        FEATURE_NAMES[
                                featureIndex
                                ],
                        globalImportance[
                                featureIndex
                                ]
                );
            }
        }


        // ========================================================
        // SUCCESS MESSAGE
        // ========================================================

        System.out.println();

        System.out.println(
                "XAI CSV saved to: "
                        + outputFile.toAbsolutePath()
        );


        System.out.println();

        System.out.println(
                "======================================"
        );

        System.out.println(
                "SHAP-STYLE ANALYSIS COMPLETED!"
        );

        System.out.println(
                "======================================"
        );


        model.close();
    }


    // ============================================================
    // GET CLASS PROBABILITY
    // ============================================================

    private static double getClassProbability(
            Predictor<NDList, NDList> predictor,
            NDManager manager,
            float[] features,
            int classIndex
    ) throws Exception {


        NDArray input =
                manager.create(
                        features
                );


        input =
                input.reshape(
                        1,
                        NUM_FEATURES
                );


        NDList output =
                predictor.predict(
                        new NDList(input)
                );


        NDArray logits =
                output.singletonOrThrow();


        float[] probabilities =
                logits
                        .softmax(1)
                        .toFloatArray();


        return probabilities[
                classIndex
                ];
    }
}