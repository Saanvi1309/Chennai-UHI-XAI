package org.example.dashboard;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import org.example.analytics.*;

import java.nio.file.Path;
import java.util.List;

/** Interactive Chennai UHI dashboard: overview, heat risk, 24 h forecast, mitigation simulator, model comparison, insights. */
public final class UHIDashboard extends Application {
    private Stage stage;
    private Scene scene;
    private AppState st;
    private Label status;

    @Override public void start(Stage stage) {
        this.stage = stage;
        stage.setTitle("Chennai HeatLens - UHI Intelligence");
        Label t = new Label("CHENNAI HEATLENS");
        t.setStyle("-fx-font-size: 26px; -fx-font-weight: bold;");
        Label log = new Label("Starting...");
        log.setWrapText(true);
        log.setMaxWidth(560);
        log.setStyle("-fx-text-fill: #CBD5E1;");
        ProgressBar pb = new ProgressBar();
        pb.setPrefWidth(360);
        VBox splash = new VBox(14, t, new Label("Loading data and models..."), pb, log);
        splash.setAlignment(Pos.CENTER);
        splash.getStyleClass().add("splash");
        scene = new Scene(splash, 1200, 760);
        scene.getStylesheets().add(css("/dashboard.css"));
        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.setMaximized(true);
        stage.show();

        Task<AppState> task = new Task<>() {
            @Override protected AppState call() throws Exception {
                updateMessage("Reading " + Cfg.data());
                DataStore ds = new DataStore(Cfg.data());
                ModelSuite ms = ModelSuite.loadOrTrain(ds, m -> updateMessage(m.trim()));
                updateMessage("Scoring validation and test hours with every model...");
                ms.computePredictions(ds);
                ms.writeResults(ds, Cfg.results());
                updateMessage("Preparing evaluation, XAI, hotspot and planning results (first start only)...");
                AnalysisRunner.ensure(ds, ms, m -> updateMessage(m.trim()));
                return new AppState(ds, ms);
            }
        };
        log.textProperty().bind(task.messageProperty());
        task.setOnSucceeded(e -> {
            st = task.getValue();
            buildMain();
        });
        task.setOnFailed(e -> {
            Throwable ex = task.getException();
            ex.printStackTrace();
            log.textProperty().unbind();
            log.setText("Could not start: " + ex + "\n\nExpected the data file at: " + Cfg.data()
                    + "\nRun the program from the project folder (the one containing data/ and models/).");
        });
        Thread th = new Thread(task, "uhi-loader");
        th.setDaemon(true);
        th.start();
    }

    private static String css(String res) { return UHIDashboard.class.getResource(res).toExternalForm(); }

    private void buildMain() {
        Label title = new Label("CHENNAI HEATLENS");
        title.getStyleClass().add("header-title");
        Label sub = new Label("UHI Intelligence  \u00B7  Deep Learning  \u00B7  Explainable AI  \u00B7  Urban Heat Analytics  \u00B7  all times in IST (data timestamps are UTC)");
        sub.getStyleClass().add("header-sub");
        Region sp = new Region();
        HBox.setHgrow(sp, Priority.ALWAYS);

        MenuButton export = new MenuButton("Export report");
        MenuItem pdf = new MenuItem("PDF report of this view"), csvSum = new MenuItem("CSV summary of this view"), csvRows = new MenuItem("CSV of the filtered hourly rows");
        pdf.setOnAction(e -> export("pdf"));
        csvSum.setOnAction(e -> export("summary"));
        csvRows.setOnAction(e -> export("rows"));
        export.getItems().addAll(pdf, csvSum, csvRows);
        ToggleButton theme = new ToggleButton("Dark mode");
        theme.getStyleClass().add("button");
        theme.selectedProperty().addListener((o, a, dark) -> {
            st.dark.set(dark);
            String d = css("/dark.css");
            if (dark) { if (!scene.getStylesheets().contains(d)) scene.getStylesheets().add(d); } else scene.getStylesheets().remove(d);
            st.refresh();
            if (st.forecast != null) st.setForecastOrigin(st.forecastOrigin);
        });
        HBox header = new HBox(14, new VBox(2, title, sub), sp, export, theme);
        header.setAlignment(Pos.CENTER_LEFT);
        header.getStyleClass().add("header-bar");

        FilterPanel filters = new FilterPanel(st);
        filters.setPrefWidth(270);
        filters.setMinWidth(220);
        filters.setMaxWidth(300);

        TabPane tabs = new TabPane();
        tabs.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        st.host = getHostServices();
        AnalysisReports.setTemperatures(st.ms);
        ForecastTab forecastTab = new ForecastTab(st);
        tabs.getTabs().addAll(
                tab("01 Overview", new OverviewTab(st)),
                tab("02 Heat Map", new HeatMapTab(st)),
                tab("03 DNN Prediction", Ui.tabs(new String[]{"DNN training & predictions", "24 h forecast", "Forecast validation"}, new DnnTab(st), forecastTab, new ForecastEvalTab(st))),
                tab("04 Model Evaluation", Ui.tabs(new String[]{"Performance analysis", "Filtered model comparison"}, new EvalTab(st), new ModelsTab(st))),
                tab("05 Explainable AI", new XaiTab(st)),
                tab("06 Heat Risk", Ui.tabs(new String[]{"Heat risk", "Alerts & insights"}, new HeatRiskTab(st), new InsightsTab(st))),
                tab("07 Urban Planning", new PlanningTab(st, new SimulatorTab(st))),
                tab("08 Reports", new ReportsTab(st)));

        status = new Label();
        HBox bar = new HBox(status);
        bar.getStyleClass().add("status-bar");
        st.onView(() -> status.setText(String.format("%,d hours in view  \u00B7  %s  \u00B7  models: %s  \u00B7  statistical model output, not an official warning",
                st.rows.length, st.filter.describe(st.ds), String.join(", ", st.ms.modelNames))));

        String pick = System.getProperty("uhi.tab");      // optional: open a given tab at start (used for testing)
        if (pick != null) tabs.getSelectionModel().select(Integer.parseInt(pick));
        if (Boolean.getBoolean("uhi.dark")) theme.setSelected(true);
        BorderPane root = new BorderPane();
        root.setMinWidth(0);
        tabs.setMinWidth(0);
        root.setTop(header);
        root.setLeft(filters);
        root.setCenter(tabs);
        root.setBottom(bar);
        scene.setRoot(root);
        st.setForecastOrigin(st.ds.nHours - 1);
        st.refresh();
    }

    private static Tab tab(String name, javafx.scene.Node n) {
        Tab t = new Tab(name, n);
        return t;
    }

    private void export(String kind) {
        final AppState s = st;
        Task<Path> task = new Task<>() {
            @Override protected Path call() throws Exception {
                String stamp = ReportExporter.stamp();
                Path dir = Cfg.exports();
                switch (kind) {
                    case "pdf": {
                        return ReportExporter.exportPdf(s.ds, s.ms, s.filter, s.rows, s.stats, s.viewInsights, s.forecast, s.forecastInsights, dir.resolve("uhi_report_" + stamp + ".pdf"));
                    }
                    case "summary": return ReportExporter.exportSummaryCsv(s.ds, s.filter, s.stats, dir.resolve("uhi_summary_" + stamp + ".csv"));
                    default: return ReportExporter.exportRowsCsv(s.ds, s.ms, s.rows, dir.resolve("uhi_filtered_rows_" + stamp + ".csv"));
                }
            }
        };
        task.setOnSucceeded(e -> {
            Path p = task.getValue();
            ButtonType open = new ButtonType("Open file"), folder = new ButtonType("Show folder"), close = new ButtonType("Close", ButtonBar.ButtonData.CANCEL_CLOSE);
            Alert a = new Alert(Alert.AlertType.INFORMATION, "Saved to:\n" + p, open, folder, close);
            a.setTitle("Export complete");
            a.setHeaderText("Your report is ready");
            a.initOwner(stage);
            a.showAndWait().ifPresent(b -> {
                try {
                    if (b == open) getHostServices().showDocument(p.toUri().toString());
                    else if (b == folder) getHostServices().showDocument(p.getParent().toUri().toString());
                } catch (Exception ignored) { }
            });
        });
        task.setOnFailed(e -> {
            task.getException().printStackTrace();
            Alert a = new Alert(Alert.AlertType.ERROR, "Export failed: " + task.getException());
            a.initOwner(stage);
            a.show();
        });
        Thread th = new Thread(task, "uhi-export");
        th.setDaemon(true);
        th.start();
    }

    public static void main(String[] args) { launch(args); }
}
