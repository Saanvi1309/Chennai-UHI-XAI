package org.example.dashboard;

import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.ScatterChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import org.example.analytics.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Explainable AI page: global importance, SHAP-style summary, dependence, Low-vs-Extreme comparison and local explanations. */
final class XaiTab extends ScrollPane {
    private final AppState st;
    private final Canvas globalC = new Canvas(760, 400), summaryC = new Canvas(760, 420), waterC = new Canvas(760, 330);
    private final ComboBox<String> depFeature = new ComboBox<>(), locBox = new ComboBox<>(), hourBox = new ComboBox<>(), classBox = new ComboBox<>(), modelBox = new ComboBox<>();
    private final DatePicker date = new DatePicker();
    private final ScatterChart<Number, Number> dep = new ScatterChart<>(new NumberAxis(), new NumberAxis());
    private final Label narrative = Ui.note(""), localTitle = Ui.label("", "card-title");
    private final TableView<String[]> top5 = Ui.table(new String[]{"Rank", "Feature", "Value", "Shapley (pp)", "Effect"}, new double[]{50, 190, 100, 100, 160});
    private final List<String[]> samples = Results.body("xai_summary_samples.csv");
    private Xai.Explanation current;
    private double[][] bg;

    XaiTab(AppState st) {
        this.st = st;
        DataStore ds = st.ds;
        Label how = Ui.note("Monte-Carlo Shapley values are computed directly on the trained DNN weights (not a surrogate model): the explained quantity is the model's probability of a class, "
                + "attributions add up exactly to that probability minus its background average, and a deletion test (table below) checks that the top-ranked features really matter to the model. "
                + "Location features (coordinates, land use, distances, densities) are constant per grid point, so their credit mostly reflects location identity, not a causal effect. Global plots use 300 test-period hours; local explanations use 100 permutations.");
        how.getStyleClass().add("banner");

        for (String f : Cfg.FEATURES) depFeature.getItems().add(f);
        depFeature.setValue("air_temperature");
        depFeature.valueProperty().addListener((o, a, b) -> drawDependence());
        dep.setAnimated(false); dep.setLegendVisible(false); dep.setPrefHeight(320);
        ((NumberAxis) dep.getYAxis()).setLabel("Shapley value (probability points)");

        VBox cGlobal = Ui.pngCard("Global feature importance", "Mean |Shapley value| over 300 test hours (probability points of the predicted class); colour = feature group.", globalC, "xai_global_importance");
        VBox cSummary = Ui.pngCard("SHAP-style summary", "Each dot is one hour: position = push on the predicted class probability, colour = feature value (blue low, red high).", summaryC, "xai_summary");
        VBox cDep = Ui.card("Feature dependence", "How the model output moves with one feature's value (each dot = one explained hour).", new VBox(6, depFeature, dep));
        TableView<String[]> grp = Ui.csvTable("xai_group_importance.csv", new int[]{0, 1, 2}, new String[]{"Feature group", "Sum of mean |phi|", "Share"}, new double[]{220, 120, 90}, null);
        grp.getItems().forEach(r -> r[2] = Ui.p1(r[2]));
        TableView<String[]> faith = Ui.csvTable("xai_faithfulness.csv", new int[]{0, 1, 2}, new String[]{"Features removed (k)", "Prob. drop: top-k by Shapley", "Prob. drop: random k"}, new double[]{130, 190, 170}, null);
        VBox cFaith = Ui.card("Faithfulness check (deletion test)", "Replacing the top-ranked features by background values should lower the class probability far more than replacing random ones.", new VBox(8, grp, faith));
        TableView<String[]> lvx = Ui.csvTable("xai_low_vs_extreme.csv", new int[]{0, 1, 2, 3}, new String[]{"Feature", "Actual Low rows", "Actual Extreme rows", "Difference"},
                new double[]{200, 130, 150, 110}, null);
        List<String[]> top = new ArrayList<>(lvx.getItems());
        top.sort((a, b) -> Double.compare(Math.abs(Results.num(b[3])), Math.abs(Results.num(a[3]))));
        for (String[] r : top) for (int i = 1; i < 4; i++) r[i] = Ui.num(Results.num(r[i]) * 100, 1);
        Ui.fill(lvx, top.subList(0, Math.min(10, top.size())));
        VBox cLvx = Ui.card("Low vs Extreme UHI: what pushes the model towards Extreme?", "Mean Shapley value (probability points) for P(Extreme) over 60 actual-Low and 60 actual-Extreme hours; top 10 by difference.", lvx);

        // local explanation controls
        for (int l = 0; l < ds.nLoc; l++) locBox.getItems().add(ds.locName[l]);
        locBox.getSelectionModel().select(3);
        for (int i = 0; i < 24; i++) { int u = Cfg.hourAt(i); hourBox.getItems().add(String.format("%02d:00 UTC (%s IST)", u, Cfg.hourLabel(u))); }
        hourBox.getSelectionModel().select(14);
        classBox.getItems().addAll("Predicted class", "Low", "Moderate", "High", "Extreme");
        classBox.getSelectionModel().select(0);
        for (String n : st.ms.modelNames) if (n.startsWith("DNN")) modelBox.getItems().add(n);
        modelBox.setValue(st.ms.primary.name());
        LocalDate dmin = ds.time(0).toLocalDate(), dmax = ds.time(ds.nHours - 1).toLocalDate();
        date.setValue(LocalDate.of(2025, 10, 28));
        date.setDayCellFactory(p -> new DateCell() { @Override public void updateItem(LocalDate x, boolean e) { super.updateItem(x, e); setDisable(e || x.isBefore(dmin) || x.isAfter(dmax)); } });
        Button go = new Button("Explain this hour");
        go.setOnAction(e -> explainSelected());
        Button extreme = new Button("Pick an Extreme-UHI test hour");
        extreme.getStyleClass().add("ghost-button");
        extreme.setOnAction(e -> pickExtreme());
        Button report = new Button("Generate explanation report (PDF)");
        report.setOnAction(e -> {
            if (current == null) explainSelected();
            final Xai.Explanation ex = current;
            final UhiClassifier m = st.ms.byName(modelBox.getValue());
            AnalysisReports.setTemperatures(st.ms);
            Ui.runExport(st, this, () -> AnalysisReports.xaiReportPdf(st.ds, st.ms, m, ex, Cfg.exports().resolve("xai_report_" + st.ds.locShort[st.ds.loc[ex.row()]] + "_" + ReportExporter.stamp() + ".pdf")));
        });
        HBox controls = new HBox(10, new Label("Model"), modelBox, new Label("Point"), locBox, new Label("UTC date"), date, hourBox, new Label("Explain"), classBox);
        controls.setAlignment(Pos.CENTER_LEFT);
        HBox buttons = new HBox(10, go, extreme, report);
        VBox local = Ui.card("Local explanation (select a location and hour)", "Why does the model give this prediction? Waterfall = how each feature moves the probability from the average to the prediction.",
                new VBox(8, controls, buttons, localTitle, narrative, waterC, Ui.label("Top five contributing features", "card-sub"), top5));
        Button pngW = new Button("Save waterfall PNG");
        pngW.getStyleClass().add("ghost-button");
        pngW.setOnAction(e -> { try { new Alert(Alert.AlertType.INFORMATION, "Saved to:\n" + Ui.savePng(waterC, "xai_waterfall")).show(); } catch (Exception ex) { new Alert(Alert.AlertType.ERROR, "" + ex).show(); } });
        local.getChildren().add(pngW);

        setContent(Ui.page(how, local, cGlobal, cSummary, Ui.row(cDep, cFaith), cLvx));
        setFitToWidth(true);
        getStyleClass().add("page-scroll");
        st.dark.addListener((o, a, b) -> { drawGlobal(); drawSummary(); drawWaterfall(); });
        drawGlobal(); drawSummary(); drawDependence();
        pickExtreme();
    }

    private void pickExtreme() {
        DataStore ds = st.ds;
        int pick = -1;
        for (int i = ds.n - 1; i >= 0; i--) if (ds.split[i] == 2 && ds.cls[i] == 3 && ds.loc[i] == 3 && ds.hour[i] == 8) { pick = i; break; }
        if (pick < 0) return;
        LocalDateTime t = ds.time(ds.hourIdx[pick]);
        date.setValue(t.toLocalDate());
        locBox.getSelectionModel().select(ds.loc[pick]);
        for (int i = 0; i < 24; i++) if (Cfg.hourAt(i) == t.getHour()) hourBox.getSelectionModel().select(i);
        explainSelected();
    }

    private void explainSelected() {
        DataStore ds = st.ds;
        int l = Math.max(0, locBox.getSelectionModel().getSelectedIndex());
        int utcHour = Cfg.hourAt(Math.max(0, hourBox.getSelectionModel().getSelectedIndex()));
        LocalDateTime t = date.getValue().atTime(utcHour, 0);
        int hi = (int) ChronoUnit.HOURS.between(DataStore.START, t);
        if (hi < 0 || hi >= ds.nHours || ds.rowAt[hi][l] < 0) { localTitle.setText("No observation for that point and hour."); return; }
        int row = ds.rowAt[hi][l];
        UhiClassifier m = st.ms.byName(modelBox.getValue());
        if (bg == null) bg = Xai.background(ds, st.ms.scaler, 200);
        int target = classBox.getSelectionModel().getSelectedIndex() - 1;
        current = Xai.explain(m, ds, st.ms.scaler, row, target, bg, 100, 7);
        st.xaiRow = row;
        localTitle.setText(String.format(Locale.ROOT, "%s  |  %s IST  |  actual class %s  |  model prediction %s (%.0f%%)", ds.locName[l],
                Cfg.local(ds.time(ds.hourIdx[row])), Cfg.CLASS_NAMES[ds.cls[row]], Cfg.CLASS_NAMES[current.predictedClass()], current.proba()[current.predictedClass()] * 100));
        narrative.setText(Xai.narrative(current, ds, 5));
        Integer[] rk = current.ranked();
        List<String[]> rows = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            int f = rk[i];
            rows.add(new String[]{String.valueOf(i + 1), Cfg.prettyFeature(Cfg.FEATURES[f]), Xai.fmt(current.raw()[f]), String.format(Locale.ROOT, "%+.1f", current.phi()[f] * 100),
                    current.phi()[f] >= 0 ? "raises P(" + Cfg.CLASS_NAMES[current.explainedClass()] + ")" : "lowers P(" + Cfg.CLASS_NAMES[current.explainedClass()] + ")"});
        }
        Ui.fill(top5, rows);
        drawWaterfall();
    }

    // ------------------------------------------------------------------ drawing

    private Color ink() { return st.dark.get() ? Color.web("#E5E7EB") : Color.web("#111827"); }
    private Color muted() { return st.dark.get() ? Color.web("#94A3B8") : Color.web("#6B7280"); }

    private static Color groupColor(String g) { return g.startsWith("Weather") ? Color.web("#1F77B4") : g.startsWith("Vegetation") ? Color.web("#2CA02C") : g.startsWith("Location") ? Color.web("#FF7F0E") : Color.web("#9467BD"); }

    private void drawGlobal() {
        GraphicsContext g = globalC.getGraphicsContext2D();
        g.clearRect(0, 0, globalC.getWidth(), globalC.getHeight());
        List<String[]> gi = Results.body("xai_global_importance.csv");
        int n = Math.min(15, gi.size());
        if (n == 0) { g.setFill(muted()); g.fillText("Run AnalysisRunner to create results/xai_global_importance.csv", 20, 30); return; }
        double max = 0;
        for (int i = 0; i < n; i++) max = Math.max(max, Results.num(gi.get(i)[3]));
        for (int i = 0; i < n; i++) {
            double v = Results.num(gi.get(i)[3]), y = 14 + i * 22, w = v / max * 430;
            g.setFill(ink()); g.setFont(Font.font(11)); g.setTextAlign(TextAlignment.RIGHT);
            g.fillText(Cfg.prettyFeature(gi.get(i)[1]), 200, y + 12);
            g.setFill(groupColor(gi.get(i)[2]));
            g.fillRect(208, y, w, 16);
            g.setFill(muted()); g.setTextAlign(TextAlignment.LEFT);
            g.fillText(String.format(Locale.ROOT, "%.1f pp", v * 100), 214 + w, y + 12);
        }
        String[] names = {"Weather", "Vegetation / spectral", "Location & land form (static)", "Data-matching metadata"};
        double lx = 14;
        for (String nm : names) { g.setFill(groupColor(nm)); g.fillRect(lx, 372, 10, 10); g.setFill(muted()); g.setTextAlign(TextAlignment.LEFT); g.fillText(nm, lx + 14, 381); lx += 30 + nm.length() * 6.4; }
    }

    private void drawSummary() {
        GraphicsContext g = summaryC.getGraphicsContext2D();
        double W = summaryC.getWidth(), H = summaryC.getHeight();
        g.clearRect(0, 0, W, H);
        List<String[]> gi = Results.body("xai_global_importance.csv");
        if (gi.isEmpty() || samples.isEmpty()) return;
        int nf = Math.min(12, gi.size());
        double maxAbs = 0;
        for (String[] r : samples) maxAbs = Math.max(maxAbs, Math.abs(Results.num(r[8])));
        double x0 = W / 2 + 60, scale = (W / 2 - 100) / Math.max(1e-9, maxAbs);
        double rowH = (H - 40) / nf;
        g.setStroke(muted()); g.setLineWidth(0.6);
        g.strokeLine(x0, 6, x0, H - 28);
        java.util.Map<String, int[]> idx = new java.util.HashMap<>();
        for (int i = 0; i < nf; i++) idx.put(gi.get(i)[1], new int[]{i});
        // per-feature min/max of scaled values for colouring
        double[] mn = new double[nf], mx = new double[nf];
        java.util.Arrays.fill(mn, 1e9); java.util.Arrays.fill(mx, -1e9);
        for (String[] r : samples) { int[] k = idx.get(r[5]); if (k == null) continue; double v = Results.num(r[7]); mn[k[0]] = Math.min(mn[k[0]], v); mx[k[0]] = Math.max(mx[k[0]], v); }
        for (int i = 0; i < nf; i++) {
            g.setFill(ink()); g.setFont(Font.font(11)); g.setTextAlign(TextAlignment.RIGHT);
            g.fillText(Cfg.prettyFeature(gi.get(i)[1]), 190, 10 + i * rowH + rowH / 2 + 4);
        }
        int c = 0;
        for (String[] r : samples) {
            int[] k = idx.get(r[5]);
            if (k == null) continue;
            double phi = Results.num(r[8]), v = Results.num(r[7]);
            double t = mx[k[0]] - mn[k[0]] < 1e-9 ? 0.5 : (v - mn[k[0]]) / (mx[k[0]] - mn[k[0]]);
            double jitter = ((c++ * 37) % 100) / 100.0 - 0.5;
            g.setFill(Color.color(0.15 + 0.8 * t, 0.35, 0.95 - 0.8 * t, 0.7));
            g.fillOval(x0 + phi * scale - 2.5, 10 + k[0] * rowH + rowH / 2 + jitter * (rowH - 6) - 2.5, 5, 5);
        }
        g.setFill(muted()); g.setTextAlign(TextAlignment.CENTER); g.setFont(Font.font(10));
        g.fillText("negative push", x0 - W / 4, H - 10); g.fillText("0", x0, H - 10); g.fillText("positive push", x0 + W / 4, H - 10);
    }

    private void drawDependence() {
        String f = depFeature.getValue();
        XYChart.Series<Number, Number> s = new XYChart.Series<>();
        for (String[] r : samples) if (r[5].equals(f)) s.getData().add(new XYChart.Data<>(Results.num(r[6]), Results.num(r[8])));
        dep.getData().setAll(List.of(s));
        ((NumberAxis) dep.getXAxis()).setLabel(Cfg.prettyFeature(f));
        ((NumberAxis) dep.getXAxis()).setForceZeroInRange(false);
    }

    private void drawWaterfall() {
        GraphicsContext g = waterC.getGraphicsContext2D();
        double W = waterC.getWidth();
        g.clearRect(0, 0, W, waterC.getHeight());
        if (current == null) return;
        Xai.Explanation e = current;
        Integer[] rk = e.ranked();
        int show = 10, n = show + 1;
        double rest = 0;
        for (int i = show; i < rk.length; i++) rest += e.phi()[rk[i]];
        double cum = e.baseline(), min = cum, max = cum, c = cum;
        for (int i = 0; i < n; i++) { c += i < show ? e.phi()[rk[i]] : rest; min = Math.min(min, c); max = Math.max(max, c); }
        double span = Math.max(1e-6, max - min) * 1.2, lo = min - span * 0.06, left = 250, avail = W - 340;
        g.setTextAlign(TextAlignment.LEFT); g.setFont(Font.font(11)); g.setFill(muted());
        g.fillText(String.format(Locale.ROOT, "average P(%s) = %.0f%%", Cfg.CLASS_NAMES[e.explainedClass()], e.baseline() * 100), 10, 14);
        for (int i = 0; i < n; i++) {
            double v = i < show ? e.phi()[rk[i]] : rest, y = 26 + i * 26;
            String label = i < show ? Cfg.prettyFeature(Cfg.FEATURES[rk[i]]) + " = " + Xai.fmt(e.raw()[rk[i]]) : "other " + (rk.length - show) + " features";
            g.setFill(ink()); g.setTextAlign(TextAlignment.RIGHT); g.fillText(label, left - 8, y + 14);
            double x1 = left + (cum - lo) / span * avail, x2 = left + (cum + v - lo) / span * avail;
            g.setFill(v >= 0 ? Color.web("#D62828") : Color.web("#2E86C1"));
            g.fillRect(Math.min(x1, x2), y, Math.max(2, Math.abs(x2 - x1)), 18);
            g.setFill(muted()); g.setTextAlign(TextAlignment.LEFT);
            g.fillText(String.format(Locale.ROOT, "%+.1f pp", v * 100), Math.max(x1, x2) + 6, y + 14);
            cum += v;
        }
        double ex = left + (e.prediction() - lo) / span * avail;
        g.setStroke(ink()); g.setLineWidth(1.2);
        g.strokeLine(ex, 20, ex, 26 + n * 26);
        g.setFill(ink()); g.setTextAlign(TextAlignment.CENTER); g.setFont(Font.font("System", FontWeight.BOLD, 11));
        g.fillText(String.format(Locale.ROOT, "prediction P = %.0f%%", e.prediction() * 100), Math.min(ex, W - 80), 26 + n * 26 + 16);
    }
}
