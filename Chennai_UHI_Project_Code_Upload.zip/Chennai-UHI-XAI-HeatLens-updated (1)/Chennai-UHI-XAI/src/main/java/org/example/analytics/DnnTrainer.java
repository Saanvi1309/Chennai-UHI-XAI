package org.example.analytics;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.function.Consumer;

/**
 * Trains {@link TunedDnn}. Everything that is used to choose between configurations (early stopping, LR plateau,
 * model selection) uses the VALIDATION split only; the test split is never touched in this class.
 */
public final class DnnTrainer {
    private DnnTrainer() {}

    public static final class Hyper implements Serializable {
        private static final long serialVersionUID = 1L;
        public String id;
        public double lr = 1e-3, weightDecay = 0;
        public int batch = 128, maxEpochs = 40, patience = 6;
        public double[] dropout = {0.30, 0.20, 0.0};     // after hidden layer 1, 2, 3 (DJL model: 0.30, 0.20, none)
        public String schedule = "fixed";               // fixed | plateau | cosine | step
        public boolean classWeights = false;
        public long seed = 42;

        public Hyper(String id) { this.id = id; }

        public String describe() {
            return String.format(Locale.ROOT, "lr=%.4g batch=%d dropout=%.2f/%.2f/%.2f schedule=%s weightDecay=%.0e classWeights=%s",
                    lr, batch, dropout[0], dropout[1], dropout[2], schedule, weightDecay, classWeights);
        }
    }

    public record Epoch(int epoch, double lr, double trainLoss, double trainAcc, double valLoss, double valAcc) {}

    public record Outcome(TunedDnn model, Hyper hyper, List<Epoch> history, int bestEpoch, double valLoss, double valAcc,
                          double valMacroF1, double seconds) {}

    /** The search grid: the existing architecture is kept; only training hyper-parameters change. */
    public static List<Hyper> grid() {
        List<Hyper> g = new ArrayList<>();
        Hyper a = new Hyper("A_djl_like");             // same settings as UHITrainer (fixed lr 1e-3, batch 128) + early stopping
        g.add(a);
        Hyper b = new Hyper("B_plateau"); b.schedule = "plateau"; g.add(b);
        Hyper c = new Hyper("C_cosine_b256"); c.lr = 2e-3; c.batch = 256; c.schedule = "cosine"; g.add(c);
        Hyper d = new Hyper("D_lowdrop"); d.dropout = new double[]{0.15, 0.10, 0.0}; d.schedule = "plateau"; g.add(d);
        Hyper e = new Hyper("E_highdrop"); e.dropout = new double[]{0.40, 0.30, 0.10}; e.schedule = "plateau"; g.add(e);
        Hyper f = new Hyper("F_wd_plateau"); f.weightDecay = 1e-4; f.dropout = new double[]{0.25, 0.15, 0.0}; f.schedule = "plateau"; g.add(f);
        Hyper h = new Hyper("G_classweights"); h.classWeights = true; h.schedule = "plateau"; g.add(h);
        return g;
    }

    public static Outcome train(double[][] xtr, int[] ytr, double[][] xva, int[] yva, Hyper hp, Consumer<String> log) {
        long t0 = System.nanoTime();
        int nIn = xtr[0].length, K = Cfg.NC;
        int[] sizes = {nIn, 128, 64, 32, K};
        Random rnd = new Random(hp.seed);
        TunedDnn net = new TunedDnn(sizes, rnd);
        int L = sizes.length - 1;

        double[] cw = new double[K];
        java.util.Arrays.fill(cw, 1.0);
        if (hp.classWeights) {
            long[] cnt = new long[K];
            for (int y : ytr) cnt[y]++;
            for (int k = 0; k < K; k++) cw[k] = (double) ytr.length / (K * Math.max(1, cnt[k]));
        }

        // Adam state
        float[][][] mW = zerosW(net), vW = zerosW(net), gW = zerosW(net);
        float[][] mB = zerosB(net), vB = zerosB(net), gB = zerosB(net);
        long step = 0;
        final double b1 = 0.9, b2 = 0.999, eps = 1e-8;

        int n = xtr.length;
        int[] order = new int[n];
        for (int i = 0; i < n; i++) order[i] = i;
        // fixed eval-mode subsample of the training set for the training curves
        int nSub = Math.min(10000, n);
        int[] sub = new int[nSub];
        for (int i = 0; i < nSub; i++) sub[i] = (int) ((long) i * n / nSub);

        float[][] act = new float[L + 1][];
        for (int l = 0; l <= L; l++) act[l] = new float[sizes[l]];
        float[][] mask = new float[L][];
        for (int l = 0; l < L - 1; l++) mask[l] = new float[sizes[l + 1]];
        float[][] delta = new float[L][];
        for (int l = 0; l < L; l++) delta[l] = new float[sizes[l + 1]];

        List<Epoch> hist = new ArrayList<>();
        TunedDnn best = null;
        double bestLoss = Double.POSITIVE_INFINITY;
        int bestEpoch = 0, stale = 0, plateauStale = 0;
        double lr = hp.lr, plateauBest = Double.POSITIVE_INFINITY;

        for (int ep = 1; ep <= hp.maxEpochs; ep++) {
            switch (hp.schedule) {
                case "cosine" -> lr = hp.lr * (0.05 + 0.95 * 0.5 * (1 + Math.cos(Math.PI * (ep - 1) / hp.maxEpochs)));
                case "step" -> lr = hp.lr * Math.pow(0.5, (ep - 1) / 8);
                default -> { }
            }
            for (int i = n - 1; i > 0; i--) { int j = rnd.nextInt(i + 1); int t = order[i]; order[i] = order[j]; order[j] = t; }
            for (int s = 0; s < n; s += hp.batch) {
                int e = Math.min(n, s + hp.batch);
                zero(gW, gB);
                double wsum = 0;
                for (int q = s; q < e; q++) {
                    int idx = order[q];
                    float[] x = act[0];
                    double[] xi = xtr[idx];
                    for (int i = 0; i < nIn; i++) x[i] = (float) xi[i];
                    // forward with inverted dropout
                    for (int l = 0; l < L; l++) {
                        float[] in = act[l], out = act[l + 1];
                        for (int o = 0; o < out.length; o++) {
                            float sum = net.b[l][o];
                            float[] row = net.w[l][o];
                            for (int i = 0; i < row.length; i++) sum += row[i] * in[i];
                            out[o] = (l < L - 1 && sum < 0) ? 0f : sum;
                        }
                        if (l < L - 1 && hp.dropout[l] > 0) {
                            double keep = 1 - hp.dropout[l];
                            for (int o = 0; o < out.length; o++) {
                                mask[l][o] = rnd.nextDouble() < keep ? (float) (1 / keep) : 0f;
                                out[o] *= mask[l][o];
                            }
                        } else if (l < L - 1) java.util.Arrays.fill(mask[l], 1f);
                    }
                    double[] p = softmax(act[L]);
                    int y = ytr[idx];
                    double wt = cw[y];
                    wsum += wt;
                    for (int k = 0; k < K; k++) delta[L - 1][k] = (float) (wt * (p[k] - (k == y ? 1 : 0)));
                    // backward
                    for (int l = L - 1; l >= 0; l--) {
                        float[] in = act[l];
                        for (int o = 0; o < sizes[l + 1]; o++) {
                            float d = delta[l][o];
                            if (d == 0f) continue;
                            gB[l][o] += d;
                            float[] g = gW[l][o];
                            for (int i = 0; i < g.length; i++) g[i] += d * in[i];
                        }
                        if (l > 0) {
                            float[] prev = delta[l - 1];
                            java.util.Arrays.fill(prev, 0f);
                            for (int o = 0; o < sizes[l + 1]; o++) {
                                float d = delta[l][o];
                                if (d == 0f) continue;
                                float[] row = net.w[l][o];
                                for (int i = 0; i < row.length; i++) prev[i] += d * row[i];
                            }
                            // through ReLU of layer l-1 output (act[l]) and its dropout mask
                            for (int i = 0; i < prev.length; i++) prev[i] = (act[l][i] > 0 ? prev[i] : 0f) * mask[l - 1][i];
                        }
                    }
                }
                // Adam update (gradients averaged over the weighted batch)
                step++;
                double c1 = 1 - Math.pow(b1, step), c2 = 1 - Math.pow(b2, step);
                float inv = (float) (1.0 / Math.max(1e-9, wsum));
                for (int l = 0; l < L; l++) {
                    for (int o = 0; o < sizes[l + 1]; o++) {
                        float[] wr = net.w[l][o], g = gW[l][o], m = mW[l][o], v = vW[l][o];
                        for (int i = 0; i < wr.length; i++) {
                            float gi = g[i] * inv + (float) (hp.weightDecay * wr[i]);
                            m[i] = (float) (b1 * m[i] + (1 - b1) * gi);
                            v[i] = (float) (b2 * v[i] + (1 - b2) * gi * gi);
                            wr[i] -= (float) (lr * (m[i] / c1) / (Math.sqrt(v[i] / c2) + eps));
                        }
                        float gb = gB[l][o] * inv;
                        mB[l][o] = (float) (b1 * mB[l][o] + (1 - b1) * gb);
                        vB[l][o] = (float) (b2 * vB[l][o] + (1 - b2) * gb * gb);
                        net.b[l][o] -= (float) (lr * (mB[l][o] / c1) / (Math.sqrt(vB[l][o] / c2) + eps));
                    }
                }
            }
            double[] tr = evalSubset(net, xtr, ytr, sub), va = eval(net, xva, yva);
            hist.add(new Epoch(ep, lr, tr[0], tr[1], va[0], va[1]));
            if (log != null) log.accept(String.format(Locale.ROOT, "  [%s] epoch %2d lr %.5f  train loss %.4f acc %.3f | val loss %.4f acc %.3f",
                    hp.id, ep, lr, tr[0], tr[1], va[0], va[1]));
            if (va[0] < bestLoss - 1e-4) { bestLoss = va[0]; bestEpoch = ep; stale = 0; best = net.copyWeights(); } else stale++;
            if ("plateau".equals(hp.schedule)) {
                if (va[0] < plateauBest - 1e-4) { plateauBest = va[0]; plateauStale = 0; }
                else if (++plateauStale >= 2) { lr *= 0.5; plateauStale = 0; }
            }
            if (stale >= hp.patience) break;
        }
        if (best != null) net.loadWeights(best);
        double[] va = eval(net, xva, yva);
        int[] pred = new int[yva.length];
        for (int i = 0; i < yva.length; i++) pred[i] = net.predict(xva[i]);
        double f1 = Metrics.of(yva, pred, K).macroF1();
        double sec = (System.nanoTime() - t0) / 1e9;
        net.hyper = hp; net.trainSeconds = sec; net.bestEpoch = bestEpoch;
        int H = hist.size();
        net.histLr = new double[H]; net.histTrainLoss = new double[H]; net.histTrainAcc = new double[H];
        net.histValLoss = new double[H]; net.histValAcc = new double[H];
        for (int i = 0; i < H; i++) {
            Epoch e = hist.get(i);
            net.histLr[i] = e.lr(); net.histTrainLoss[i] = e.trainLoss(); net.histTrainAcc[i] = e.trainAcc();
            net.histValLoss[i] = e.valLoss(); net.histValAcc[i] = e.valAcc();
        }
        return new Outcome(net, hp, hist, bestEpoch, va[0], va[1], f1, sec);
    }

    private static double[] eval(TunedDnn m, double[][] x, int[] y) {
        int[] all = new int[x.length];
        for (int i = 0; i < all.length; i++) all[i] = i;
        return evalSubset(m, x, y, all);
    }

    private static double[] evalSubset(TunedDnn m, double[][] x, int[] y, int[] idx) {
        double loss = 0; int ok = 0;
        for (int i : idx) {
            double[] p = m.predictProba(x[i]);
            loss -= Math.log(Math.max(p[y[i]], 1e-12));
            int b = 0;
            for (int c = 1; c < p.length; c++) if (p[c] > p[b]) b = c;
            if (b == y[i]) ok++;
        }
        return new double[]{loss / idx.length, (double) ok / idx.length};
    }

    private static double[] softmax(float[] z) {
        double[] p = new double[z.length];
        double mx = Double.NEGATIVE_INFINITY;
        for (float v : z) mx = Math.max(mx, v);
        double s = 0;
        for (int i = 0; i < z.length; i++) { p[i] = Math.exp(z[i] - mx); s += p[i]; }
        for (int i = 0; i < z.length; i++) p[i] /= s;
        return p;
    }

    private static float[][][] zerosW(TunedDnn n) {
        float[][][] a = new float[n.w.length][][];
        for (int l = 0; l < a.length; l++) a[l] = new float[n.w[l].length][n.w[l][0].length];
        return a;
    }
    private static float[][] zerosB(TunedDnn n) {
        float[][] a = new float[n.b.length][];
        for (int l = 0; l < a.length; l++) a[l] = new float[n.b[l].length];
        return a;
    }
    private static void zero(float[][][] gW, float[][] gB) {
        for (float[][] a : gW) for (float[] r : a) java.util.Arrays.fill(r, 0f);
        for (float[] r : gB) java.util.Arrays.fill(r, 0f);
    }
}
