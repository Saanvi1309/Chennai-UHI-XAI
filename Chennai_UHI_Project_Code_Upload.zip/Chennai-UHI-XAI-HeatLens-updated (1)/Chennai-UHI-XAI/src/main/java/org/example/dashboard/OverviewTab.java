package org.example.dashboard;

import javafx.collections.FXCollections;
import javafx.scene.chart.*;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableView;
import javafx.scene.layout.*;
import org.example.analytics.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** KPIs, class distribution, daily profile, seasonal profile, satellite grid-point map, month x hour heat-map. */
final class OverviewTab extends ScrollPane {
    private final AppState st;
    private final Ui.Kpi kRows = new Ui.Kpi("HOURS IN VIEW", Palette.TEAL), kAnom = new Ui.Kpi("MEAN UHI ANOMALY", 0xFF7F0E),
            kExt = new Ui.Kpi("EXTREME UHI SHARE", Palette.CLASS[3]), kDan = new Ui.Kpi("DANGER-OR-WORSE HEAT STRESS", Palette.RISK[3]),
            kT = new Ui.Kpi("MEAN AIR TEMPERATURE", 0x8C564B), kRh = new Ui.Kpi("MEAN HUMIDITY", Palette.CLASS[0]);
    private final BarChart<String, Number> classChart = new BarChart<>(new CategoryAxis(), new NumberAxis());
    private final BarChart<String, Number> monthChart = new BarChart<>(new CategoryAxis(), new NumberAxis());
    private final LineChart<String, Number> hourChart;
    private final MapCanvas map;
    private final HeatmapCanvas heat;
    private final TableView<String[]> locTable = Ui.table(new String[]{"Point", "Hours", "Mean anomaly", "Extreme", "Danger+", "Adj. HI"},
            new double[]{190, 60, 90, 70, 70, 70});

    OverviewTab(AppState st) {
        this.st = st;
        CategoryAxis hx = new CategoryAxis();
        hx.setCategories(FXCollections.observableArrayList(Ui.hourCats()));
        hx.setTickLabelRotation(0);
        NumberAxis hy = new NumberAxis();
        hy.setLabel("\u00B0C vs median point");
        hourChart = new LineChart<>(hx, hy);
        hourChart.setCreateSymbols(false);
        hourChart.setAnimated(false);
        hourChart.setPrefHeight(300);
        hourChart.setLegendVisible(false);
        for (BarChart<String, Number> c : List.of(classChart, monthChart)) { c.setAnimated(false); c.setLegendVisible(false); c.setPrefHeight(300); c.setCategoryGap(14); }
        monthChart.setCategoryGap(1);
        monthChart.setBarGap(0);
        ((NumberAxis) classChart.getYAxis()).setLabel("% of hours");
        ((NumberAxis) monthChart.getYAxis()).setLabel("% of hours that are Extreme");
        map = new MapCanvas(st, 520, 380, false);
        heat = new HeatmapCanvas(st, 520, 300);

        FlowPane kpis = new FlowPane(12, 10, kRows, kAnom, kExt, kDan, kT, kRh);
        kpis.setPrefWrapLength(900);
        HBox r1 = new HBox(12, Ui.card("UHI class distribution", classChart),
                Ui.card("Mean UHI anomaly by hour of day (IST)", "Hours are the start of each hour bin; data timestamps are UTC.", new VBox(6, hourChart, Ui.legend(Ui.LOC_COLORS, new String[]{"P1", "P2", "P3", "P4", "P5", "P6"}))),
                Ui.card("Extreme-UHI share by month", monthChart));
        for (var n : r1.getChildren()) HBox.setHgrow(n, Priority.ALWAYS);
        r1.getChildren().get(1).setStyle("-fx-min-width: 0;");
        for (var n : r1.getChildren()) ((Region) n).setMinWidth(0);
        VBox mapBox = Ui.card("Satellite map of the grid points", "Real satellite imagery with each point at its true location. Hover a point for details; scroll to zoom, drag to pan. Pale circles are close to the median point.", map);
        VBox heatBox = Ui.card("When is it hottest? Month \u00D7 hour of day", "Mean UHI anomaly (\u00B0C): red = warmer than the median point, blue = cooler.", heat);
        VBox tblBox = Ui.card("By grid point", locTable);
        HBox r2 = new HBox(12, mapBox, heatBox);
        HBox.setHgrow(heatBox, Priority.ALWAYS);
        VBox page = Ui.page(kpis, r1, r2, tblBox);
        setContent(page);
        setFitToWidth(true);
        getStyleClass().add("page-scroll");
        heatBox.widthProperty().addListener((o, a, b) -> { heat.setWidth(Math.max(300, b.doubleValue() - 30)); });
        st.onView(this::update);
    }

    void update() {
        ViewStats v = st.stats;
        DataStore ds = st.ds;
        kRows.set(String.format(Locale.ROOT, "%,d", v.n), v.n == 0 ? "" : "of " + String.format(Locale.ROOT, "%,d", ds.n));
        if (v.n == 0) { for (Ui.Kpi k : List.of(kAnom, kExt, kDan, kT, kRh)) k.set("-", ""); }
        else {
            kAnom.set(String.format(Locale.ROOT, "%+.2f \u00B0C", v.meanAnomaly), "vs median grid point");
            kExt.set(Ui.pct(v.classShare[3]), "Low " + Ui.pct0(v.classShare[0]) + " \u00B7 High " + Ui.pct0(v.classShare[2]));
            kDan.set(Ui.pct(v.riskShare[3] + v.riskShare[4]), "peak adj. heat index " + Ui.num(v.maxAdjHi, 1) + " \u00B0C");
            kT.set(Ui.num(v.meanAirT, 1) + " \u00B0C", "heat index " + Ui.num(v.meanHeatIndex, 1) + " \u00B0C");
            kRh.set(Ui.num(v.meanRh, 0) + " %", "");
        }
        // class distribution
        XYChart.Series<String, Number> s = new XYChart.Series<>();
        for (int c = 0; c < Cfg.NC; c++) s.getData().add(new XYChart.Data<>(Cfg.CLASS_NAMES[c], v.classShare[c] * 100));
        classChart.getData().setAll(List.of(s));
        Ui.colorBars(classChart, Palette.CLASS);
        // months
        XYChart.Series<String, Number> m = new XYChart.Series<>();
        for (int i = 0; i < 12; i++) m.getData().add(new XYChart.Data<>(Ui.MONTHS[i], v.monthExtremeShare[i] * 100));
        monthChart.getData().setAll(List.of(m));
        Ui.colorBars(monthChart, new int[]{Palette.CLASS[3]});
        // hourly profile
        List<String> cats = Ui.hourCats();
        List<XYChart.Series<String, Number>> all = new ArrayList<>();
        for (int l = 0; l < ds.nLoc; l++) {
            if (v.locN[l] == 0) continue;
            XYChart.Series<String, Number> sr = new XYChart.Series<>();
            sr.setName(ds.locShort[l]);
            for (int i = 0; i < 24; i++) sr.getData().add(new XYChart.Data<>(cats.get(i), v.locHourMeanAnom[l][Cfg.hourAt(i)]));
            all.add(sr);
        }
        hourChart.getData().setAll(all);
        int k = 0;
        for (int l = 0; l < ds.nLoc; l++) if (v.locN[l] > 0) Ui.styleLine(hourChart.getData().get(k++), Ui.LOC_COLORS[l], 2.2, false);
        // heat-map month x hour
        double[][] g = new double[12][24];
        boolean[][] has = new boolean[12][24];
        for (int mo = 0; mo < 12; mo++) for (int i = 0; i < 24; i++) { int u = Cfg.hourAt(i); g[mo][i] = v.hm[mo][u]; has[mo][i] = v.hmN[mo][u] > 0; }
        heat.setData(g, has, Ui.MONTHS, Ui.hourLabelsRot(), (x, a, b) -> Palette.diverging(x, Math.max(Math.abs(a), Math.abs(b))), "\u00B0C");
        map.draw();
        // table
        List<String[]> rows = new ArrayList<>();
        for (int l = 0; l < ds.nLoc; l++) {
            if (v.locN[l] == 0) continue;
            rows.add(new String[]{ds.locName[l], String.valueOf(v.locN[l]), String.format(Locale.ROOT, "%+.2f", v.locMeanAnom[l]),
                    Ui.pct0(v.locExtremeShare[l]), Ui.pct0(v.locDangerShare[l]), Ui.num(v.locMeanAdjHi[l], 1)});
        }
        Ui.fill(locTable, rows);
    }
}
