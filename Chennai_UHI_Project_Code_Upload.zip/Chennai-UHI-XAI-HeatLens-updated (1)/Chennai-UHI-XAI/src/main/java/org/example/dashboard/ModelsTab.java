package org.example.dashboard;

import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import org.example.analytics.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** DNN vs gradient boosting vs logistic regression on the rows of the current filter, plus forecast accuracy and drivers. */
final class ModelsTab extends ScrollPane {
    private final AppState st;
    private final CheckBox useVal = new CheckBox("Validation rows (Jan-Jun 2025)"), useTest = new CheckBox("Test rows (Jul-Dec 2025)");
    private final TableView<String[]> table = Ui.table(new String[]{"Model", "Rows", "Accuracy", "Macro-F1", "\u00B11 class", "Log-loss", "F1 Low", "F1 Moderate", "F1 High", "F1 Extreme"},
            new double[]{150, 70, 80, 80, 80, 80, 70, 90, 70, 80});
    private final BarChart<String, Number> chart = new BarChart<>(new CategoryAxis(), new NumberAxis(0, 100, 20));
    private final ComboBox<String> cmModel = new ComboBox<>();
    private final GridPane cm = new GridPane();
    private final BarChart<Number, String> imp1 = new BarChart<>(new NumberAxis(), new CategoryAxis());
    private final BarChart<Number, String> imp2 = new BarChart<>(new NumberAxis(), new CategoryAxis());
    private final LineChart<Number, Number> fcChart = new LineChart<>(new NumberAxis(1, 24, 3), new NumberAxis(40, 90, 10));
    private ModelSuite.Row[] last;

    ModelsTab(AppState st) {
        this.st = st;
        useTest.setSelected(true);
        useVal.setSelected(false);
        useVal.selectedProperty().addListener((o, a, b) -> update());
        useTest.selectedProperty().addListener((o, a, b) -> update());
        cmModel.getItems().addAll(st.ms.modelNames);
        cmModel.setValue(st.ms.modelNames[0]);
        cmModel.valueProperty().addListener((o, a, b) -> drawCm());

        chart.setAnimated(false); chart.setPrefHeight(280); chart.setCategoryGap(24); chart.setLegendVisible(false);
        ((NumberAxis) chart.getYAxis()).setLabel("%");
        imp1.setAnimated(false); imp1.setLegendVisible(false); imp1.setPrefHeight(340); imp1.setCategoryGap(4);
        imp2.setAnimated(false); imp2.setLegendVisible(false); imp2.setPrefHeight(340); imp2.setCategoryGap(4);
        fcChart.setCreateSymbols(false); fcChart.setAnimated(false); fcChart.setPrefHeight(300); fcChart.setLegendVisible(false);
        ((NumberAxis) fcChart.getXAxis()).setLabel("Forecast horizon (hours ahead)");
        ((NumberAxis) fcChart.getYAxis()).setLabel("Accuracy (%)");
        ((NumberAxis) fcChart.getYAxis()).setForceZeroInRange(false);

        HBox pick = new HBox(16, new Label("Score on:"), useVal, useTest);
        pick.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        Label how = Ui.note("All classifiers see the same 28 standardised features and are scored on the same hours. The DJL DNN is read directly from "
                + (st.ms.dnn == null ? "(DNN weights not found)" : st.ms.dnn.source.getFileName()) + " (your DJL training output); the tuned DNN (see DNN Prediction page), gradient boosting and logistic regression are trained on 2024 with 2025 H1 for early stopping. "
                + "Scores change with the filters on the left - e.g. pick one grid point or one season to see where each model is weak.");
        how.getStyleClass().add("banner");
        VBox c1 = Ui.card("Model comparison (current filters)", new VBox(8, pick, table));
        VBox c2 = Ui.card("Headline metrics", new VBox(6, chart, Ui.legend(java.util.Arrays.copyOf(Ui.MODEL_COLORS, st.ms.modelNames.length), st.ms.modelNames)));
        VBox c3 = Ui.card("Confusion matrix", "Rows = actual class, columns = predicted class; shading = share of the actual class.", new VBox(8, cmModel, cm));
        HBox r1 = new HBox(12, c2, c3);
        HBox.setHgrow(c2, Priority.ALWAYS); HBox.setHgrow(c3, Priority.ALWAYS);
        VBox c4 = Ui.card("Forecast accuracy by horizon (test period)", "The forecaster beats 'same hour yesterday' and climatology at every horizon.", new VBox(6, fcChart, Ui.legend(new int[]{Palette.TEAL, 0xFF7F0E, 0x9467BD, 0x94A3B8}, new String[]{"Forecast model", "Same hour yesterday", "Location\u00D7month\u00D7hour climatology", "Persistence (now = then)"})));
        VBox c5 = Ui.card("What drives the classifier? (gradient boosting gain)", "Share of total split gain; static location features appear because they identify the grid point.", imp1);
        VBox c6 = Ui.card("What drives the forecast?", "Lagged anomalies and 'same hour yesterday' values dominate.", imp2);
        HBox r2 = new HBox(12, c4);
        HBox.setHgrow(c4, Priority.ALWAYS);
        HBox r3 = new HBox(12, c5, c6);
        HBox.setHgrow(c5, Priority.ALWAYS); HBox.setHgrow(c6, Priority.ALWAYS);
        setContent(Ui.page(how, c1, r1, r2, r3));
        setFitToWidth(true);
        getStyleClass().add("page-scroll");
        drawStatic();
        st.onView(this::update);
        st.dark.addListener((o, a, b) -> drawCm());
    }

    private void drawStatic() {
        fill(imp1, Cfg.FEATURES, st.ms.gb.featureGain(), 12, Palette.CLASS[0]);
        fill(imp2, ForecastModel.FEATURE_NAMES, st.ms.forecast.gb.featureGain(), 12, Palette.TEAL);
        ForecastModel.Eval e = st.ms.forecast.testEval;
        if (e == null) return;
        String[] names = {"Forecast model", "Same hour yesterday", "Location\u00D7month\u00D7hour climatology", "Persistence (now = then)"};
        double[][] vals = {e.acc, e.yesterdayAcc, e.climAcc, e.persistAcc};
        List<XYChart.Series<Number, Number>> ss = new ArrayList<>();
        for (int k = 0; k < 4; k++) {
            XYChart.Series<Number, Number> s = new XYChart.Series<>();
            s.setName(names[k]);
            for (int i = 0; i < e.horizons.length; i++) s.getData().add(new XYChart.Data<>(e.horizons[i], vals[k][i] * 100));
            ss.add(s);
        }
        fcChart.getData().setAll(ss);
        int[] cols = {Palette.TEAL, 0xFF7F0E, 0x9467BD, 0x94A3B8};
        for (int k = 0; k < 4; k++) Ui.styleLine(fcChart.getData().get(k), cols[k], k == 0 ? 3 : 2, k == 3);
    }

    private static void fill(BarChart<Number, String> c, String[] names, double[] gain, int top, int color) {
        double tot = Arrays.stream(gain).sum();
        Integer[] idx = new Integer[names.length];
        for (int i = 0; i < idx.length; i++) idx[i] = i;
        Arrays.sort(idx, (a, b) -> Double.compare(gain[b], gain[a]));
        XYChart.Series<Number, String> s = new XYChart.Series<>();
        for (int i = top - 1; i >= 0; i--) s.getData().add(new XYChart.Data<>(tot == 0 ? 0 : gain[idx[i]] / tot * 100, Cfg.prettyFeature(names[idx[i]])));
        c.getData().setAll(List.of(s));
        for (XYChart.Data<Number, String> d : s.getData()) {
            String st = "-fx-bar-fill: " + Ui.css(color) + ";";
            if (d.getNode() != null) d.getNode().setStyle(st);
            d.nodeProperty().addListener((o, a, n) -> { if (n != null) n.setStyle(st); });
        }
        ((NumberAxis) c.getXAxis()).setLabel("% of total gain");
    }

    private void update() {
        last = st.ms.compare(st.ds, st.rows, useVal.isSelected(), useTest.isSelected());
        List<String[]> rows = new ArrayList<>();
        for (ModelSuite.Row r : last)
            rows.add(new String[]{r.name(), String.format(Locale.ROOT, "%,d", r.n()), Ui.pct(r.accuracy()), Ui.pct(r.macroF1()), Ui.pct(r.adjacentAccuracy()),
                    Ui.num(r.logLoss(), 3), Ui.pct(r.f1()[0]), Ui.pct(r.f1()[1]), Ui.pct(r.f1()[2]), Ui.pct(r.f1()[3])});
        Ui.fill(table, rows);
        String[] cats = {"Accuracy", "Macro-F1", "Within \u00B11 class"};
        List<XYChart.Series<String, Number>> ss = new ArrayList<>();
        for (ModelSuite.Row r : last) {
            XYChart.Series<String, Number> s = new XYChart.Series<>();
            s.setName(r.name());
            s.getData().add(new XYChart.Data<>(cats[0], nz(r.accuracy()) * 100));
            s.getData().add(new XYChart.Data<>(cats[1], nz(r.macroF1()) * 100));
            s.getData().add(new XYChart.Data<>(cats[2], nz(r.adjacentAccuracy()) * 100));
            ss.add(s);
        }
        chart.getData().setAll(ss);
        Ui.colorSeriesBars(chart, Ui.MODEL_COLORS);
        drawCm();
    }

    private static double nz(double d) { return Double.isNaN(d) ? 0 : d; }

    private void drawCm() {
        cm.getChildren().clear();
        cm.setHgap(3); cm.setVgap(3);
        if (last == null) return;
        ModelSuite.Row r = Arrays.stream(last).filter(x -> x.name().equals(cmModel.getValue())).findFirst().orElse(last[0]);
        cm.add(new Label(""), 0, 0);
        for (int c = 0; c < Cfg.NC; c++) { Label l = Ui.label("pred " + Cfg.CLASS_NAMES[c], "legend"); cm.add(l, c + 1, 0); }
        boolean dark = st.dark.get();
        for (int a = 0; a < Cfg.NC; a++) {
            cm.add(Ui.label("actual " + Cfg.CLASS_NAMES[a], "legend"), 0, a + 1);
            long tot = 0;
            for (int p = 0; p < Cfg.NC; p++) tot += r.cm()[a][p];
            for (int p = 0; p < Cfg.NC; p++) {
                double share = tot == 0 ? 0 : (double) r.cm()[a][p] / tot;
                Label cell = new Label(String.format(Locale.ROOT, "%,d\n%.0f%%", r.cm()[a][p], share * 100));
                cell.setMinSize(86, 52);
                cell.setAlignment(javafx.geometry.Pos.CENTER);
                cell.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
                int base = a == p ? Palette.TEAL : Palette.CLASS[3];
                double alpha = 0.10 + 0.85 * share;
                Color c = Ui.color(base);
                cell.setStyle(String.format(Locale.ROOT, "-fx-background-color: rgba(%d,%d,%d,%.2f); -fx-background-radius: 6; -fx-text-fill: %s;",
                        (int) (c.getRed() * 255), (int) (c.getGreen() * 255), (int) (c.getBlue() * 255), alpha, share > 0.45 ? "white" : (dark ? "#E5E7EB" : "#111827")));
                cm.add(cell, p + 1, a + 1);
            }
        }
    }
}
