package org.example.dashboard;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.util.StringConverter;
import org.example.analytics.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** 1-24 hour UHI-class and heat-risk forecast for every grid point (with back-testing when the future hour exists in the data). */
final class ForecastTab extends ScrollPane {
    private final AppState st;
    private final DatePicker date = new DatePicker();
    private final ComboBox<Integer> hour = new ComboBox<>();
    private final StripCanvas strip;
    private final LineChart<Number, Number> hiChart = new LineChart<>(new NumberAxis(1, 24, 3), new NumberAxis());
    private final StackedAreaChart<Number, Number> probChart = new StackedAreaChart<>(new NumberAxis(1, 24, 3), new NumberAxis(0, 100, 25));
    private final VBox alerts = new VBox(8);
    private final TableView<String[]> acc = Ui.table(new String[]{"Horizon", "Forecast", "Macro-F1", "Same hour yesterday", "Climatology", "Temp error", "Humidity error"},
            new double[]{70, 80, 80, 140, 100, 90, 110});
    private final Label title = Ui.label("", "card-title");
    private final Label selLabel = Ui.label("", "card-sub");
    private int sel = 3;
    private boolean muted;

    ForecastTab(AppState st) {
        this.st = st;
        DataStore ds = st.ds;
        date.setEditable(false);
        LocalDate min = Cfg.local(ds.time(24)).toLocalDate(), max = Cfg.local(ds.time(ds.nHours - 1)).toLocalDate();
        date.setDayCellFactory(p -> new DateCell() { @Override public void updateItem(LocalDate x, boolean e) { super.updateItem(x, e); setDisable(e || x.isBefore(min) || x.isAfter(max)); } });
        for (int i = 0; i < 24; i++) hour.getItems().add(i);
        hour.setConverter(new StringConverter<>() {
            @Override public String toString(Integer i) { return i == null ? "" : String.format("%02d:30 IST", i); }
            @Override public Integer fromString(String s) { return 0; }
        });
        Button latest = new Button("Latest data hour");
        latest.getStyleClass().add("ghost-button");
        latest.setOnAction(e -> st.setForecastOrigin(ds.nHours - 1));
        Button back = new Button("Pick a hot day (back-test)");
        back.getStyleClass().add("ghost-button");
        back.setOnAction(e -> {
            int best = 24 + 24;
            double bv = -1;
            for (int t = 48; t < ds.nHours - 30; t += 24) {   // evening-before origins, scored by next-day heat
                double s = 0;
                for (int l = 0; l < ds.nLoc; l++) for (int h = 1; h <= 24; h++) { int r = ds.rowAt[t + h][l]; if (r >= 0) s += ds.adjHi[r]; }
                if (s > bv) { bv = s; best = t; }
            }
            st.setForecastOrigin(best);
        });
        date.valueProperty().addListener((o, a, b) -> pushOrigin());
        hour.valueProperty().addListener((o, a, b) -> pushOrigin());

        HBox bar = new HBox(10, new Label("Forecast issued at:"), date, hour, latest, back);
        bar.setAlignment(Pos.CENTER_LEFT);
        Label how = Ui.note("One gradient-boosting model forecasts the UHI class for every hour from +1 h to +24 h, using lagged UHI anomalies, 'same hour yesterday' values, current weather and the target hour. "
                + "Temperature and humidity (for the heat-risk level) come from a diurnal climatology with decaying persistence. If the issue time is inside the dataset, the middle strip shows what actually happened.");
        how.getStyleClass().add("banner");

        strip = new StripCanvas(st, 1080);
        strip.onPick(l -> { sel = l; updateDetail(); });
        VBox stripBox = Ui.card(null, new VBox(6, title, strip, Ui.legend(Palette.CLASS, Cfg.CLASS_NAMES), Ui.legend(Palette.RISK, HeatRisk.LEVELS)));
        stripBox.widthProperty().addListener((o, a, b) -> { strip.setWidth(Math.max(500, b.doubleValue() - 30)); strip.draw(); });

        hiChart.setCreateSymbols(false); hiChart.setAnimated(false); hiChart.setPrefHeight(300); hiChart.setLegendVisible(false);
        ((NumberAxis) hiChart.getXAxis()).setLabel("Hours ahead");
        ((NumberAxis) hiChart.getYAxis()).setLabel("Adjusted heat index (\u00B0C)");
        ((NumberAxis) hiChart.getYAxis()).setForceZeroInRange(false);
        probChart.setCreateSymbols(false); probChart.setAnimated(false); probChart.setPrefHeight(300); probChart.setLegendVisible(false);
        ((NumberAxis) probChart.getXAxis()).setLabel("Hours ahead");
        ((NumberAxis) probChart.getYAxis()).setLabel("Class probability (%)");
        VBox c1 = Ui.card("Heat-risk forecast for the selected point", new VBox(6, hiChart, Ui.legend(new int[]{0x2B6CB0, 0xFF7F0E, Palette.RISK[1], Palette.RISK[2], Palette.RISK[3], Palette.RISK[4]}, new String[]{"Forecast", "Actual (back-test)", "Caution", "Extreme Caution", "Danger", "Extreme Danger"})));
        c1.getChildren().add(1, selLabel);
        VBox c2 = Ui.card("UHI class probabilities", "Click a row in the strip above to change the point.", new VBox(6, probChart, Ui.legend(Palette.CLASS, Cfg.CLASS_NAMES)));
        HBox charts = new HBox(12, c1, c2);
        HBox.setHgrow(c1, Priority.ALWAYS); HBox.setHgrow(c2, Priority.ALWAYS);

        VBox alertBox = Ui.card("Alerts for the next 24 hours", alerts);
        VBox accBox = Ui.card("How good is this forecast? (test period Jul-Dec 2025)", "Accuracy of the forecast UHI class versus simple baselines; mean absolute error of the temperature/humidity forecast.", acc);
        VBox page = Ui.page(bar, how, stripBox, charts, alertBox, accBox);
        setContent(page);
        setFitToWidth(true);
        getStyleClass().add("page-scroll");
        st.onForecast(this::update);
        st.dark.addListener((o, a, b) -> { if (st.forecast != null) updateDetail(); });
    }

    private void pushOrigin() {
        if (muted || date.getValue() == null || hour.getValue() == null) return;
        LocalDateTime local = LocalDateTime.of(date.getValue(), LocalTime.of(hour.getValue(), 30));
        LocalDateTime utc = local.minusMinutes(Cfg.TZ_MIN);
        st.setForecastOrigin((int) ChronoUnit.HOURS.between(DataStore.START, utc));
    }

    private void update() {
        ForecastModel.Forecast f = st.forecast;
        LocalDateTime local = Cfg.local(st.ds.time(f.origin));
        muted = true;
        date.setValue(local.toLocalDate());
        hour.setValue(local.getHour());
        muted = false;
        boolean real = f.origin + ForecastModel.MAX_H < st.ds.nHours;
        title.setText("Forecast from " + local.format(java.time.format.DateTimeFormatter.ofPattern("EEE d MMM yyyy HH:mm", Locale.ENGLISH)) + " IST"
                + (real ? "   (back-test: actual outcomes shown)" : "   (beyond the dataset: no actual outcomes available)"));
        strip.select(sel);
        strip.draw();
        alerts.getChildren().clear();
        for (InsightEngine.Insight in : st.forecastInsights) alerts.getChildren().add(Ui.insightCard(in));
        List<String[]> rows = new ArrayList<>();
        ForecastModel.Eval e = st.ms.forecast.testEval;
        if (e != null) for (int i = 0; i < e.horizons.length; i++)
            rows.add(new String[]{"+" + e.horizons[i] + " h", Ui.pct(e.acc[i]), Ui.pct(e.macroF1[i]), Ui.pct(e.yesterdayAcc[i]), Ui.pct(e.climAcc[i]),
                    Ui.num(e.maeT[i], 2) + " \u00B0C", Ui.num(e.maeRh[i], 1) + " %"});
        Ui.fill(acc, rows);
        updateDetail();
    }

    private void updateDetail() {
        ForecastModel.Forecast f = st.forecast;
        if (f == null) return;
        DataStore ds = st.ds;
        strip.select(sel);
        selLabel.setText(ds.locName[sel] + "  \u2014  dashed lines are the warning-level thresholds");
        XYChart.Series<Number, Number> fc = new XYChart.Series<>(), act = new XYChart.Series<>();
        fc.setName("Forecast");
        act.setName("Actual (dataset)");
        for (int h = 1; h <= ForecastModel.MAX_H; h++) {
            fc.getData().add(new XYChart.Data<>(h, f.adjHi[sel][h - 1]));
            int r = f.origin + h < ds.nHours ? ds.rowAt[f.origin + h][sel] : -1;
            if (r >= 0) act.getData().add(new XYChart.Data<>(h, ds.adjHi[r]));
        }
        List<XYChart.Series<Number, Number>> all = new ArrayList<>(List.of(fc));
        double lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
        for (XYChart.Series<Number, Number> sr : all) for (XYChart.Data<Number, Number> d : sr.getData()) { lo = Math.min(lo, d.getYValue().doubleValue()); hi = Math.max(hi, d.getYValue().doubleValue()); }
        for (XYChart.Data<Number, Number> d : act.getData()) { lo = Math.min(lo, d.getYValue().doubleValue()); hi = Math.max(hi, d.getYValue().doubleValue()); }
        if (!act.getData().isEmpty()) all.add(act);
        List<Integer> shown = new ArrayList<>();
        for (int k = 1; k <= 4; k++) {
            double cut = HeatRisk.CUT[k - 1];
            if (cut < lo - 5 || cut > hi + 5) continue;
            XYChart.Series<Number, Number> t = new XYChart.Series<>();
            t.setName(HeatRisk.LEVELS[k]);
            t.getData().add(new XYChart.Data<>(1, cut));
            t.getData().add(new XYChart.Data<>(24, cut));
            all.add(t);
            shown.add(k);
        }
        hiChart.getData().setAll(all);
        int i = 0;
        Ui.styleLine(hiChart.getData().get(i++), 0x2B6CB0, 3, false);
        if (!act.getData().isEmpty()) Ui.styleLine(hiChart.getData().get(i++), 0xFF7F0E, 2, false);
        for (int k : shown) Ui.styleLine(hiChart.getData().get(i++), Palette.RISK[k], 1.3, true);

        List<XYChart.Series<Number, Number>> ps = new ArrayList<>();
        for (int c = 0; c < Cfg.NC; c++) {
            XYChart.Series<Number, Number> s = new XYChart.Series<>();
            s.setName(Cfg.CLASS_NAMES[c]);
            for (int h = 1; h <= ForecastModel.MAX_H; h++) s.getData().add(new XYChart.Data<>(h, f.proba[sel][h - 1][c] * 100));
            ps.add(s);
        }
        probChart.getData().setAll(ps);
        for (int c = 0; c < Cfg.NC; c++) {
            final int col = Palette.CLASS[c];
            XYChart.Series<Number, Number> s = probChart.getData().get(c);
            String fill = "-fx-fill: " + Ui.css(col) + "; -fx-opacity: 0.85;", stroke = "-fx-stroke: " + Ui.css(col) + ";";
            if (s.getNode() != null) s.getNode().setStyle(fill);
            s.nodeProperty().addListener((o, a, n) -> { if (n != null) n.setStyle(fill); });
        }
    }
}
