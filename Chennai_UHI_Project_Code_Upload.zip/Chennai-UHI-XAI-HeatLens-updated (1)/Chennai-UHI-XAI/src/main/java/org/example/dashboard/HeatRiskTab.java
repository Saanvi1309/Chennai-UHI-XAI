package org.example.dashboard;

import javafx.collections.FXCollections;
import javafx.scene.chart.*;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableView;
import javafx.scene.layout.*;
import org.example.analytics.*;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Heat-risk layer: NWS heat index (temperature + humidity) plus the UHI anomaly, mapped to 5 warning levels. */
final class HeatRiskTab extends ScrollPane {
    private final AppState st;
    private final Ui.Kpi kDan = new Ui.Kpi("DANGER OR WORSE", Palette.RISK[3]), kPeak = new Ui.Kpi("PEAK ADJUSTED HEAT INDEX", Palette.RISK[4]),
            kMean = new Ui.Kpi("MEAN ADJUSTED HEAT INDEX", Palette.RISK[2]), kMonth = new Ui.Kpi("WORST MONTH", Palette.RISK[3]),
            kHour = new Ui.Kpi("HOTTEST TIME OF DAY (IST)", Palette.RISK[2]);
    private final BarChart<String, Number> riskChart = new BarChart<>(new CategoryAxis(), new NumberAxis());
    private final BarChart<String, Number> monthChart = new BarChart<>(new CategoryAxis(), new NumberAxis());
    private final LineChart<String, Number> hourChart;
    private final MapCanvas map;
    private final HeatmapCanvas heat;
    private final TableView<String[]> worst = Ui.table(new String[]{"Time (IST)", "Point", "Air \u00B0C", "RH %", "UHI class", "Heat index", "Adjusted", "Level"},
            new double[]{120, 50, 60, 55, 80, 80, 80, 120});

    HeatRiskTab(AppState st) {
        this.st = st;
        CategoryAxis hx = new CategoryAxis();
        hx.setCategories(FXCollections.observableArrayList(Ui.hourCats()));
        NumberAxis hy = new NumberAxis();
        hy.setLabel("Adjusted heat index (\u00B0C)");
        hy.setForceZeroInRange(false);
        hourChart = new LineChart<>(hx, hy);
        hourChart.setCreateSymbols(false);
        hourChart.setAnimated(false);
        hourChart.setPrefHeight(300);
        hourChart.setLegendVisible(false);
        for (BarChart<String, Number> c : List.of(riskChart, monthChart)) { c.setAnimated(false); c.setLegendVisible(false); c.setPrefHeight(300); c.setCategoryGap(14); }
        monthChart.setCategoryGap(1);
        monthChart.setBarGap(0);
        ((NumberAxis) riskChart.getYAxis()).setLabel("% of hours");
        ((NumberAxis) monthChart.getYAxis()).setLabel("% Danger or worse");
        map = new MapCanvas(st, 520, 380, true);
        heat = new HeatmapCanvas(st, 520, 300);

        Label how = Ui.note("Adjusted heat index = NWS heat index of air temperature and humidity + the local UHI anomaly (\u00B0C above/below the median grid point). "
                + "Bands (\u00B0C): Normal < 26.7 \u00B7 Caution 26.7-32.2 \u00B7 Extreme Caution 32.2-39.4 \u00B7 Danger 39.4-51.1 \u00B7 Extreme Danger \u2265 51.1.");
        how.getStyleClass().add("banner");
        HBox kp = new HBox(12, kDan, kPeak, kMean, kMonth, kHour);
        HBox r1 = new HBox(12, Ui.card("Heat-risk levels", riskChart), Ui.card("Adjusted heat index by hour of day (IST)", "Dashed lines mark the warning-level thresholds (shown when near the data).", new VBox(6, hourChart, Ui.legend(new int[]{0x2B6CB0, Palette.RISK[1], Palette.RISK[2], Palette.RISK[3], Palette.RISK[4]}, new String[]{"Mean adjusted heat index", "Caution", "Extreme Caution", "Danger", "Extreme Danger"}))),
                Ui.card("Danger-or-worse share by month", monthChart));
        for (var n : r1.getChildren()) HBox.setHgrow(n, Priority.ALWAYS);
        r1.getChildren().get(1).setStyle("-fx-min-width: 440;");
        VBox heatBox = Ui.card("Month \u00D7 hour of day: mean adjusted heat index", "Darker red = higher heat stress.", heat);
        HBox r2 = new HBox(12, Ui.card("Grid-point heat risk (satellite map)", "Hover a point for details; scroll to zoom, drag to pan.", map), heatBox);
        HBox.setHgrow(heatBox, Priority.ALWAYS);
        heatBox.widthProperty().addListener((o, a, b) -> heat.setWidth(Math.max(300, b.doubleValue() - 30)));
        VBox adv = new VBox(6);
        for (int k = 4; k >= 0; k--) {
            Label t = new Label(HeatRisk.LEVELS[k] + "  \u2014  " + HeatRisk.ADVICE[k]);
            t.setWrapText(true);
            t.setGraphic(Ui.dot(Palette.RISK[k]));
            adv.getChildren().add(t);
        }
        VBox r3 = Ui.card("What each level means", adv);
        VBox r4 = Ui.card("Ten most severe hours in this view", worst);
        setContent(Ui.page(how, kp, r1, r2, r3, r4));
        setFitToWidth(true);
        getStyleClass().add("page-scroll");
        st.onView(this::update);
    }

    void update() {
        ViewStats v = st.stats;
        DataStore ds = st.ds;
        if (v.n == 0) { for (Ui.Kpi k : List.of(kDan, kPeak, kMean, kMonth, kHour)) k.set("-", ""); }
        else {
            kDan.set(Ui.pct(v.riskShare[3] + v.riskShare[4]), "Danger " + Ui.pct0(v.riskShare[3]) + " \u00B7 Extreme " + Ui.pct(v.riskShare[4]));
            kPeak.set(Ui.num(v.maxAdjHi, 1) + " \u00B0C", HeatRisk.LEVELS[HeatRisk.level(v.maxAdjHi)]);
            kMean.set(Ui.num(v.meanAdjHi, 1) + " \u00B0C", HeatRisk.LEVELS[HeatRisk.level(v.meanAdjHi)]);
            int wm = 0, ph = 0;
            for (int m = 1; m < 12; m++) if (v.monthN[m] > 0 && (v.monthN[wm] == 0 || v.monthDangerShare[m] > v.monthDangerShare[wm])) wm = m;
            for (int h = 1; h < 24; h++) if (v.hourN[h] > 0 && (v.hourN[ph] == 0 || v.hourMeanAdjHi[h] > v.hourMeanAdjHi[ph])) ph = h;
            kMonth.set(Ui.MONTHS[wm], Ui.pct0(v.monthDangerShare[wm]) + " Danger+");
            kHour.set(Cfg.hourLabel(ph), Ui.num(v.hourMeanAdjHi[ph], 1) + " \u00B0C mean");
        }
        XYChart.Series<String, Number> r = new XYChart.Series<>();
        String[] ln = {"Normal", "Caution", "Ext. Caution", "Danger", "Ext. Danger"};
        for (int k = 0; k < 5; k++) r.getData().add(new XYChart.Data<>(ln[k], v.riskShare[k] * 100));
        riskChart.getData().setAll(List.of(r));
        Ui.colorBars(riskChart, Palette.RISK);
        XYChart.Series<String, Number> m = new XYChart.Series<>();
        for (int i = 0; i < 12; i++) m.getData().add(new XYChart.Data<>(Ui.MONTHS[i], v.monthDangerShare[i] * 100));
        monthChart.getData().setAll(List.of(m));
        Ui.colorBars(monthChart, new int[]{Palette.RISK[3]});

        List<String> cats = Ui.hourCats();
        List<XYChart.Series<String, Number>> all = new ArrayList<>();
        XYChart.Series<String, Number> mean = new XYChart.Series<>();
        mean.setName("Mean adjusted heat index");
        for (int i = 0; i < 24; i++) mean.getData().add(new XYChart.Data<>(cats.get(i), v.hourMeanAdjHi[Cfg.hourAt(i)]));
        all.add(mean);
        double lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
        for (int i = 0; i < 24; i++) if (v.hourN[i] > 0) { lo = Math.min(lo, v.hourMeanAdjHi[i]); hi = Math.max(hi, v.hourMeanAdjHi[i]); }
        List<Integer> shown = new ArrayList<>();
        for (int k = 1; k <= 4; k++) {
            double cut = HeatRisk.CUT[k - 1];
            if (v.n == 0 || cut < lo - 8 || cut > hi + 8) continue;
            XYChart.Series<String, Number> t = new XYChart.Series<>();
            t.setName(HeatRisk.LEVELS[k]);
            for (int i = 0; i < 24; i++) t.getData().add(new XYChart.Data<>(cats.get(i), cut));
            all.add(t);
            shown.add(k);
        }
        hourChart.getData().setAll(all);
        Ui.styleLine(hourChart.getData().get(0), 0x2B6CB0, 3, false);
        for (int i = 0; i < shown.size(); i++) Ui.styleLine(hourChart.getData().get(i + 1), Palette.RISK[shown.get(i)], 1.4, true);

        double[][] g = new double[12][24];
        boolean[][] has = new boolean[12][24];
        double[][] sum = new double[12][24];
        int[][] cnt = new int[12][24];
        for (int row : st.rows) { sum[ds.month[row]][ds.hour[row]] += ds.adjHi[row]; cnt[ds.month[row]][ds.hour[row]]++; }
        for (int mo = 0; mo < 12; mo++) for (int i = 0; i < 24; i++) { int u = Cfg.hourAt(i); has[mo][i] = cnt[mo][u] > 0; g[mo][i] = has[mo][i] ? sum[mo][u] / cnt[mo][u] : 0; }
        heat.setData(g, has, Ui.MONTHS, Ui.hourLabelsRot(), (x, a, b) -> {
            double t = b - a < 1e-9 ? 0 : (x - a) / (b - a);
            int rr = (int) (255 - 20 * t), gg = (int) (244 - 200 * t), bb = (int) (200 - 170 * t);
            return (rr << 16) | (gg << 8) | bb;
        }, "\u00B0C");
        map.draw();

        int[] top = new int[10];
        int n = 0;
        for (int row : st.rows) {
            if (n < 10) { top[n++] = row; sortDesc(top, n); }
            else if (ds.adjHi[row] > ds.adjHi[top[9]]) { top[9] = row; sortDesc(top, 10); }
        }
        List<String[]> rows = new ArrayList<>();
        DateTimeFormatter df = DateTimeFormatter.ofPattern("d MMM yyyy HH:mm", Locale.ENGLISH);
        for (int i = 0; i < n; i++) {
            int row = top[i];
            rows.add(new String[]{Cfg.local(ds.time(ds.hourIdx[row])).format(df), ds.locShort[ds.loc[row]], Ui.num(ds.x[row][Cfg.F_AIR_T], 1), Ui.num(ds.x[row][Cfg.F_RH], 0),
                    Cfg.CLASS_NAMES[ds.cls[row]], Ui.num(ds.heatIndex[row], 1), Ui.num(ds.adjHi[row], 1), HeatRisk.LEVELS[ds.risk[row]]});
        }
        Ui.fill(worst, rows);
    }

    private void sortDesc(int[] a, int n) {
        for (int i = 1; i < n; i++) {
            int x = a[i];
            int j = i - 1;
            while (j >= 0 && st.ds.adjHi[a[j]] < st.ds.adjHi[x]) { a[j + 1] = a[j]; j--; }
            a[j + 1] = x;
        }
    }
}
