package org.example.analytics;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Tiny reader for the CSV / text files that {@link AnalysisRunner} writes into results/. */
public final class Results {
    private Results() {}

    public static boolean has(String file) { return Files.exists(Cfg.results().resolve(file)); }

    /** All rows including the header row; empty list if the file is missing. */
    public static List<String[]> read(String file) {
        List<String[]> out = new ArrayList<>();
        Path p = Cfg.results().resolve(file);
        if (!Files.exists(p)) return out;
        try {
            for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) {
                if (line.isBlank()) continue;
                out.add(DataStore.parse(line).toArray(new String[0]));
            }
        } catch (IOException e) { /* treated as missing */ }
        return out;
    }

    /** Rows without the header. */
    public static List<String[]> body(String file) {
        List<String[]> r = read(file);
        return r.isEmpty() ? r : new ArrayList<>(r.subList(1, r.size()));
    }

    public static String text(String file) {
        try { return Files.readString(Cfg.results().resolve(file), StandardCharsets.UTF_8); } catch (IOException e) { return ""; }
    }

    public static double num(String s) {
        try { return Double.parseDouble(s.trim()); } catch (Exception e) { return Double.NaN; }
    }
}
