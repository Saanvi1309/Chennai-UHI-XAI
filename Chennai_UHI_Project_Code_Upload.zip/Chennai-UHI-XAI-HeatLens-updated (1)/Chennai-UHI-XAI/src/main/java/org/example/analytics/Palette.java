package org.example.analytics;

/** Colours shared by the dashboard and the PDF report (0xRRGGBB). */
public final class Palette {
    private Palette() {}
    public static final int[] CLASS = {0x2E86C1, 0x58B368, 0xF39C12, 0xD62828};
    public static final int[] RISK = {0x4CAF50, 0xF9C74F, 0xF8961E, 0xE63946, 0x7B0828};
    public static final int NAVY = 0x14213D, TEAL = 0x1F7A8C, GREY = 0x6B7280, LIGHT = 0xF3F4F6, INK = 0x111827;

    public static String hex(int c) { return String.format("#%06X", c & 0xFFFFFF); }

    /** Diverging blue-white-red colour for v in [-max, max]. */
    public static int diverging(double v, double max) {
        double t = max <= 0 ? 0 : Math.max(-1, Math.min(1, v / max));
        int[] a = t < 0 ? new int[]{255, 255, 255} : new int[]{255, 255, 255};
        int[] b = t < 0 ? new int[]{0x2E, 0x86, 0xC1} : new int[]{0xD6, 0x28, 0x28};
        double k = Math.abs(t);
        int r = (int) Math.round(a[0] + (b[0] - a[0]) * k), g = (int) Math.round(a[1] + (b[1] - a[1]) * k), bl = (int) Math.round(a[2] + (b[2] - a[2]) * k);
        return (r << 16) | (g << 8) | bl;
    }
}
