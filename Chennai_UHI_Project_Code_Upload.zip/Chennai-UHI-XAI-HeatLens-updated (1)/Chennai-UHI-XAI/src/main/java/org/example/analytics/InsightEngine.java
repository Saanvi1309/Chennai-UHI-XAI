package org.example.analytics;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Generates plain-language insights, alerts and recommendations from the filtered view and the forecast. */
public final class InsightEngine {
    private InsightEngine() {}

    /** kind: alert | warn | info | rec */
    public record Insight(String kind, String title, String text) {}

    static final String[] MONTHS = {"January", "February", "March", "April", "May", "June", "July",
            "August", "September", "October", "November", "December"};
    private static final DateTimeFormatter DAY_HOUR = DateTimeFormatter.ofPattern("EEE HH:mm", Locale.ENGLISH);

    static String hh(int h) { return Cfg.hourLabel(h) + " " + Cfg.TZ_NAME; }
    static String pct(double v) { return String.format(Locale.ROOT, "%.0f%%", v * 100); }

    public static List<Insight> fromView(DataStore ds, ViewStats v) {
        List<Insight> out = new ArrayList<>();
        if (v.n == 0) {
            out.add(new Insight("info", "No data in this view", "The current filters select no rows. Widen the date range or re-enable some locations."));
            return out;
        }
        // 1) location x month x hour hot-spots for the Extreme UHI class
        record Spot(int l, int m, int h, double share, double base, int n) {}
        List<Spot> spots = new ArrayList<>();
        for (int l = 0; l < ds.nLoc; l++) {
            if (v.locN[l] == 0) continue;
            Spot best = null;
            for (int m = 0; m < 12; m++) for (int h = 0; h < 24; h++) {
                int n = v.cellN[l][m][h];
                if (n < 15) continue;
                double s = (double) v.cellExtreme[l][m][h] / n;
                if (best == null || s > best.share) best = new Spot(l, m, h, s, v.locExtremeShare[l], n);
            }
            if (best != null && best.share >= 0.3) spots.add(best);
        }
        spots.sort(Comparator.comparingDouble((Spot s) -> -s.share));
        for (int i = 0; i < Math.min(3, spots.size()); i++) {
            Spot s = spots.get(i);
            out.add(new Insight(s.share >= 0.6 ? "alert" : "warn", "Extreme UHI peak at " + ds.locShort[s.l],
                    String.format(Locale.ROOT, "At %s the Extreme class peaks at %s in %s: %s of those hours are Extreme, versus %s overall for this point (%d hours observed).",
                            ds.locName[s.l], hh(s.h), MONTHS[s.m], pct(s.share), pct(s.base), s.n)));
        }

        // 2) daily window with most Extreme hours
        double totalExt = 0;
        double[] ext = new double[24];
        for (int h = 0; h < 24; h++) { ext[h] = v.hourExtremeShare[h] * v.hourN[h]; totalExt += ext[h]; }
        if (totalExt > 0) {
            int bs = 0; double bv = -1;
            for (int s = 0; s < 24; s++) {
                double sum = ext[s] + ext[(s + 1) % 24] + ext[(s + 2) % 24];
                if (sum > bv) { bv = sum; bs = s; }
            }
            out.add(new Insight("info", "Hottest time-of-day window",
                    String.format(Locale.ROOT, "%s of all Extreme-UHI hours fall between %s and %s (a window that covers only 12.5%% of the day).",
                            pct(bv / totalExt), hh(bs), hh(bs + 3))));
        }

        // 3) hottest / coolest locations
        int hot = -1, cool = -1;
        for (int l = 0; l < ds.nLoc; l++) {
            if (v.locN[l] == 0) continue;
            if (hot < 0 || v.locMeanAnom[l] > v.locMeanAnom[hot]) hot = l;
            if (cool < 0 || v.locMeanAnom[l] < v.locMeanAnom[cool]) cool = l;
        }
        if (hot >= 0 && cool >= 0 && hot != cool) {
            out.add(new Insight("info", "Spatial contrast",
                    String.format(Locale.ROOT, "%s is the warmest point (mean UHI anomaly %+.2f\u00B0C) and %s the coolest (%+.2f\u00B0C): a %.2f\u00B0C gap.",
                            ds.locName[hot], v.locMeanAnom[hot], ds.locName[cool], v.locMeanAnom[cool], v.locMeanAnom[hot] - v.locMeanAnom[cool])));
        }

        // 4) heat risk
        double danger = v.riskShare[3] + v.riskShare[4];
        int wm = -1;
        for (int m = 0; m < 12; m++) if (v.monthN[m] >= 100 && (wm < 0 || v.monthDangerShare[m] > v.monthDangerShare[wm])) wm = m;
        int ph = 0;
        for (int h = 1; h < 24; h++) if (v.hourN[h] > 0 && v.hourMeanAdjHi[h] > v.hourMeanAdjHi[ph]) ph = h;
        String kind = danger >= 0.2 ? "alert" : danger >= 0.05 ? "warn" : "info";
        out.add(new Insight(kind, "Heat-stress exposure",
                String.format(Locale.ROOT, "%s of hours reach Danger or Extreme Danger heat-stress%s. Adjusted heat index peaks around %s (mean %.1f\u00B0C at that hour).",
                        pct(danger), wm >= 0 && v.monthDangerShare[wm] > 0 ? ", worst in " + MONTHS[wm] + " (" + pct(v.monthDangerShare[wm]) + ")" : "",
                        hh(ph), v.hourMeanAdjHi[ph])));

        // 5) seasonal swing
        int hi = -1, lo = -1;
        for (int m = 0; m < 12; m++) if (v.monthN[m] >= 100) {
            if (hi < 0 || v.monthMeanAdjHi[m] > v.monthMeanAdjHi[hi]) hi = m;
            if (lo < 0 || v.monthMeanAdjHi[m] < v.monthMeanAdjHi[lo]) lo = m;
        }
        if (hi >= 0 && lo >= 0 && hi != lo)
            out.add(new Insight("info", "Seasonal pattern", String.format(Locale.ROOT,
                    "Adjusted heat index is highest in %s (%.1f\u00B0C) and lowest in %s (%.1f\u00B0C), a seasonal swing of %.1f\u00B0C.",
                    MONTHS[hi], v.monthMeanAdjHi[hi], MONTHS[lo], v.monthMeanAdjHi[lo], v.monthMeanAdjHi[hi] - v.monthMeanAdjHi[lo])));

        // 6) recommendations
        if (hot >= 0) out.addAll(recommendations(ds, hot, totalExt > 0 ? bestWindow(ext) : -1, danger));
        return out;
    }

    private static int bestWindow(double[] ext) {
        int bs = 0; double bv = -1;
        for (int s = 0; s < 24; s++) {
            double sum = ext[s] + ext[(s + 1) % 24] + ext[(s + 2) % 24];
            if (sum > bv) { bv = sum; bs = s; }
        }
        return bs;
    }

    private static int rank(DataStore ds, int feature, int l) {
        double mine = ds.x[ds.rowAt[0][l]][feature];
        int r = 0;
        for (int j = 0; j < ds.nLoc; j++) if (ds.x[ds.rowAt[0][j]][feature] > mine) r++;
        return r; // 0 = highest of the grid points
    }

    static List<Insight> recommendations(DataStore ds, int l, int windowStart, double dangerShare) {
        List<Insight> r = new ArrayList<>();
        String n = ds.locShort[l];
        double[] x = ds.x[ds.rowAt[0][l]];
        if (rank(ds, Cfg.F_BLD, l) <= 1)
            r.add(new Insight("rec", "Cut built-up heat storage at " + n, String.format(Locale.ROOT,
                    "%s has one of the two highest building densities (%.0f). Prioritise cool/reflective roofs and walls, and shaded public space.", n, x[Cfg.F_BLD])));
        if (x[Cfg.F_NDVI] < 0.5 || rank(ds, Cfg.F_NDVI, l) >= ds.nLoc - 2)
            r.add(new Insight("rec", "Add vegetation at " + n, String.format(Locale.ROOT,
                    "NDVI at %s is %.2f, among the lowest of the six points. Street trees, green roofs and pocket parks should help; test it in the Simulator tab.", n, x[Cfg.F_NDVI])));
        if (rank(ds, Cfg.F_DWATER, l) <= 1)
            r.add(new Insight("rec", "Bring water closer to " + n,
                    n + " is among the points furthest from water bodies. Restoring ponds/tanks and shaded blue-green corridors can add evaporative cooling."));
        if (rank(ds, Cfg.F_ROAD, l) <= 1)
            r.add(new Insight("rec", "Reduce paved surface at " + n,
                    n + " has one of the highest road densities. Use permeable or light-coloured paving and add roadside shade."));
        if (windowStart >= 0)
            r.add(new Insight("rec", "Schedule around the peak window", String.format(Locale.ROOT,
                    "Move outdoor work, school sports and delivery runs away from %s-%s, when Extreme-UHI hours cluster.", hh(windowStart), hh(windowStart + 3))));
        if (dangerShare >= 0.05)
            r.add(new Insight("rec", "Prepare a heat-action plan",
                    "Because Danger-level heat stress is frequent, set up cooling shelters, drinking-water points and an alert trigger tied to the forecast level."));
        if (r.isEmpty()) r.add(new Insight("rec", "Keep monitoring", "No dominant driver stands out for the warmest point; continue tracking the forecast alerts."));
        return r;
    }

    public static List<Insight> fromForecast(DataStore ds, ForecastModel.Forecast f) {
        List<Insight> out = new ArrayList<>();
        int maxLevel = 0;
        for (int l = 0; l < f.nLoc; l++) {
            int h = 0;
            while (h < ForecastModel.MAX_H) {
                if (f.level[l][h] >= 3) {
                    int s = h; double peak = f.adjHi[l][h]; int lv = f.level[l][h];
                    while (h < ForecastModel.MAX_H && f.level[l][h] >= 3) { peak = Math.max(peak, f.adjHi[l][h]); lv = Math.max(lv, f.level[l][h]); h++; }
                    maxLevel = Math.max(maxLevel, lv);
                    out.add(new Insight("alert", HeatRisk.LEVELS[lv] + " heat stress at " + ds.locShort[l],
                            String.format(Locale.ROOT, "%s expected from %s to %s (peak adjusted heat index %.1f\u00B0C). %s",
                                    HeatRisk.LEVELS[lv], DAY_HOUR.format(Cfg.local(ds.time(f.origin + s + 1))), DAY_HOUR.format(Cfg.local(ds.time(f.origin + h))), peak, HeatRisk.ADVICE[lv])));
                } else h++;
            }
        }
        if (out.isEmpty()) {
            for (int l = 0; l < f.nLoc; l++) for (int h = 0; h < ForecastModel.MAX_H; h++) maxLevel = Math.max(maxLevel, f.level[l][h]);
            out.add(new Insight(maxLevel >= 2 ? "warn" : "info", "No Danger-level heat stress forecast",
                    "Highest level in the next 24 h: " + HeatRisk.LEVELS[maxLevel] + ". " + HeatRisk.ADVICE[maxLevel]));
        }
        for (int l = 0; l < f.nLoc; l++) {
            int cnt = 0, first = -1;
            for (int h = 0; h < ForecastModel.MAX_H; h++) if (f.cls[l][h] == 3) { cnt++; if (first < 0) first = h; }
            if (cnt >= 3)
                out.add(new Insight("warn", "Extreme UHI expected at " + ds.locShort[l],
                        String.format(Locale.ROOT, "%d of the next 24 hours are forecast Extreme UHI, starting %s.", cnt, DAY_HOUR.format(Cfg.local(ds.time(f.origin + first + 1))))));
        }
        return out;
    }
}
