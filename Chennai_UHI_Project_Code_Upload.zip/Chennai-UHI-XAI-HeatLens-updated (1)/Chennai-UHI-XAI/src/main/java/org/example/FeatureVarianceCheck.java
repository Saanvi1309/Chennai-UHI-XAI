package org.example;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

public class FeatureVarianceCheck {

    private static final String FILE =
            "data/processed/train.csv";

    private static final String[] FEATURES = {
            "latitude",
            "longitude",
            "air_temperature",
            "dew_point_temperature",
            "cloud_cover",
            "u10",
            "v10",
            "wind_speed",
            "wind_direction",
            "relative_humidity",
            "pressure",
            "rainfall",
            "Population",
            "Area",
            "Population Density",
            "red_band",
            "nir_band",
            "ndvi",
            "ndwi",
            "ndbi",
            "land_use_type",
            "elevation",
            "distance_to_coast",
            "distance_to_green_space",
            "distance_to_road",
            "distance_to_water",
            "building_density",
            "road_density",
            "spatial_match_distance_km",
            "dynamic_nearest_distance_km",
            "landsat_temporal_gap_days"
    };

    public static void main(String[] args) throws Exception {

        System.out.println("======================================");
        System.out.println("FEATURE VARIANCE CHECK");
        System.out.println("======================================");

        try (
                CSVParser parser = CSVParser.parse(
                        Path.of(FILE),
                        StandardCharsets.UTF_8,
                        CSVFormat.DEFAULT.builder()
                                .setHeader()
                                .setSkipHeaderRecord(true)
                                .build()
                )
        ) {

            long rows = 0;

            double[] min = new double[FEATURES.length];
            double[] max = new double[FEATURES.length];

            for (int i = 0; i < FEATURES.length; i++) {
                min[i] = Double.POSITIVE_INFINITY;
                max[i] = Double.NEGATIVE_INFINITY;
            }

            for (CSVRecord record : parser) {

                rows++;

                for (int i = 0; i < FEATURES.length; i++) {

                    String value = record.get(FEATURES[i])
                            .trim()
                            .replace(",", "");

                    double number = Double.parseDouble(value);

                    if (number < min[i]) {
                        min[i] = number;
                    }

                    if (number > max[i]) {
                        max[i] = number;
                    }
                }
            }

            System.out.println("Rows checked: " + rows);
            System.out.println();
            System.out.println("Feature range check:");
            System.out.println("--------------------------------------");

            for (int i = 0; i < FEATURES.length; i++) {

                double range = max[i] - min[i];

                if (range == 0) {
                    System.out.printf(
                            "ZERO VARIANCE: %-35s Min = %.6f  Max = %.6f%n",
                            FEATURES[i],
                            min[i],
                            max[i]
                    );
                }
            }

            System.out.println();
            System.out.println("Check completed.");
        }
    }
}