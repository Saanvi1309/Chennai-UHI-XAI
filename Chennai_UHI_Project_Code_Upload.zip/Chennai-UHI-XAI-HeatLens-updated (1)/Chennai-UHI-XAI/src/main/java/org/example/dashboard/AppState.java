package org.example.dashboard;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import org.example.analytics.*;

import java.util.ArrayList;
import java.util.List;

/** Shared state: data, models, the global filter, and the derived view that every tab renders. */
public final class AppState {
    public final DataStore ds;
    public final ModelSuite ms;
    public final Filter filter = new Filter();
    public final BooleanProperty dark = new SimpleBooleanProperty(false);

    public int[] rows = new int[0];
    public ViewStats stats;
    public List<InsightEngine.Insight> viewInsights = new ArrayList<>();

    /** Set by UHIDashboard so exports can open files. */
    public javafx.application.HostServices host;
    /** Row currently explained on the XAI page (-1 = none). */
    public int xaiRow = -1;

    public int forecastOrigin;
    public ForecastModel.Forecast forecast;
    public List<InsightEngine.Insight> forecastInsights = new ArrayList<>();

    private final List<Runnable> viewListeners = new ArrayList<>();
    private final List<Runnable> forecastListeners = new ArrayList<>();

    public AppState(DataStore ds, ModelSuite ms) {
        this.ds = ds;
        this.ms = ms;
        this.forecastOrigin = ds.nHours - 1;
    }

    public void onView(Runnable r) { viewListeners.add(r); }
    public void onForecast(Runnable r) { forecastListeners.add(r); }

    public void refresh() {
        rows = filter.apply(ds);
        stats = ViewStats.compute(ds, rows);
        viewInsights = InsightEngine.fromView(ds, stats);
        for (Runnable r : viewListeners) r.run();
    }

    public void setForecastOrigin(int t) {
        forecastOrigin = Math.max(24, Math.min(ds.nHours - 1, t));
        forecast = ms.forecast.forecast(ds, forecastOrigin);
        forecastInsights = InsightEngine.fromForecast(ds, forecast);
        for (Runnable r : forecastListeners) r.run();
    }
}
