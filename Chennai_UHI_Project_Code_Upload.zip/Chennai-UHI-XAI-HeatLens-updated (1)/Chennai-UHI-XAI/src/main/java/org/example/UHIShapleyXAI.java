package org.example;

import ai.djl.Model;
import ai.djl.inference.Predictor;
import ai.djl.ndarray.NDArray;
import ai.djl.ndarray.NDList;
import ai.djl.translate.Batchifier;
import ai.djl.translate.Translator;
import ai.djl.translate.TranslatorContext;

import ai.djl.nn.Block;
import ai.djl.nn.SequentialBlock;
import ai.djl.nn.core.Linear;
import ai.djl.nn.norm.Dropout;
import ai.djl.nn.Activation;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.io.input.BOMInputStream;

import java.io.InputStreamReader;
import java.io.Reader;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class UHIShapleyXAI {

    private static final int NUM_FEATURES = 28;
    private static final int NUM_CLASSES = 4;

    private static final int XAI_SAMPLES = 100;
    private static final int PERMUTATIONS = 20;

    private static final String TEST_FILE =
            "data/processed/test_scaled.csv";

    private static final String MODEL_DIR =
            "models";

    private static final String OUTPUT_FILE =
            "data/processed/UHI_XAI_Global_Importance.csv";

    private static final String[] FEATURES = {
            "latitude",
            "longitude",
            "air_temperature",
            "dew_point_temperature",
            "cloud_cover",
            "u10",
            "v10",
            "wind_speed",
            "wind_direction",
            "relative_humidity",
            "pressure",
            "rainfall",
            "red_band",
            "nir_band",
            "ndvi",
            "ndbi",
            "ndwi",
            "land_use_type",
            "elevation",
            "distance_to_coast",
            "distance_to_green_space",
            "distance_to_road",
            "distance_to_water",
            "building_density",
            "road_density",
            "spatial_match_distance_km",
            "dynamic_nearest_distance_km",
            "landsat_temporal_gap_days"
    };

    public static void main(String[] args) throws Exception {

        System.out.println("======================================");
        System.out.println("UHI EXPLAINABLE AI");
        System.out.println("MONTE CARLO SHAPLEY-STYLE ATTRIBUTION");
        System.out.println("======================================");

        List<float[]> samples = new ArrayList<>();

        System.out.println();
        System.out.println("Loading test data...");

        BOMInputStream inputStream =
                BOMInputStream.builder()
                        .setPath(Path.of(TEST_FILE))
                        .get();

        Reader reader =
                new InputStreamReader(
                        inputStream,
                        StandardCharsets.UTF_8
                );

        try (
                CSVParser parser =
                        CSVFormat.DEFAULT
                                .builder()
                                .setHeader()
                                .setSkipHeaderRecord(true)
                                .get()
                                .parse(reader)
        ) {

            int count = 0;

            for (CSVRecord record : parser) {

                if (count >= XAI_SAMPLES) {
                    break;
                }

                float[] row = new float[NUM_FEATURES];

                for (int i = 0; i < NUM_FEATURES; i++) {

                    row[i] =
                            Float.parseFloat(
                                    record.get(FEATURES[i])
                            );
                }

                samples.add(row);
                count++;
            }
        }

        System.out.println(
                "XAI samples: " + samples.size()
        );

        System.out.println();
        System.out.println("Loading trained model...");

        try (Model model = Model.newInstance("uhi-dnn")) {

            Block network =
                    new SequentialBlock()
                            .add(
                                    Linear.builder()
                                            .setUnits(128)
                                            .build()
                            )
                            .add(Activation::relu)
                            .add(
                                    Dropout.builder()
                                            .optRate(0.30f)
                                            .build()
                            )
                            .add(
                                    Linear.builder()
                                            .setUnits(64)
                                            .build()
                            )
                            .add(Activation::relu)
                            .add(
                                    Dropout.builder()
                                            .optRate(0.20f)
                                            .build()
                            )
                            .add(
                                    Linear.builder()
                                            .setUnits(32)
                                            .build()
                            )
                            .add(Activation::relu)
                            .add(
                                    Linear.builder()
                                            .setUnits(NUM_CLASSES)
                                            .build()
                            );

            model.setBlock(network);

            model.load(Path.of(MODEL_DIR));

            try (
                    Predictor<float[], float[]> predictor =
                            model.newPredictor(
                                    new XAITranslator()
                            )
            ) {

                double[] meanAbsoluteContribution =
                        new double[NUM_FEATURES];

                double[] meanSignedContribution =
                        new double[NUM_FEATURES];

                Random random =
                        new Random(42);

                System.out.println();
                System.out.println(
                        "Calculating feature contributions..."
                );

                for (int sampleIndex = 0;
                     sampleIndex < samples.size();
                     sampleIndex++) {

                    float[] original =
                            samples.get(sampleIndex);

                    float[] baseline =
                            new float[NUM_FEATURES];

                    int predictedClass =
                            predictClass(
                                    predictor,
                                    original
                            );

                    List<Integer> permutation =
                            new ArrayList<>();

                    for (int feature = 0;
                         feature < NUM_FEATURES;
                         feature++) {

                        permutation.add(feature);
                    }

                    double[] sampleContribution =
                            new double[NUM_FEATURES];

                    for (int p = 0;
                         p < PERMUTATIONS;
                         p++) {

                        Collections.shuffle(
                                permutation,
                                random
                        );

                        float[] current =
                                baseline.clone();

                        double previousProbability =
                                predictProbability(
                                        predictor,
                                        current,
                                        predictedClass
                                );

                        for (int position = 0;
                             position < NUM_FEATURES;
                             position++) {

                            int featureIndex =
                                    permutation.get(position);

                            current[featureIndex] =
                                    original[featureIndex];

                            double newProbability =
                                    predictProbability(
                                            predictor,
                                            current,
                                            predictedClass
                                    );

                            double contribution =
                                    newProbability
                                            - previousProbability;

                            sampleContribution[
                                    featureIndex
                                    ] += contribution;

                            previousProbability =
                                    newProbability;
                        }
                    }

                    for (int feature = 0;
                         feature < NUM_FEATURES;
                         feature++) {

                        sampleContribution[feature] /=
                                PERMUTATIONS;

                        meanSignedContribution[feature] +=
                                sampleContribution[feature];

                        meanAbsoluteContribution[feature] +=
                                Math.abs(
                                        sampleContribution[feature]
                                );
                    }

                    if ((sampleIndex + 1) % 10 == 0) {

                        System.out.println(
                                "Processed XAI samples: "
                                        + (sampleIndex + 1)
                                        + " / "
                                        + samples.size()
                        );
                    }
                }

                for (int feature = 0;
                     feature < NUM_FEATURES;
                     feature++) {

                    meanAbsoluteContribution[feature] /=
                            samples.size();

                    meanSignedContribution[feature] /=
                            samples.size();
                }

                writeResults(
                        meanAbsoluteContribution,
                        meanSignedContribution
                );
            }
        }

        System.out.println();
        System.out.println(
                "======================================"
        );
        System.out.println(
                "XAI COMPLETED SUCCESSFULLY!"
        );
        System.out.println(
                "======================================"
        );

        System.out.println();
        System.out.println(
                "Output file:"
        );
        System.out.println(
                OUTPUT_FILE
        );
    }

    private static int predictClass(
            Predictor<float[], float[]> predictor,
            float[] input
    ) throws Exception {

        float[] output =
                predictor.predict(input);

        int bestClass = 0;

        for (int i = 1;
             i < output.length;
             i++) {

            if (output[i] > output[bestClass]) {
                bestClass = i;
            }
        }

        return bestClass;
    }

    private static double predictProbability(
            Predictor<float[], float[]> predictor,
            float[] input,
            int targetClass
    ) throws Exception {

        float[] logits =
                predictor.predict(input);

        double maxLogit =
                Double.NEGATIVE_INFINITY;

        for (float logit : logits) {

            if (logit > maxLogit) {
                maxLogit = logit;
            }
        }

        double denominator = 0.0;

        for (float logit : logits) {

            denominator +=
                    Math.exp(logit - maxLogit);
        }

        double numerator =
                Math.exp(
                        logits[targetClass]
                                - maxLogit
                );

        return numerator / denominator;
    }

    private static void writeResults(
            double[] meanAbsoluteContribution,
            double[] meanSignedContribution
    ) throws Exception {

        List<Integer> ranking =
                new ArrayList<>();

        for (int i = 0;
             i < NUM_FEATURES;
             i++) {

            ranking.add(i);
        }

        ranking.sort(
                (a, b) ->
                        Double.compare(
                                meanAbsoluteContribution[b],
                                meanAbsoluteContribution[a]
                        )
        );

        try (
                CSVPrinter printer =
                        new CSVPrinter(
                                new FileWriter(
                                        OUTPUT_FILE,
                                        StandardCharsets.UTF_8
                                ),
                                CSVFormat.DEFAULT
                        )
        ) {

            printer.printRecord(
                    "Feature",
                    "Mean_Absolute_Contribution",
                    "Mean_Signed_Contribution",
                    "Rank"
            );

            for (int rank = 0;
                 rank < ranking.size();
                 rank++) {

                int featureIndex =
                        ranking.get(rank);

                printer.printRecord(
                        FEATURES[featureIndex],
                        meanAbsoluteContribution[
                                featureIndex
                                ],
                        meanSignedContribution[
                                featureIndex
                                ],
                        rank + 1
                );
            }
        }
    }

    private static class XAITranslator
            implements Translator<float[], float[]> {

        @Override
        public NDList processInput(
                TranslatorContext ctx,
                float[] input
        ) {

            NDArray array =
                    ctx.getNDManager()
                            .create(input);

            return new NDList(array);
        }

        @Override
        public float[] processOutput(
                TranslatorContext ctx,
                NDList list
        ) {

            return list.singletonOrThrow()
                    .toFloatArray();
        }

        @Override
        public Batchifier getBatchifier() {
            return null;
        }
    }
}