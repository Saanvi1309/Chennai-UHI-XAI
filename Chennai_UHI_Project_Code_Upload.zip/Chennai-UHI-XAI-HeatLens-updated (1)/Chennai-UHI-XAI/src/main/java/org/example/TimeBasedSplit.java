package org.example;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.io.input.BOMInputStream;

import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;

public class TimeBasedSplit {

    private static final String INPUT_FILE =
            "data/processed/Chennai_UHI_Final.csv";

    private static final String TRAIN_FILE =
            "data/processed/train.csv";

    private static final String VALIDATION_FILE =
            "data/processed/validation.csv";

    private static final String TEST_FILE =
            "data/processed/test.csv";

    public static void main(String[] args) {

        System.out.println("======================================");
        System.out.println("TIME-BASED DATA SPLIT");
        System.out.println("======================================");

        try {

            BOMInputStream inputStream =
                    BOMInputStream.builder()
                            .setPath(Paths.get(INPUT_FILE))
                            .get();

            Reader reader =
                    new InputStreamReader(
                            inputStream,
                            StandardCharsets.UTF_8
                    );

            CSVParser parser =
                    CSVFormat.DEFAULT
                            .builder()
                            .setHeader()
                            .setSkipHeaderRecord(true)
                            .get()
                            .parse(reader);

            String[] headers =
                    parser.getHeaderNames().toArray(new String[0]);

            FileWriter trainWriter =
                    new FileWriter(TRAIN_FILE);

            FileWriter validationWriter =
                    new FileWriter(VALIDATION_FILE);

            FileWriter testWriter =
                    new FileWriter(TEST_FILE);

            CSVPrinter trainPrinter =
                    new CSVPrinter(
                            trainWriter,
                            CSVFormat.DEFAULT
                                    .builder()
                                    .setHeader(headers)
                                    .build()
                    );

            CSVPrinter validationPrinter =
                    new CSVPrinter(
                            validationWriter,
                            CSVFormat.DEFAULT
                                    .builder()
                                    .setHeader(headers)
                                    .build()
                    );

            CSVPrinter testPrinter =
                    new CSVPrinter(
                            testWriter,
                            CSVFormat.DEFAULT
                                    .builder()
                                    .setHeader(headers)
                                    .build()
                    );

            long trainCount = 0;
            long validationCount = 0;
            long testCount = 0;

            for (CSVRecord record : parser) {

                String timestamp =
                        record.get("timestamp");

                int month =
                        Integer.parseInt(
                                timestamp.substring(3, 5)
                        );

                int year =
                        Integer.parseInt(
                                timestamp.substring(6, 10)
                        );

                if (year == 2024) {

                    trainPrinter.printRecord(record);
                    trainCount++;

                } else if (year == 2025 && month <= 6) {

                    validationPrinter.printRecord(record);
                    validationCount++;

                } else if (year == 2025 && month >= 7) {

                    testPrinter.printRecord(record);
                    testCount++;
                }
            }

            trainPrinter.close();
            validationPrinter.close();
            testPrinter.close();
            parser.close();

            System.out.println();
            System.out.println("======================================");
            System.out.println("TIME-BASED SPLIT SUCCESSFUL!");
            System.out.println("======================================");

            System.out.println("Training rows:   " + trainCount);
            System.out.println("Validation rows: " + validationCount);
            System.out.println("Test rows:       " + testCount);
            System.out.println(
                    "Total rows:      "
                            + (trainCount + validationCount + testCount)
            );

            System.out.println();
            System.out.println("Training file:");
            System.out.println(TRAIN_FILE);

            System.out.println();
            System.out.println("Validation file:");
            System.out.println(VALIDATION_FILE);

            System.out.println();
            System.out.println("Test file:");
            System.out.println(TEST_FILE);

        } catch (Exception e) {

            System.out.println();
            System.out.println("ERROR:");
            e.printStackTrace();
        }
    }
}