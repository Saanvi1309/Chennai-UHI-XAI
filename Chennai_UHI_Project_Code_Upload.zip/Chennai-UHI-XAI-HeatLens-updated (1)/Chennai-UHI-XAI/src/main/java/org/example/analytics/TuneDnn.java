package org.example.analytics;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Command-line hyper-parameter search for the DNN. Selection uses validation macro-F1 only.
 * Writes models/dnn_tuned.bin, results/dnn_tuning_results.csv and results/dnn_training_history.csv.
 * Run: org.example.analytics.TuneDnn   (about 10-20 minutes on one CPU core; delete models/dnn_tuned.bin to repeat)
 */
public final class TuneDnn {
    public static void main(String[] args) throws Exception {
        DataStore ds = new DataStore(Cfg.data());
        Path sc = Cfg.models().resolve("scaler.csv");
        Scaler scaler = Files.exists(sc) ? Scaler.load(sc) : Scaler.fit(ds);
        double[][] xtr = ModelSuite.rows(ds, scaler, 0), xva = ModelSuite.rows(ds, scaler, 1);
        int[] ytr = ModelSuite.labels(ds, 0), yva = ModelSuite.labels(ds, 1);
        System.out.println("train " + xtr.length + " rows, validation " + xva.length + " rows (test split not used)");
        List<DnnTrainer.Outcome> all = new ArrayList<>();
        for (DnnTrainer.Hyper h : DnnTrainer.grid()) {
            System.out.println("=== " + h.id + ": " + h.describe());
            DnnTrainer.Outcome o = DnnTrainer.train(xtr, ytr, xva, yva, h, System.out::println);
            System.out.printf(Locale.ROOT, "--> %s best epoch %d  val loss %.4f  val acc %.4f  val macro-F1 %.4f  (%.0f s)%n",
                    h.id, o.bestEpoch(), o.valLoss(), o.valAcc(), o.valMacroF1(), o.seconds());
            all.add(o);
        }
        DnnTrainer.Outcome best = all.get(0);
        for (DnnTrainer.Outcome o : all)
            if (o.valMacroF1() > best.valMacroF1() + 1e-9 || (Math.abs(o.valMacroF1() - best.valMacroF1()) <= 1e-9 && o.valLoss() < best.valLoss())) best = o;
        System.out.println("Selected on validation macro-F1: " + best.hyper().id);
        best.model().label = "DNN (tuned)";
        Files.createDirectories(Cfg.models());
        try (ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(Files.newOutputStream(Cfg.models().resolve("dnn_tuned.bin"))))) {
            out.writeObject(best.model());
        }
        Files.createDirectories(Cfg.results());
        StringBuilder t = new StringBuilder("config,learning_rate,batch_size,dropout_1,dropout_2,dropout_3,lr_schedule,weight_decay,class_weights,epochs_run,best_epoch,val_loss,val_accuracy,val_macro_f1,train_seconds,selected\n");
        StringBuilder h = new StringBuilder("config,epoch,learning_rate,train_loss,train_accuracy_eval_mode_subsample,val_loss,val_accuracy,is_best_epoch,selected_config\n");
        for (DnnTrainer.Outcome o : all) {
            DnnTrainer.Hyper p = o.hyper();
            t.append(String.format(Locale.ROOT, "%s,%.5g,%d,%.2f,%.2f,%.2f,%s,%.0e,%s,%d,%d,%.5f,%.5f,%.5f,%.1f,%s%n", p.id, p.lr, p.batch, p.dropout[0], p.dropout[1], p.dropout[2],
                    p.schedule, p.weightDecay, p.classWeights, o.history().size(), o.bestEpoch(), o.valLoss(), o.valAcc(), o.valMacroF1(), o.seconds(), o == best));
            for (DnnTrainer.Epoch e : o.history())
                h.append(String.format(Locale.ROOT, "%s,%d,%.6f,%.5f,%.5f,%.5f,%.5f,%s,%s%n", p.id, e.epoch(), e.lr(), e.trainLoss(), e.trainAcc(), e.valLoss(), e.valAcc(), e.epoch() == o.bestEpoch(), o == best));
        }
        Files.writeString(Cfg.results().resolve("dnn_tuning_results.csv"), t.toString());
        Files.writeString(Cfg.results().resolve("dnn_training_history.csv"), h.toString());
        System.out.println("Saved models/dnn_tuned.bin and results/dnn_tuning_results.csv, dnn_training_history.csv");
    }
}
