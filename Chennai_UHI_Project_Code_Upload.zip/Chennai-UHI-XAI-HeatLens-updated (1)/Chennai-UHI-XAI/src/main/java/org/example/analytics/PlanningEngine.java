package org.example.analytics;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Urban-planning screening layer. Scores are transparent, rule-based rankings of the six grid cells (each about 0.25 deg, ~28 km)
 * built from the observed heat exposure and the static land-cover indicators in the dataset. They are screening guidance, not
 * site designs. The what-if comparison re-runs the trained DNN on edited input features: a MODEL-BASED SIMULATION, not a
 * guaranteed real-world temperature reduction.
 */
public final class PlanningEngine {
    private PlanningEngine() {}

    public static final String[] MEASURES = {"Tree plantation", "Green-space planning", "Cool roofs", "Roadside vegetation", "Water-body conservation"};

    public static final class LocPlan {
        public int loc;
        public double meanAnomaly, ndvi, distGreen, building, road, distWater;
        public int heatRank;
        public double[] score = new double[MEASURES.length];     // 0..1 (higher = higher priority); NaN = not applicable
        public String[] evidence = new String[MEASURES.length];
        public int bestMeasure;
        public String note;
    }

    public static LocPlan[] plans(DataStore ds, int[] rows) {
        int L = ds.nLoc;
        UrbanAnalytics.LocAgg[] a = UrbanAnalytics.aggregate(ds, rows);
        double[] ndvi = UrbanAnalytics.locMeans(ds, Cfg.F_NDVI), dg = UrbanAnalytics.locMeans(ds, Cfg.F_DGREEN), bl = UrbanAnalytics.locMeans(ds, Cfg.F_BLD),
                rd = UrbanAnalytics.locMeans(ds, Cfg.F_ROAD), dw = UrbanAnalytics.locMeans(ds, Cfg.F_DWATER);
        double[] anom = new double[L];
        for (int l = 0; l < L; l++) anom[l] = a[l].n > 0 ? a[l].anomaly : Double.NaN;
        double[] heat = norm(anom), veg = invert(norm(ndvi)), gap = norm(dg), built = norm(bl), road = norm(rd), water = norm(dw);
        double[] rk = UrbanAnalytics.ranks(anom);
        LocPlan[] out = new LocPlan[L];
        for (int l = 0; l < L; l++) {
            LocPlan p = new LocPlan();
            p.loc = l; p.meanAnomaly = anom[l]; p.ndvi = ndvi[l]; p.distGreen = dg[l]; p.building = bl[l]; p.road = rd[l]; p.distWater = dw[l];
            p.heatRank = (int) (L + 1 - rk[l]);
            p.score[0] = 0.5 * heat[l] + 0.3 * veg[l] + 0.2 * gap[l];
            p.score[1] = 0.5 * gap[l] + 0.3 * veg[l] + 0.2 * heat[l];
            p.score[2] = bl[l] > 0 ? 0.5 * built[l] + 0.5 * heat[l] : Double.NaN;
            p.score[3] = rd[l] > 0 ? 0.5 * road[l] + 0.3 * heat[l] + 0.2 * veg[l] : Double.NaN;
            p.score[4] = 0.6 * (1 - water[l]) + 0.4 * heat[l];
            p.evidence[0] = String.format(Locale.ROOT, "heat rank %d of %d, mean NDVI %.2f, nearest green space %.0f m", p.heatRank, L, ndvi[l], dg[l]);
            p.evidence[1] = String.format(Locale.ROOT, "nearest green space %.0f m, mean NDVI %.2f", dg[l], ndvi[l]);
            p.evidence[2] = bl[l] > 0 ? String.format(Locale.ROOT, "building density %.0f, heat rank %d of %d", bl[l], p.heatRank, L) : "building density 0 in the data: not applicable";
            p.evidence[3] = rd[l] > 0 ? String.format(Locale.ROOT, "road density %.3f, mean NDVI %.2f", rd[l], ndvi[l]) : "road density 0 in the data: not applicable";
            p.evidence[4] = String.format(Locale.ROOT, "nearest water %.0f m, heat rank %d of %d", dw[l], p.heatRank, L);
            int best = 0;
            for (int k = 1; k < MEASURES.length; k++) if (!Double.isNaN(p.score[k]) && (Double.isNaN(p.score[best]) || p.score[k] > p.score[best])) best = k;
            p.bestMeasure = best;
            if (Double.isNaN(p.score[best]) || p.score[best] < 0.5) p.bestMeasure = -1;     // nothing scores high enough: maintain
            out[l] = p;
        }
        return out;
    }

    private static double[] norm(double[] v) {
        double mn = Double.MAX_VALUE, mx = -Double.MAX_VALUE;
        for (double x : v) if (!Double.isNaN(x)) { mn = Math.min(mn, x); mx = Math.max(mx, x); }
        double[] o = new double[v.length];
        for (int i = 0; i < o.length; i++) o[i] = Double.isNaN(v[i]) ? 0 : mx - mn < 1e-12 ? 0.5 : (v[i] - mn) / (mx - mn);
        return o;
    }
    private static double[] invert(double[] v) { double[] o = new double[v.length]; for (int i = 0; i < o.length; i++) o[i] = 1 - v[i]; return o; }

    /** Building density vs heat across the grid points (rank correlation, n = 6). */
    public static double buildingHeatCorrelation(DataStore ds, int[] rows) {
        UrbanAnalytics.LocAgg[] a = UrbanAnalytics.aggregate(ds, rows);
        double[] an = new double[ds.nLoc];
        for (int l = 0; l < an.length; l++) an[l] = a[l].anomaly;
        return UrbanAnalytics.spearman(UrbanAnalytics.locMeans(ds, Cfg.F_BLD), an);
    }

    public static String intervention(LocPlan p) {
        return switch (p.bestMeasure) {
            case -1 -> "Maintain current cover: no measure scores above 0.5 for this grid point";
            case 0 -> "Prioritise tree plantation (largest combined heat + vegetation-deficit score)";
            case 1 -> "Plan new / connected green space (far from existing green cover)";
            case 2 -> "Promote cool / reflective roofs on built-up areas";
            case 3 -> "Add roadside shade trees along the road network";
            default -> "Protect and restore nearby water bodies (cooling relevance)";
        };
    }

    // ------------------------------------------------------------------ mitigation impact comparison

    public static final String[] PRESETS = {"Tree plantation (green +40%)", "Green-space expansion (green +80%)", "Building-density reduction (-30%)",
            "Road-corridor greening (green +25%, road -30%)", "Water-body proximity (-30% distance)"};
    public static Simulator.Scenario preset(int i) {
        return switch (i) {
            case 0 -> new Simulator.Scenario(40, 0, 0, 0);
            case 1 -> new Simulator.Scenario(80, 0, 0, 0);
            case 2 -> new Simulator.Scenario(0, 30, 0, 0);
            case 3 -> new Simulator.Scenario(25, 0, 30, 0);
            default -> new Simulator.Scenario(0, 0, 0, 30);
        };
    }

    /** Typical error of the model's expected-anomaly estimate (test MAE of the DNN, about 0.3 degC); changes below it are within model error. */
    public static final double MODEL_ERROR_C = 0.30;

    public record Impact(int loc, int currentClass, double baseLst, double scenLst, double baseAnomaly, double scenAnomaly, String intervention,
                         double[] classShareBefore, double[] classShareAfter) {
        public double delta() { return scenAnomaly - baseAnomaly; }
        /** Reliability flag for the simulated change (all presets are meant to cool, so a warming response is a model artefact). */
        public String reliability() {
            if (Double.isNaN(delta())) return "no data";
            if (delta() > 0.02) return "counter-intuitive (model warms) - treat as artefact";
            if (Math.abs(delta()) < MODEL_ERROR_C) return "within model error (~" + MODEL_ERROR_C + " C)";
            return "cooling response larger than model error";
        }
    }

    /**
     * For each grid point: current predicted UHI class (most frequent DNN prediction over the rows), baseline and scenario predicted
     * land-surface temperature (= observed grid-median reference LST + model-expected anomaly) and the difference.
     */
    public static Impact[] impacts(DataStore ds, Scaler sc, UhiClassifier model, int[] rows, Simulator.Scenario s, LocPlan[] plans, int maxPerLoc) {
        int L = ds.nLoc;
        List<List<Integer>> by = new ArrayList<>();
        for (int l = 0; l < L; l++) by.add(new ArrayList<>());
        for (int r : rows) by.get(ds.loc[r]).add(r);
        Impact[] out = new Impact[L];
        Random rnd = new Random(7);
        for (int l = 0; l < L; l++) {
            List<Integer> rs = by.get(l);
            if (rs.isEmpty()) { out[l] = new Impact(l, -1, Double.NaN, Double.NaN, Double.NaN, Double.NaN, intervention(plans[l]), new double[Cfg.NC], new double[Cfg.NC]); continue; }
            int n = Math.min(maxPerLoc, rs.size());
            double[] sb = new double[Cfg.NC], sa = new double[Cfg.NC];
            double lb = 0, la = 0, eb = 0, ea = 0;
            int[] votes = new int[Cfg.NC];
            for (int i = 0; i < n; i++) {
                int r = rs.get(n == rs.size() ? i : rnd.nextInt(rs.size()));
                double[] pb = model.predictProba(sc.scale(ds.x[r]));
                double[] pa = s.isBaseline() ? pb : model.predictProba(sc.scale(Simulator.apply(ds.x[r], s)));
                double xb = 0, xa = 0;
                for (int c = 0; c < Cfg.NC; c++) { xb += pb[c] * ds.classMeanAnomaly[c]; xa += pa[c] * ds.classMeanAnomaly[c]; sb[c] += pb[c]; sa[c] += pa[c]; }
                double ref = ds.lst[r] - ds.anomaly[r];            // observed grid-median reference LST of that hour
                lb += ref + xb; la += ref + xa; eb += xb; ea += xa;
                votes[ModelEval.argmax(pb)]++;
            }
            int cur = 0;
            for (int c = 1; c < Cfg.NC; c++) if (votes[c] > votes[cur]) cur = c;
            for (int c = 0; c < Cfg.NC; c++) { sb[c] /= n; sa[c] /= n; }
            out[l] = new Impact(l, cur, lb / n, la / n, eb / n, ea / n, intervention(plans[l]), sb, sa);
        }
        return out;
    }

    public static void write(DataStore ds, ModelSuite ms, Path dir) throws IOException {
        Files.createDirectories(dir);
        int[] rows = UrbanAnalytics.allRows(ds);
        LocPlan[] pl = plans(ds, rows);
        StringBuilder sb = new StringBuilder("location,area_hint,heat_rank_1_hottest,mean_uhi_anomaly_c,mean_ndvi,distance_to_green_space_m,building_density,road_density,distance_to_water_m");
        for (String m : MEASURES) sb.append(',').append(m.toLowerCase(Locale.ROOT).replace(' ', '_').replace('-', '_')).append("_priority");
        sb.append(",top_measure,suggested_intervention\n");
        for (LocPlan p : pl) {
            sb.append(String.format(Locale.ROOT, "%s,\"%s\",%d,%.3f,%.3f,%.1f,%.0f,%.4f,%.1f", ds.locShort[p.loc], Cfg.areaHint(ds.locLat[p.loc], ds.locLon[p.loc]), p.heatRank, p.meanAnomaly, p.ndvi, p.distGreen, p.building, p.road, p.distWater));
            for (double s : p.score) sb.append(Double.isNaN(s) ? ",n/a" : String.format(Locale.ROOT, ",%.3f", s));
            sb.append(String.format(Locale.ROOT, ",%s,\"%s\"%n", p.bestMeasure < 0 ? "none (maintain)" : MEASURES[p.bestMeasure], intervention(p)));
        }
        Files.writeString(dir.resolve("urban_planning_priorities.csv"), sb.toString());

        UhiClassifier model = ms.primary;
        int[] test = UrbanAnalytics.splitRows(ds, 2);
        StringBuilder im = new StringBuilder("scenario,location,current_predicted_class,baseline_predicted_lst_c,scenario_predicted_lst_c,difference_c,baseline_expected_anomaly_c,scenario_expected_anomaly_c,reliability,suggested_intervention,note\n");
        for (int k = 0; k < PRESETS.length; k++) {
            Impact[] ii = impacts(ds, ms.scaler, model, test, preset(k), pl, 3000);
            for (Impact i : ii)
                im.append(String.format(Locale.ROOT, "%s,%s,%s,%.3f,%.3f,%+.3f,%.3f,%.3f,%s,\"%s\",model-based simulation (DNN input edit on test-period rows); not a guaranteed real-world reduction%n",
                        PRESETS[k], ds.locShort[i.loc()], i.currentClass() < 0 ? "n/a" : Cfg.CLASS_NAMES[i.currentClass()], i.baseLst(), i.scenLst(), i.scenLst() - i.baseLst(), i.baseAnomaly(), i.scenAnomaly(), i.reliability(), i.intervention()));
        }
        Files.writeString(dir.resolve("mitigation_impact_comparison.csv"), im.toString());
    }
}
