
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;

import java.io.FileReader;
import java.io.FileWriter;
import java.util.*;

public class UHITargetGenerator {

    private static final String INPUT_FILE =
            "C:\\Users\\Saanvi R\\Desktop\\UHI_PROJECT\\Chennai-UHI-XAI\\data\\raw\\Chennai_UHI_Final_Merged.csv";

    private static final String OUTPUT_FILE =
            "data/processed/Chennai_UHI_With_Target.csv";

    public static void main(String[] args) {

        try {

            System.out.println("======================================");
            System.out.println("UHI TARGET GENERATION");
            System.out.println("======================================");

            // --------------------------------------------------
            // 1. Read the raw CSV
            // --------------------------------------------------

            List<Map<String, String>> rows = new ArrayList<>();

            CSVParser parser = CSVFormat.DEFAULT
                    .builder()
                    .setHeader()
                    .setSkipHeaderRecord(true)
                    .get()
                    .parse(new FileReader(INPUT_FILE));

            List<String> headers = new ArrayList<>(parser.getHeaderMap().keySet());

            System.out.println("Input file:");
            System.out.println(INPUT_FILE);

            System.out.println("Columns: " + headers.size());

            // --------------------------------------------------
            // 2. Read all rows
            // --------------------------------------------------

            for (CSVRecord record : parser) {

                Map<String, String> row = new LinkedHashMap<>();

                for (String header : headers) {
                    row.put(header, record.get(header));
                }

                rows.add(row);
            }

            parser.close();

            System.out.println("Total records: " + rows.size());

            // --------------------------------------------------
            // 3. Group LST values by timestamp
            // --------------------------------------------------

            Map<String, List<Double>> timestampLST =
                    new LinkedHashMap<>();

            for (Map<String, String> row : rows) {

                String timestamp = row.get("timestamp");

                double lst = Double.parseDouble(
                        row.get("land_surface_temperature")
                );

                timestampLST
                        .computeIfAbsent(timestamp, k -> new ArrayList<>())
                        .add(lst);
            }

            System.out.println(
                    "Unique timestamps: " + timestampLST.size()
            );

            // --------------------------------------------------
            // 4. Calculate median LST for every timestamp
            // --------------------------------------------------

            Map<String, Double> referenceLST =
                    new HashMap<>();

            for (Map.Entry<String, List<Double>> entry :
                    timestampLST.entrySet()) {

                List<Double> values = entry.getValue();

                Collections.sort(values);

                double median;

                int size = values.size();

                if (size % 2 == 0) {

                    median =
                            (values.get(size / 2 - 1)
                                    + values.get(size / 2)) / 2.0;

                } else {

                    median =
                            values.get(size / 2);
                }

                referenceLST.put(
                        entry.getKey(),
                        median
                );
            }

            // --------------------------------------------------
            // 5. Add reference LST and UHI anomaly
            // --------------------------------------------------

            String referenceColumn = "reference_lst";
            String anomalyColumn = "uhi_anomaly";

            List<String> outputHeaders =
                    new ArrayList<>(headers);

            outputHeaders.add(referenceColumn);
            outputHeaders.add(anomalyColumn);

            FileWriter writer =
                    new FileWriter(OUTPUT_FILE);

            CSVPrinter printer =
                    new CSVPrinter(
                            writer,
                            CSVFormat.DEFAULT
                                    .builder()
                                    .setHeader(
                                            outputHeaders.toArray(
                                                    new String[0]
                                            )
                                    )
                                    .build()
                    );

            double min = Double.MAX_VALUE;
            double max = -Double.MAX_VALUE;
            double sum = 0;

            long count = 0;

            // --------------------------------------------------
            // 6. Write output
            // --------------------------------------------------

            for (Map<String, String> row : rows) {

                String timestamp =
                        row.get("timestamp");

                double lst =
                        Double.parseDouble(
                                row.get(
                                        "land_surface_temperature"
                                )
                        );

                double reference =
                        referenceLST.get(timestamp);

                double anomaly =
                        lst - reference;

                List<String> outputRow =
                        new ArrayList<>();

                for (String header : headers) {
                    outputRow.add(row.get(header));
                }

                outputRow.add(
                        String.valueOf(reference)
                );

                outputRow.add(
                        String.valueOf(anomaly)
                );

                printer.printRecord(outputRow);

                min = Math.min(min, anomaly);
                max = Math.max(max, anomaly);

                sum += anomaly;
                count++;
            }

            printer.close();
            writer.close();

            // --------------------------------------------------
            // 7. Display results
            // --------------------------------------------------

            double mean = sum / count;

            System.out.println();
            System.out.println("======================================");
            System.out.println("UHI TARGET CREATION SUCCESSFUL!");
            System.out.println("======================================");

            System.out.println(
                    "Unique timestamps processed: "
                            + timestampLST.size()
            );

            System.out.println(
                    "Total records processed: "
                            + count
            );

            System.out.println(
                    "Minimum UHI anomaly: "
                            + min
            );

            System.out.println(
                    "Maximum UHI anomaly: "
                            + max
            );

            System.out.println(
                    "Mean UHI anomaly: "
                            + mean
            );

            System.out.println();
            System.out.println(
                    "Output file created at:"
            );

            System.out.println(
                    OUTPUT_FILE
            );

        } catch (Exception e) {

            System.out.println();
            System.out.println(
                    "ERROR DURING UHI TARGET GENERATION"
            );

            e.printStackTrace();
        }
    }
}